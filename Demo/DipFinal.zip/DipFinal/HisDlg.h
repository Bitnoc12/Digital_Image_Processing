#if !defined(AFX_HISDLG_H__51EE94E1_B2B2_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_HISDLG_H__51EE94E1_B2B2_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HisDlg.h : header file
//

#include "Color.h"
#include "His.h"
/////////////////////////////////////////////////////////////////////////////
// CHisDlg dialog
class CHisDlg : public CDialog
{
// Construction
public:
	CHisDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CHisDlg)
	enum { IDD = IDD_DIALOG_HIS };
	CHis	m_his;
	CColor	m_color;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHisDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHisDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeComboCh();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CImage* m_image;
	BOOL m_bcolor;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISDLG_H__51EE94E1_B2B2_11D4_A11E_0080C8D7131C__INCLUDED_)
