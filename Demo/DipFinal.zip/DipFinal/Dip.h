// Dip.h : main header file for the DIP application
//

#if !defined(AFX_DIP_H__F20EB2A5_A477_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_DIP_H__F20EB2A5_A477_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#define BOUND(x, mn, mx)	((x) < (mn) ? (mn) : ((x) > (mx) ? (mx) : (x)))

/////////////////////////////////////////////////////////////////////////////
// CDipApp:
// See Dip.cpp for the implementation of this class
//

class CDipApp : public CWinApp
{
public:
	CDipApp();
	int GetTypeFromIndex(int nIndex, BOOL bOpenFileDialog);
	int GetIndexFromType(int nDocType, BOOL bOpenFileDialog);
	CString GetExtFromType(int nDocType);
	CString GetFileTypes(BOOL bOpenFileDialog);
	BOOL GetWritableType(int nDocType);
	BOOL PromptForFileName(CString& fileName, UINT nIDSTitle,DWORD dwFlags, BOOL bOpenFileDialog, int* pType=NULL);
	int GetStackSize() { return m_nStackSize;};
	int GetNumOpen() { return m_nNumOpen;};
	int GetFilterIndex() {return m_nFilterIndex;};
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDipApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CDipApp)
	afx_msg void OnAppAbout();
	afx_msg void OnFileOpen();
	afx_msg void OnAppParameter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	UINT m_nFilterIndex;
//	{ CIMAGE_FORMAT_GIF, TRUE, FALSE, "GIF files", "gif" },
//	{ CIMAGE_FORMAT_JPEG, TRUE, TRUE, "JPEG files", "jpg" },
//	{ CIMAGE_FORMAT_PNG, TRUE, TRUE, "PNG files", "png" },
//	{ CIMAGE_FORMAT_BMP, TRUE, TRUE, "BMP files", "bmp" }
	UINT m_nNumOpen;
	UINT m_nStackSize;	
};

struct DocType
{
public:
	int nID;
	BOOL bRead;
	BOOL bWrite;
	const char* description;
	const char* ext;
};

#define NUM_DOC_TYPES 4
extern CDipApp theApp;
extern DocType doctypes[];
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIP_H__F20EB2A5_A477_11D4_A11E_0080C8D7131C__INCLUDED_)
