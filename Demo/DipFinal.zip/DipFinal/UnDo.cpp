// UnDo.cpp: implementation of the CUnDo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Dip.h"
#include "lib/cimage.h"
#include "DipProcessor.h"
#include "UnDo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

UnDoItem::UnDoItem(BOOL color,BOOL modify,CImage *pImage,BOOL bfloat)
:m_next(NULL),m_bColor(color),m_bmodify(modify),m_bfloat(bfloat){
	if(!pImage){
		m_data=NULL;
		return;
	}
	m_data=new CImage(pImage);
	VERIFY(m_data);
	CDipProcessor::CopyData(m_data,pImage);
}
UnDoItem::~UnDoItem(){
	delete m_data;
	m_data=NULL;
	delete m_next;
	m_next=NULL;
}

CUnDo::CUnDo()
{
	m_len=0;
	m_first=new UnDoItem(FALSE,FALSE,NULL);
	VERIFY(m_first);
}

CUnDo::~CUnDo()
{
	delete m_first;
	m_first=NULL;
}
void CUnDo::Add(CImage *pImage,BOOL color,BOOL modify,BOOL bfloat){
	int m_max=theApp.GetStackSize();
	if(m_max<1) return;
	m_len++;
	UnDoItem * temp;
	if(m_len>m_max){
		temp=m_first;
		while(temp->m_next&&temp->m_next->m_next){
			temp=temp->m_next;
		}
		delete temp->m_next;
		temp->m_next=NULL;
		m_len=m_max;
	}
	temp=new UnDoItem(color,modify,pImage,bfloat);
	VERIFY(temp);
	temp->m_next=m_first->m_next;
	m_first->m_next=temp;
}

void CUnDo::UnDo(CImage *&pImage,BOOL &color,BOOL &modify){
	if(m_len<1) return;
	delete pImage;
	UnDoItem *temp=m_first->m_next;
	pImage=temp->m_data;
	color=temp->m_bColor;
	modify=temp->m_bmodify;
	m_first->m_next=temp->m_next;
	temp->m_next=NULL;
	temp->m_data=NULL;
	delete temp;
	m_len--;
}
void CUnDo::Clear(){
	delete m_first->m_next;
	m_first->m_next=NULL;
	m_len=0;
}

BOOL CUnDo::ClearFloat(BOOL &modify)
{
	int len=m_len;
	UnDoItem *temp=m_first;//->m_next;
	while(temp->m_next&&temp->m_next->m_bfloat){
		temp=temp->m_next;
		m_len--;
	}

	UnDoItem *save=temp->m_next;
	if(save&&save->m_next&&save->m_next->m_bmodify){
		temp->m_next=save->m_next;
	//	temp=save;
		while(temp->m_next&&temp->m_next->m_bfloat){
			temp=temp->m_next;
			m_len--;
		}
		modify=temp->m_bmodify;
		save->m_next=temp->m_next;
		temp->m_next=save;
	//	temp=save;
	}else{
		modify=temp->m_bmodify;
	}
	if(len!=m_len){
		UnDoItem *dTemp=m_first->m_next;
		m_first->m_next=temp->m_next;
		temp->m_next=NULL;
		delete dTemp;
		m_len--;
	}
	return len!=m_len;
}

BOOL CUnDo::GetPerModify(BOOL &b,BOOL&c)
{
	BOOL res=FALSE;
	UnDoItem *temp=m_first;//->m_next;
	while(temp->m_next&&temp->m_next->m_bfloat){
		temp=temp->m_next;
		res=TRUE;
	}
	b=temp->m_bmodify;
	c=temp->m_bColor;
	return res;
}

void CUnDo::UpDate()
{
	int m_max=theApp.GetStackSize();
//	if(m_max<2){
//		if(m_len>m_max) 
//			Clear();
		//if(m_max<1)
//			return m_max;
//	}
	if(m_len>m_max){
		int i=0;
		UnDoItem * temp;
		temp=m_first;
		while(i<m_max){
			temp=temp->m_next;
			i++;
		}
		delete temp->m_next;
		temp->m_next=NULL;
		m_len=m_max;
	}
}
