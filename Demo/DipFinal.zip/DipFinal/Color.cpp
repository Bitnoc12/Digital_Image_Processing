// Color.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"
#include "Color.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColor

CColor::CColor()
{
	m_ch=0;
}

CColor::~CColor()
{
}


BEGIN_MESSAGE_MAP(CColor, CStatic)
	//{{AFX_MSG_MAP(CColor)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColor message handlers

void CColor::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect rc;
	GetClientRect(&rc);
	int r=0,g=0,b=0;
	r=m_ch==0||m_ch==1 ? ~r: 0;
	g=m_ch==0||m_ch==2 ? ~g: 0;
	b=m_ch==0||m_ch==3 ? ~b: 0;

	int width=rc.Width();
	VERIFY(width>=256);
	//float dclr=256.0f/width;
	CRect trc(rc);
	trc.right=rc.left+1;
	for(int i=0;i<255;i++){
//		dc.FillSolidRect(&trc,RGB(int(i*dclr)&r,int(i*dclr)&g,int(i*dclr)&b));
		dc.FillSolidRect(&trc,RGB(i&r,i&g,i&b));
		trc.left++;
		trc.right++;
	}
}

void CColor::SetCh(int ch)
{
	m_ch=ch;
}