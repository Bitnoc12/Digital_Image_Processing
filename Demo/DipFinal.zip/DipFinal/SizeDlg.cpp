// SizeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "dip.h"
#include "SizeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSizeDlg dialog


CSizeDlg::CSizeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSizeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSizeDlg)
	m_nHeight = 0;
	m_nWidth = 0;
	//}}AFX_DATA_INIT
}


void CSizeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSizeDlg)
	DDX_Control(pDX, IDC_EDIT_WIDTH, m_width);
	DDX_Control(pDX, IDC_EDIT_HEIGHT, m_height);
	DDX_Control(pDX, IDC_CHECK_HOLD, m_check);
	DDX_Text(pDX, IDC_EDIT_HEIGHT, m_nHeight);
	DDX_Text(pDX, IDC_EDIT_WIDTH, m_nWidth);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSizeDlg, CDialog)
	//{{AFX_MSG_MAP(CSizeDlg)
	ON_EN_CHANGE(IDC_EDIT_WIDTH, OnChangeEditWidth)
	ON_BN_CLICKED(IDC_CHECK_HOLD, OnCheckHold)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSizeDlg message handlers

BOOL CSizeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_check.SetCheck(1);
	m_bCheck=TRUE;
	m_height.EnableWindow(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSizeDlg::OnChangeEditWidth() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	if(m_check.GetCheck()){
		UpdateData();
		m_nHeight=int(scale*m_nWidth);
		UpdateData(FALSE);
	}
}

void CSizeDlg::SetData(int width, int height)
{
	m_nWidth=width;
	m_nHeight=height;
	scale=float(height)/width;
}

void CSizeDlg::OnCheckHold() 
{
	// TODO: Add your control notification handler code here
	m_bCheck=m_check.GetCheck();
	m_height.EnableWindow(!m_bCheck);
}
