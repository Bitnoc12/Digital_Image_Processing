// DipProcessor.h: interface for the CDipProcessor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DIPPROCESSOR_H__01D0505A_261F_4BEE_8614_AF75DB87A19A__INCLUDED_)
#define AFX_DIPPROCESSOR_H__01D0505A_261F_4BEE_8614_AF75DB87A19A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Definitions required for convolution image filtering
#define MAX_STRENGTH 20
#define KERNELCOLS 3
#define KERNELROWS 3
#define KERNELELEMENTS (KERNELCOLS * KERNELROWS)

// struct for convolute kernel 
typedef struct 
{
  int Element[KERNELELEMENTS];
  float Divisor;
} KERNEL;

#define LF1      1
#define LF2      2
#define GAUSS    3
#define HF1      4
#define HF2      5
#define HF3      6
#define ROBERTS  7
#define PREWITT  8
#define SOBEL    9
#define ISOBEL   10
#define LAP1     11  
#define LAP2     12 
#define LAP3     13 
#define LAP4     14

extern int D1[],D2[],D3[];

#include "lib/cimage.h"

#define _Round(d) ( (d>0) ? int(d+0.5f): -int(-d+0.5f) )
inline unsigned char FloatToByte(double d)
{
	int i = _Round(d);
	if (i < 0)
		return (unsigned char)0;
	else if (i > 255)
		return (unsigned char)255;
	else
		return (unsigned char)i;
}

#define Lab_f(t) ( (t>0.008856) ? pow(t,1.0/3) : 7.787*t+16.0/116)
#define	max(a, b) (((a) > (b)) ? (a) : (b)) 
#define	min(a, b) (((a) < (b)) ? (a) : (b)) 

#define	max3(a, b, c) (((a) > (b)) ? max(a,c) : max(b,c)) 
#define	min3(a, b, c) (((a) < (b)) ? min(a,c) : min(a,c)) 

class CDipProcessor  
{
public:
	static BOOL Empty(CImage *pImage);
	static BOOL Canny(CImage *&pImage);
	static BOOL GetColorSet(CImage *pImage);
	static BOOL CanCopy(CImage *p1,CImage *p2);
	static BOOL Thin(CImage *&pImage,BOOL white);
	static BOOL GaussLap(CImage *&pImage,int bColor);
	static BOOL MedianFilter(CImage *&pImage,BOOL bColor);
	static BOOL SUSAN(CImage *&pImage,int g,int t,BOOL bColor);
	static BOOL ConvoluteImage(CImage *&pImage, KERNEL *lpKernel, int Strength, int nKernelNum,int bColor);
	static void DoGray(CImage *pImage);
	static void HisEqu(CImage *&pImage);
	static void PointPseudo(CImage *pImage);
	static void GeoMirror_H(CImage *pImage);
	static void GeoMirror_L(CImage *pImage);
	static void PointNegative(CImage * pImage);
	static void ImageMax(CImage *p1, CImage *p2);
	static void PointTransMinus(CImage *&pImage);
	static void SetNColor(CImage *pImage,BYTE n);
	static void ComputeNewImage(CImage *&m_image);
	static void SetOneColor(CImage *pImage,int i);
	static void CvtColorLab(CImage *pImage);
	static void CvtColorXYZ(CImage *pImage);
	static void CvtColorYCrCb(CImage *pImage);
	static void CvtColorHSV(CImage *pImage);
	static void CvtColorSTV(CImage *pImage);
	static void ImageMinus(CImage *p1, CImage *p2);
	static void GeoTranlate_L(CImage *&pImage,int i);
	static void GeoTranlate_H(CImage *&pImage, int i);
	static void CopyData(CImage *image,CImage *pImage);
	static void PointThreshold(CImage * pImage,byte k);
	static void PointLine(CImage *pImage,float a,int b);
	static void GeoTranlate(CImage *&pImage,int i,int j);
	static void CopyData(CImage *image,const BITMAPINFO  *info);
	static void GeoTs(CImage *&pImage,float jl,int sj1,int sj2,float jj,BOOL inter);
	static void GeoAffine(CImage *&pImage,float cd,float ss,float nq,float xz,BOOL inter);
	static void Convolute(CImage *&pImage,int Strength,int nFilter,int bColor);
	static void MergePart(CImage *&pImage,CImage *image, int left, int top);
	static void CutPart(CImage *pImage,int left,int top,int width,int height);
	static void PointContrast(CImage *pImage,CPoint &a,CPoint &b);
	static HANDLE CopyHandle(HANDLE h);
	static HANDLE ImageToDIB(CImage *pImage);
	static HBITMAP ImageToDDB(CImage *pImage);
	static int * His(CImage *pImage,int ch,BOOL color);
	static CImage * MorphDilation(CImage *&pImage, int *T, int m, int n,BOOL del=TRUE);
	static CImage * MorphErosion(CImage *&pImage,int *T,int m,int n,BOOL del=TRUE);
	static CImage * PointAdd(CImage *p1, CImage *p2);
	static CImage * PointAnd(CImage *p1, CImage *p2);
	static CImage * PointMinus(CImage *p1,CImage *p2);
	static CImage * Sys_Size(CImage *pImage, int nWidth, int nHeight);
	static CImage * GetPart(CImage *pImage,int left,int top,int width,int height);
	static CImage * Cov_8_To_24(CImage *pImage);
	static CImage * Cov_24_To_8(CImage *pImage,BOOL bcolor);
private:
	static float Interpolation(float nx,float ny,float *data,int sx,int sy);
	static BOOL ConvImage2(float *out1,float *out2,CImage *pImage,int *T1,int div1,int *T2,int div2);
	static BOOL ConvImage(float *out,CImage *pImage,int *T,int div);
	static void DoSusan(int *r, int *g, int *b, int G,int T,ImagePointerType pt, int sDepth,long EffWidth,BOOL bColor);
	static void DoPoint(CImage *pImage);
	static int ComputePixel(float x, float y, float &x1, float &y1);
	static void DoConvoluteDIB1(int *red, int *green, int *blue, ImagePointerType pt,int sDepth,long EffWidth, KERNEL *lpKernel,int bColor);
	static void DoConvoluteDIB2(int *red, int *green, int *blue, ImagePointerType pt,int sDepth,long EffWidth, KERNEL *lpKernel,int bColor);
	static void DoMedianFilter1(int *red, int *green, int *blue, ImagePointerType p,int sDepth,long EffWidth);
	static void DoMedianFilter2(int *red, int *green, int *blue, ImagePointerType p,int sDepth,long EffWidth);
	static BYTE r[256],g[256],b[256];
};

#endif // !defined(AFX_DIPPROCESSOR_H__01D0505A_261F_4BEE_8614_AF75DB87A19A__INCLUDED_)
