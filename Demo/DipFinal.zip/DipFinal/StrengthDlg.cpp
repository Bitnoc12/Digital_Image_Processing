// StrengthDlg.cpp : implementation file
//

#include "stdafx.h"
#include "dip.h"

#include "DipProcessor.h"

#include "DipDoc.h"
#include "DipView.h"

#include "StrengthDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStrengthDlg dialog


CStrengthDlg::CStrengthDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStrengthDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStrengthDlg)
	m_strength = 0;
	//}}AFX_DATA_INIT
}


void CStrengthDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStrengthDlg)
	DDX_Control(pDX, IDC_STATIC_GRAPH, m_graph);
	DDX_Slider(pDX, IDC_SLIDER_STRENGTH, m_strength);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStrengthDlg, CDialog)
	//{{AFX_MSG_MAP(CStrengthDlg)
	ON_WM_HSCROLL()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStrengthDlg message handlers

BOOL CStrengthDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString str;
	CSliderCtrl * ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_STRENGTH);
	ps->SetRange(1,MAX_STRENGTH);
	ps->SetPos(3);
	str.Format("%d",ps->GetPos());
	SetDlgItemText(IDC_STATIC_STRENGTH,str);

	CDipView * m_view=CDipView::GetActiveView();
	CRect rc;
	m_graph.GetClientRect(&rc);
	CImage *pImage=m_view->GetDocument()->GetCurImage();
	m_color=m_view->GetDocument()->GetColorType();
	CImage *temp;
	BOOL bCopy=FALSE;
	if(pImage->GetDepth()<16){
		temp=CDipProcessor::Cov_8_To_24(pImage);
		bCopy=TRUE;
	}else{
		temp=pImage;
		bCopy=FALSE;
	}
	m_bak=CDipProcessor::Sys_Size(temp,rc.Width(),rc.Height());
	m_image=CDipProcessor::Sys_Size(temp,rc.Width(),rc.Height());
	VERIFY(m_bak->IsOK());
	VERIFY(m_image->IsOK());
	CDipProcessor::Convolute(m_image,ps->GetPos(),m_filter,m_color);
	m_graph.SetImage(m_image);
	if(bCopy){
		delete temp;
		temp=NULL;
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CStrengthDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CSliderCtrl * ps=(CSliderCtrl*)pScrollBar;
	CString str;
	str.Format("%d",ps->GetPos());
	SetDlgItemText(IDC_STATIC_STRENGTH,str);
	
	CDipProcessor::CopyData(m_image,m_bak);
	CDipProcessor::Convolute(m_image,ps->GetPos(),m_filter,m_color);
	m_graph.SetImage(m_image);
	m_graph.Invalidate();
	
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CStrengthDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	delete m_bak;
	m_bak=NULL;	
}
