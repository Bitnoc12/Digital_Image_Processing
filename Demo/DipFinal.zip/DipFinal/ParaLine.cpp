// ParaLine.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"
#include "ParaLine.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CParaLine

CParaLine::CParaLine()
{
	m_bCaptured=FALSE;
	a.x=100;
	a.y=155;
	b.x=200;
	b.y=55;
	m_selected=NO;
}

CParaLine::~CParaLine()
{
}


BEGIN_MESSAGE_MAP(CParaLine, CStatic)
	//{{AFX_MSG_MAP(CParaLine)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CParaLine message handlers

void CParaLine::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CRect tempRecta(a.x-_W,a.y-_H,a.x+_W,a.y+_H);
	CRect tempRectb(b.x-_W,b.y-_H,b.x+_W,b.y+_H);
	if(	tempRecta.PtInRect(point))
	{
		SetCapture();
		m_bCaptured=TRUE;
		m_selected=A;
	}
	if (tempRectb.PtInRect(point))
	{
		SetCapture();
		m_bCaptured=TRUE;
		m_selected=B;
	}
}

void CParaLine::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_bCaptured)
	{
		::ReleaseCapture();
		m_bCaptured=FALSE;
		m_selected=NO;
	}	
}

void CParaLine::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(m_bCaptured)
	{
        if(m_selected==A)
		{
			if(point.x>_W&&point.y>=(b.y)&&point.x<b.x&&point.y<width+_H)
			{
				a=point;
				Invalidate();	
			}
		}else if(m_selected==B){
			if(point.x>a.x&&point.y>_H&&point.x<width+_W&&point.y<(a.y))
			{
				b=point;
				Invalidate();	
			}
		}
	}
}

void CParaLine::OnPaint() 
{
	CPaintDC dc(this);
	
	CString str;
	CStatic *st=(CStatic*)GetParent()->GetDlgItem(IDC_STATIC_A);
	str.Format("%d",a.x-_W);
	st->SetWindowText(str);
	
	st=(CStatic*)GetParent()->GetDlgItem(IDC_STATIC_B);
	str.Format("%d",b.x-_H);
	st->SetWindowText(str);

	st=(CStatic*)GetParent()->GetDlgItem(IDC_STATIC_ALPHA);
	str.Format("%.3f",float(width+_H-a.y)/(a.x-_W));
	st->SetWindowText(str);

	st=(CStatic*)GetParent()->GetDlgItem(IDC_STATIC_BETA);
	str.Format("%.3f",float(b.y-a.y)/(a.x-b.x));
	st->SetWindowText(str);

	st=(CStatic*)GetParent()->GetDlgItem(IDC_STATIC_GAMA);
	str.Format("%.3f",float(b.y-_H)/(width+_W-b.x));
	st->SetWindowText(str);

	dc.FillSolidRect(0,0,_W,w,RGB(212,208,200));
	dc.FillSolidRect(_W,0,width+_W,_H,RGB(212,208,200));
	dc.FillSolidRect(width+_W,0,_W+1,width+_H,RGB(212,208,200));
	dc.FillSolidRect(_W,width+_H,w-_W,_H+1,RGB(212,208,200));
	CPen pen(PS_SOLID,1,RGB(255,0,0));
    CPen* oldpen=dc.SelectObject(&pen);
	CBrush brush(RGB(0,0,0));
    CBrush* oldbrush=dc.SelectObject(&brush);
    dc.Rectangle(CRect(_W,_H,width+_W,width+_H));	
	dc.MoveTo(_W,width+_H-1);
	dc.LineTo(a.x,a.y);
	dc.LineTo(b.x,b.y);
	dc.LineTo(width+_W-1,_H);
	dc.SelectObject(oldpen);

	dc.FillSolidRect(a.x-_W,a.y-_H,_W*2+1,_H*2+1,RGB(255,255,0));
	dc.FillSolidRect(b.x-_W,b.y-_H,_W*2+1,_H*2+1,RGB(255,255,0));	
}

void CParaLine::GetPoint(CPoint &x,CPoint &y){
	x.x=a.x-_W;
	x.y=width+_H-a.y;
	y.x=b.x-_W;
	y.y=width+_H-b.y;
}

void CParaLine::init()
{
	CRect rc;
	GetClientRect(&rc);
	w=rc.Width();
	width=w-2*_W;
}
