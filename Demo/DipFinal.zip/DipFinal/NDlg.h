#if !defined(AFX_NDLG_H__BE095130_C048_40E5_807D_0F4D5356BF1D__INCLUDED_)
#define AFX_NDLG_H__BE095130_C048_40E5_807D_0F4D5356BF1D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNDlg dialog

class CDipView;
class CNDlg : public CDialog
{
// Construction
public:
	CNDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNDlg)
	enum { IDD = IDD_POINT_N };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CImage * m_image;
	CDipView *m_view;
	CDC *pDc;

	// Generated message map functions
	//{{AFX_MSG(CNDlg)
	afx_msg void OnDestroy();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NDLG_H__BE095130_C048_40E5_807D_0F4D5356BF1D__INCLUDED_)
