// TsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "dip.h"

#include "lib/cimage.h"
#include "DipProcessor.h"

#include "DipDoc.h"
#include "DipView.h"

#include "TsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTsDlg dialog


CTsDlg::CTsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTsDlg)
	m_jj = 0;
	m_jl = 0;
	m_sj1 = 0;
	m_sj2 = 0;
	m_inter = FALSE;
	//}}AFX_DATA_INIT
}


void CTsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTsDlg)
	DDX_Control(pDX, IDC_CHECK_TWO, m_two);
	DDX_Control(pDX, IDC_STATIC_TS_GRAPH, m_graph);
	DDX_Slider(pDX, IDC_SLIDER_JJ, m_jj);
	DDX_Slider(pDX, IDC_SLIDER_JL, m_jl);
	DDX_Slider(pDX, IDC_SLIDER_SJ1, m_sj1);
	DDX_Slider(pDX, IDC_SLIDER_SJ2, m_sj2);
	DDX_Check(pDX, IDC_CHECK_TWO, m_inter);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTsDlg, CDialog)
	//{{AFX_MSG_MAP(CTsDlg)
	ON_WM_DESTROY()
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTsDlg message handlers

BOOL CTsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	Reset();
	m_two.SetCheck(1);
	CDipView * m_view=CDipView::GetActiveView();
	CRect rc;
	m_graph.GetClientRect(&rc);

	CImage *pImage=m_view->GetDocument()->GetCurImage();
	CImage *temp;
	BOOL bCopy=FALSE;
	if(pImage->GetDepth()<16){
		temp=CDipProcessor::Cov_8_To_24(pImage);
		bCopy=TRUE;
	}else{
		temp=pImage;
		bCopy=FALSE;
	}
	m_bak=CDipProcessor::Sys_Size(temp,rc.Width(),rc.Height());
	m_image=CDipProcessor::Sys_Size(temp,rc.Width(),rc.Height());
	VERIFY(m_bak->IsOK());
	VERIFY(m_image->IsOK());
	m_graph.SetImage(m_image);
	if(bCopy){
		delete temp;
		temp=NULL;
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTsDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	delete m_bak;
	m_bak=NULL;
}

void CTsDlg::Reset()
{
	CString str;
	CSliderCtrl * ps;

	ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_JL);
	ps->SetRange(0,180);
	ps->SetPos(90);
	if(ps->GetPos()>90)
		str.Format("��=%.2f",ps->GetPos()*0.1f-8);
	else
		str.Format("��=%.2f",ps->GetPos()*0.01f+0.1);
	SetDlgItemText(IDC_STATIC_JL,str);
	
	ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_SJ1);
	ps->SetRange(0,360);
	ps->SetPos(270);
	str.Format("��=%d",ps->GetPos()-180);
	SetDlgItemText(IDC_STATIC_SJ1,str);
	
	ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_SJ2);
	ps->SetRange(0,180);
	ps->SetPos(90);
	str.Format("��=%d",ps->GetPos());
	SetDlgItemText(IDC_STATIC_SJ2,str);

	ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_JJ);
	ps->SetRange(0,180);
	ps->SetPos(90);
	if(ps->GetPos()>90)
		str.Format("f=%.2f",ps->GetPos()*0.1f-8);
	else
		str.Format("f=%.2f",ps->GetPos()*0.01f+0.1);
	SetDlgItemText(IDC_STATIC_JJ,str);
}

void CTsDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CSliderCtrl * ps=(CSliderCtrl*)pScrollBar;
	CString str;
	switch(pScrollBar->GetDlgCtrlID()){
	case IDC_SLIDER_JL:
		if(ps->GetPos()>90)
			str.Format("��=%.2f",ps->GetPos()*0.1f-8);
		else
			str.Format("��=%.2f",ps->GetPos()*0.01f+0.1);
		SetDlgItemText(IDC_STATIC_JL,str);
		break;
	case IDC_SLIDER_SJ1:
		str.Format("��=%d",ps->GetPos()-180);
		SetDlgItemText(IDC_STATIC_SJ1,str);
		break;
	case IDC_SLIDER_SJ2:
		str.Format("��=%d",ps->GetPos());
		SetDlgItemText(IDC_STATIC_SJ2,str);
		break;
	case IDC_SLIDER_JJ:
		if(ps->GetPos()>90)
			str.Format("f=%.2f",ps->GetPos()*0.1f-8);
		else
			str.Format("f=%.2f",ps->GetPos()*0.01f+0.1);
		SetDlgItemText(IDC_STATIC_JJ,str);
		break;
	}
	DoUpdate();
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CTsDlg::OnButtonReset() 
{
	Reset();
	CDipProcessor::CopyData(m_image,m_bak);
	m_graph.Invalidate();
}

void CTsDlg::DoUpdate()
{
	UpdateData();
	float jl,jj;
	int sj1,sj2;
	if(m_jl>90)
		jl=m_jl*0.1f-8;
	else
		jl=m_jl*0.01f+0.1f;
	sj1=m_sj1-180;
	sj2=m_sj2;
	if(m_jj>90)
		jj=m_jj*0.1f-8;
	else
		jj=m_jj*0.01f+0.1f;
	CDipProcessor::CopyData(m_image,m_bak);
	CDipProcessor::GeoTs(m_image,jl,sj1,sj2,jj,m_inter);
	m_graph.SetImage(m_image);
	m_graph.Invalidate();
}
