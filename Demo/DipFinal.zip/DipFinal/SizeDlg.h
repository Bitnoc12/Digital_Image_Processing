#if !defined(AFX_SIZEDLG_H__8D8B6101_BD42_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_SIZEDLG_H__8D8B6101_BD42_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SizeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSizeDlg dialog

class CSizeDlg : public CDialog
{
// Construction
public:
	void SetData(int width,int height);
	CSizeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	BOOL m_bCheck;
	float scale;
	//{{AFX_DATA(CSizeDlg)
	enum { IDD = IDD_DIALOG_SIZE };
	CEdit	m_width;
	CEdit	m_height;
	CButton	m_check;
	UINT	m_nHeight;
	UINT	m_nWidth;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSizeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSizeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEditWidth();
	afx_msg void OnCheckHold();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIZEDLG_H__8D8B6101_BD42_11D4_A11E_0080C8D7131C__INCLUDED_)
