// ParaDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"
#include "ParaDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CParaDlg dialog


CParaDlg::CParaDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CParaDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CParaDlg)
	m_nIndex = -1;
	m_nNumFile = 0;
	m_nStack = 0;
	//}}AFX_DATA_INIT
}


void CParaDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CParaDlg)
	DDX_CBIndex(pDX, IDC_COMBO_EXT, m_nIndex);
	DDX_Text(pDX, IDC_EDIT_FILE, m_nNumFile);
	DDX_Text(pDX, IDC_EDIT_STACK, m_nStack);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CParaDlg, CDialog)
	//{{AFX_MSG_MAP(CParaDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CParaDlg message handlers

BOOL CParaDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CSpinButtonCtrl * pSpin=(CSpinButtonCtrl *)GetDlgItem(IDC_SPIN_FILE);
	pSpin->SetRange(0,15);
	pSpin->SetPos(theApp.GetNumOpen());
	pSpin=(CSpinButtonCtrl *)GetDlgItem(IDC_SPIN_STACK);
	pSpin->SetRange(0,30);
	pSpin->SetPos(theApp.GetStackSize());
	CComboBox *pCombo=(CComboBox *)GetDlgItem(IDC_COMBO_EXT);
	pCombo->SetCurSel(theApp.GetFilterIndex()-1);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
