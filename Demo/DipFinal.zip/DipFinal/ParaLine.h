#if !defined(AFX_PARALINE_H__6EAD5608_B494_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_PARALINE_H__6EAD5608_B494_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ParaLine.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CParaLine window
typedef enum
{
	A,
	B,
	NO
} eType;

class CParaLine : public CStatic
{
// Construction
public:
	CParaLine();

// Attributes
public:

// Operations
public:
	void GetPoint(CPoint &x,CPoint &y);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CParaLine)
	//}}AFX_VIRTUAL

// Implementation
public:
	void init();
	virtual ~CParaLine();

	// Generated message map functions
protected:
	//{{AFX_MSG(CParaLine)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	enum{_W=5,_H=5};
	BOOL m_bCaptured;
    CPoint a;
	CPoint b;
	eType m_selected;
	int width,w;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARALINE_H__6EAD5608_B494_11D4_A11E_0080C8D7131C__INCLUDED_)
