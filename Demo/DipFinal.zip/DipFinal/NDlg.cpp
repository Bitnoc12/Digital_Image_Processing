// NDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"

#include "lib/cimage.h"
#include "DipProcessor.h"

#include "DipDoc.h"
#include "DipView.h"
#include "NDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNDlg dialog


CNDlg::CNDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_image=NULL;
	m_view=NULL;
}


void CNDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNDlg, CDialog)
	//{{AFX_MSG_MAP(CNDlg)
	ON_WM_DESTROY()
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNDlg message handlers

void CNDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	delete m_image;
	m_image=NULL;
	m_view->ReleaseCurDC(pDc);
}

void CNDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);

	CDipProcessor::CopyData(m_view->GetDocument()->GetCurImage(),m_image);
	CString str;
	CSliderCtrl * ps=(CSliderCtrl*)pScrollBar;
	str.Format("%d",ps->GetPos());
	SetDlgItemText(IDC_STATIC_N,str);
	CDipProcessor::SetNColor(m_view->GetDocument()->GetCurImage(),ps->GetPos());
	m_view->ReDraw(pDc);
}

BOOL CNDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CString str;
	CSliderCtrl * ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_N);
	ps->SetRange(2,127);
	ps->SetPos(2);
	str.Format("%d",ps->GetPos());
	SetDlgItemText(IDC_STATIC_N,str);

	m_view=CDipView::GetActiveView();
	pDc=m_view->GetCurDC();

	m_image=new CImage(m_view->GetDocument()->GetCurImage());
	CDipProcessor::CopyData(m_image,m_view->GetDocument()->GetCurImage());
	VERIFY(m_image->IsOK());
	CDipProcessor::SetNColor(m_view->GetDocument()->GetCurImage(),ps->GetPos());
	m_view->ReDraw(pDc);
	return 	true;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
