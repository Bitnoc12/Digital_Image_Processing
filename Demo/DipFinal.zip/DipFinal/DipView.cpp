// DipView.cpp : implementation of the CDipView class
//

#include "stdafx.h"
#include "Dip.h"
#include "MainFrm.h"
#include "ChildFrm.h"

#include "lib/cimage.h"
#include "DipProcessor.h"
#include "UnDo.h"

#include "DipDoc.h"
#include "DipView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDipView

IMPLEMENT_DYNCREATE(CDipView, CScrollView)

BEGIN_MESSAGE_MAP(CDipView, CScrollView)
	//{{AFX_MSG_MAP(CDipView)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_COMMAND(ID_SELECT_ALL, OnSelectAll)
	ON_COMMAND(ID_SELECT_CANCAL, OnSelectCancal)
	ON_UPDATE_COMMAND_UI(ID_SELECT_CANCAL, OnUpdateSelectCancal)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDipView construction/destruction

CDipView::CDipView()
{
	SetScrollSizes(MM_TEXT, CSize(0, 0));
	m_topX = 0;
	m_topY = 0;
	m_bDrawingRubber = FALSE;
	m_nDrawType = DT_SELECT;
}

CDipView::~CDipView()
{
}

BOOL CDipView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDipView drawing

void CDipView::OnDraw(CDC* dc)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
	CPoint pos(GetScrollPosition());
	CRect rect;
	GetClientRect(&rect);
	int width = rect.right - rect.left;
	int height = rect.bottom - rect.top;

	if (image)
	{
		int x =-pos.x;
		int y =-pos.y;
		if (width >= image->GetWidth())
			x = (width - image->GetWidth())/2;
		if (height >= image->GetHeight())
			y = (height - image->GetHeight())/2;

		CPalette *hOldPal = 0;
		if (image->GetPalette())
		{
			hOldPal = dc->SelectPalette(image->GetPalette(), TRUE);
			dc->RealizePalette();
		}

		if (pDoc->GetStretchMode())
		{
			m_topX = 0;
			m_topY = 0;
			SetScrollSizes(MM_TEXT,CSize(0,0));
			image->Stretch(dc, 0, 0, width, height);
		}
		else
		{
			m_topX = x>0?x:0;
			m_topY = y>0?y:0;
			SetScrollSizes(MM_TEXT,CSize(image->GetWidth(), image->GetHeight()));
			image->Draw(dc, x, y);
		}
		if (image->GetPalette())
			dc->SelectPalette(hOldPal,TRUE);
	}
}

void CDipView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
	if (image){
		SetScrollSizes(MM_TEXT,
		  CSize(image->GetWidth(), image->GetHeight()));
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDipView diagnostics

#ifdef _DEBUG
void CDipView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CDipView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CDipDoc* CDipView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDipDoc)));
	return (CDipDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDipView message handlers

void CDipView::OnMouseMove(UINT nFlags, CPoint point) 
{
	static char s[80];
	byte r = 0, g = 0, b = 0;
	float x =(float) point.x;
	float y =(float) point.y;
	
	CPoint pos(GetScrollPosition());
	x += pos.x;
	y += pos.y;

	x -= m_topX;
	y -= m_topY;

	CRect rect;
	GetClientRect(&rect);
	int width = rect.right - rect.left;
	int height = rect.bottom - rect.top;

	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
    if (!image)
		return;
	
	if (pDoc->GetStretchMode())
	{
		x *= image->GetWidth()/(float)width;
		y *= image->GetHeight()/(float)height;
	}
	if (image->Inside((int)x, (int)y))
	{
		sprintf(s,"XY:%.0f,%.0f", x, y);
		if (image->GetRGB((int)x, (int)(image->GetHeight() - y), &r, &g, &b))
			sprintf(&s[strlen(s)]," RGB:%d,%d,%d", r, g, b);
	} else strcpy(s," ");
	
	CStatusBar& statusBar = ((CMainFrame *)(AfxGetApp()->m_pMainWnd))->GetStatusBar();
	statusBar.SetPaneText(PANE_POS_RGB, s);
	CRect rect1;
	statusBar.GetItemRect(PANE_RGB_COLOR,&rect1);
	CRect size(-1,-1,-1,-1);
	rect1+=&size;
	CDC *pDc=statusBar.GetDC();
	pDc->FillSolidRect(&rect1,RGB(r,g,b));
	ReleaseDC(pDc);
	// change rectangle
	if (m_bDrawingRubber)
		DrawRubber(point);
	CScrollView::OnMouseMove(nFlags, point);
}

void CDipView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (PointInDib(point))
	{
		MergeFloatDib();

		// if ther is text, just merge it into DIB
//		if (! MergeText())	// else, do paint
//		{
				// start draw rectangle
				StartDrawRubber(point);
				m_bDrawingRubber = TRUE;
//		}
	}

	CScrollView::OnLButtonDown(nFlags, point);
}

void CDipView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();

	if (m_bDrawingRubber)
	{
		StopDrawRubber();
		m_bDrawingRubber = FALSE;

		if (! m_rcClip.IsRectEmpty())
		{
			// adjust position with scroll position
			CRect rcInDib(m_rcClip);
			ClientToDib(rcInDib);
					
			CImage *pImage=CDipProcessor::GetPart(image,rcInDib.left,image->GetHeight()-rcInDib.bottom,rcInDib.Width(),rcInDib.Height());
			CreateFloatWnd(pImage, m_rcClip.TopLeft());
		}
	}
	CScrollView::OnLButtonUp(nFlags, point);
}

void CDipView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	SetStatus();
	Invalidate();
}
void CDipView::DoDrawRubber(CDC *pDC, CRect rc)
{
	if (rc.IsRectEmpty())
		return;

	// draw 
	switch(m_nDrawType)
	{
	case DT_SELECT:
	//case DT_TEXT:
		pDC->Rectangle(&rc);
		break;
	}
}

void CDipView::StartDrawRubber(CPoint point)
{
	// save current mouse position
	ClientToDib(point);
	m_ptStart = point;

	// empty current rectangle
	m_rcClip.SetRectEmpty();
	m_rcRubber.SetRectEmpty();

	// capture mouse
	SetCapture();
}

void CDipView::DrawRubber(CPoint point)
{
	// get DC and set its ROP
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
	CClientDC dc(this);

	// define used pen
	int nPenStyle;
	int nPenWidth;
	COLORREF color;
	int nOldRop = dc.SetROP2(R2_NOTXORPEN);
	if (m_nDrawType == DT_SELECT )//|| m_nDrawType == DT_TEXT)
	{
		nPenStyle = PS_DOT;
		nPenWidth = 1;
		color = RGB(0,0,0);
	}
	CPen pen(nPenStyle, nPenWidth, color);
	CPen* pOldPen = dc.SelectObject(&pen);

	// if there is rectangle drawn, clear it
	DoDrawRubber(&dc, m_rcRubber);

	// Adjust cooridnates for select
	if (m_nDrawType == DT_SELECT)
	{
		// get current scroll pos
		int nScrollX = GetScrollPos(SB_HORZ);
		int nScrollY = GetScrollPos(SB_VERT);
		// calculate new scroll pos, and set it
		CRect rcClient;
		GetClientRect(&rcClient);
		int nMinX, nMaxX, nMinY, nMaxY;
		GetScrollRange(SB_HORZ, &nMinX, &nMaxX);
		GetScrollRange(SB_VERT, &nMinY, &nMaxY);
		BOOL bNeedRedraw = FALSE;
		if ((rcClient.Width() < image->GetWidth()) &&
			(point.x < 0 || point.x > rcClient.right))
		{
			nScrollX += point.x;
			nScrollX = BOUND(nScrollX, nMinX, nMaxX);
			SetScrollPos(SB_HORZ, nScrollX);
			bNeedRedraw = TRUE;
		}
		if ((rcClient.Height() < image->GetHeight()) &&
			(point.y < 0 || point.y > rcClient.bottom))
		{
			nScrollY += point.y;
			nScrollY = BOUND(nScrollY, nMinY, nMaxY);
			SetScrollPos(SB_VERT, nScrollY);
			bNeedRedraw = TRUE;
		}
		if (bNeedRedraw)
		{
			// redraw
			Invalidate(FALSE);
			UpdateWindow();
		}
		// normalize point coordinate
		if (AdjustPointinDib(point))
		{
			ClientToScreen(&point);
			SetCursorPos(point.x, point.y);
			ScreenToClient(&point);
		}
	}

	// use client coordinates
	CPoint ptStart(m_ptStart);
	DibToClient(ptStart);
	// set new rectangle
	if (point.x < ptStart.x)
	{
		m_rcRubber.left = point.x;
		m_rcRubber.right = ptStart.x;
	}	
	else
	{
		m_rcRubber.left = ptStart.x;
		m_rcRubber.right = point.x;
	}
	if (point.y < ptStart.y)
	{
		m_rcRubber.top = point.y;
		m_rcRubber.bottom = ptStart.y;
	}
	else
	{
		m_rcRubber.top = ptStart.y;
		m_rcRubber.bottom = point.y;
	}
	m_rcRubber.NormalizeRect();

	// draw new rectangle
	DoDrawRubber(&dc, m_rcRubber);

	// restore
	dc.SelectObject(pOldPen);
	dc.SetROP2(nOldRop);
}

void CDipView::StopDrawRubber()
{
	if (m_nDrawType == DT_SELECT)// || m_nDrawType == DT_TEXT)
	{
		m_rcClip = m_rcRubber;

		// if there is rectangle drawn, clear it
		if (! m_rcClip.IsRectEmpty())
		{
			// get DC and set its ROP
			CClientDC dc(this);
			int OldRop = dc.SetROP2(R2_NOTXORPEN);
			// define used pen
			CPen pen(PS_DOT, 1, RGB(0,0,0));
			CPen* pOldPen = dc.SelectObject(&pen);
			
			// draw to clear
			DoDrawRubber(&dc, m_rcClip);
		
			// restore
			dc.SetROP2(OldRop);
			dc.SelectObject(pOldPen);
		}
		/*
		if (m_nDrawType == DT_TEXT)
		{
			// empty clip area 
			m_rcClip.SetRectEmpty();

			CRect rc = m_rcRubber;

			CClientDC dc(this);
			CFont *pOldFont = dc.SelectObject(m_pFont);
			CRect rcLetter(0,0,1,1);
			int nHeight = dc.DrawText(_T("��"),&rcLetter, DT_CALCRECT);
			int nWidth = 4*rcLetter.Width();
			dc.SelectObject(pOldFont);

			if (rc.Height() < nHeight)
				rc.bottom = rc.top + nHeight;
			if (rc.Width() < nWidth)
				rc.right = rc.left + nWidth;
			ClientToDib(rc);
			if (rc.bottom > m_image->GetHeight())
				rc.bottom = m_image->GetHeight();
			if (rc.right > m_image->GetWidth())
				rc.right = m_image->GetWidth();
			DibToClient(rc);

			DWORD style = ES_LEFT;
			if (m_nTextAlign == DT_LEFT)
				style = ES_LEFT;
			else if (m_nTextAlign == DT_CENTER)
				style = ES_CENTER;
			else if (m_nTextAlign == DT_RIGHT)
				style = ES_RIGHT;
			m_EditText.Create(style|WS_VISIBLE|WS_CHILD|ES_MULTILINE, 
						  rc, 
						  this, 
						  IDC_EDIT);
			rc.InflateRect(2,2);
			InvalidateRect(&rc);
			m_EditText.SetFont(m_pFont);
			m_EditText.SetFocus();
		}*/
	}
//	Invalidate(FALSE);
	ReleaseCapture();	
}
void CDipView::ClientToDib(CPoint& point)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
	if(!image)
		return;
	CPoint pos(GetScrollPosition());

	point.x += pos.x;
	point.y += pos.y;

	point.x -= m_topX;
	point.y -= m_topY;
	CRect rect;
	GetClientRect(&rect);
	int width = rect.right - rect.left;
	int height = rect.bottom - rect.top;
	if (pDoc->GetStretchMode())
	{
		point.x=long(point.x*image->GetWidth()/(float)width);
		point.y=long(point.y*image->GetHeight()/(float)height);
	}
}

void CDipView::ClientToDib(CRect& rect)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
	if(!image)
		return;
	CPoint pos(GetScrollPosition());

	rect.left += pos.x;
	rect.top += pos.y;
	rect.right += pos.x;
	rect.bottom += pos.y;

	rect.left -= m_topX;
	rect.top -= m_topY;
	rect.right -= m_topX;
	rect.bottom -= m_topY;

	CRect trect;
	GetClientRect(&trect);
	int width = trect.right - trect.left;
	int height = trect.bottom - trect.top;
	float xs=image->GetWidth()/(float)width,ys=image->GetHeight()/(float)height;
	if (pDoc->GetStretchMode())
	{
		rect.left=long(xs*rect.left);
		rect.top=long(ys*rect.top);
		rect.right=long(xs*rect.right);
		rect.bottom=long(ys*rect.bottom);
	}
}

void CDipView::DibToClient(CPoint& point)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
	if(!image)
		return;
	CRect rect;
	GetClientRect(&rect);
	int width = rect.right - rect.left;
	int height = rect.bottom - rect.top;
	if (pDoc->GetStretchMode())
	{
		point.x=long(point.x*width/(float)image->GetWidth());
		point.y=long(point.y*height/(float)image->GetHeight());
	}

	CPoint pos(GetScrollPosition());

	point.x -= pos.x;
	point.y -= pos.y;

	point.x += m_topX;
	point.y += m_topY;
}

void CDipView::DibToClient(CRect& rect)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
	if(!image)
		return;
	CRect trect;
	GetClientRect(&trect);
	int width = trect.right - trect.left;
	int height = trect.bottom - trect.top;
	float xs=width/(float)image->GetWidth(),ys=height/(float)image->GetHeight();
	if (pDoc->GetStretchMode())
	{
		rect.left=long(xs*rect.left);
		rect.top=long(ys*rect.top);
		rect.right=long(xs*rect.right);
		rect.bottom=long(ys*rect.bottom);
	}

	CPoint pos(GetScrollPosition());

	rect.left -= pos.x;
	rect.top -= pos.y;
	rect.right -= pos.x;
	rect.bottom -= pos.y;

	rect.left += m_topX;
	rect.top += m_topY;
	rect.right += m_topX;
	rect.bottom += m_topY;
}

BOOL CDipView::AdjustPointinDib(CPoint& point)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();
	int nWidth = image->GetWidth();
	int nHeight = image->GetHeight();
	BOOL bOut = FALSE;

	ClientToDib(point);
	if (point.x < 0)
	{
		point.x = 0;
		bOut = TRUE;
	}
	else if (point.x >= nWidth)
	{
		point.x = nWidth;
		bOut = TRUE;
	}
	if (point.y < 0)
	{
		point.y = 0;
		bOut = TRUE;
	}
	else if (point.y >= nHeight)
	{
		point.y = nHeight;
		bOut = TRUE;
	}
	DibToClient(point);

	return bOut;
}

BOOL CDipView::PointInDib(CPoint point)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CImage *image=pDoc->GetImage();

	if (!image->IsOK())
		return FALSE;

	ClientToDib(point);
	CRect rcDib(0, 0, image->GetWidth(), image->GetWidth());
	return rcDib.PtInRect(point);
}

void CDipView::CreateFloatWnd(CImage *pImage, CPoint ptTopLeft,BOOL bPaste)
{
	MergeFloatDib();
	if(!pImage){
		AfxMessageBox("xixi");
		return;
	}
	int nWidth  = pImage->GetWidth();
	int nHeight = pImage->GetHeight();

	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	if(pDoc->GetStretchMode()){
		CRect rc;
		GetClientRect(&rc);
		nWidth=int(float(rc.Width()*nWidth)/float(pDoc->GetImage()->GetWidth()));
		nHeight=int(float(rc.Height()*nHeight)/float(pDoc->GetImage()->GetHeight()));
	}
	CRect rc(ptTopLeft.x, ptTopLeft.y, ptTopLeft.x+nWidth, ptTopLeft.y+nHeight);
	pDoc->FloatCreat(pImage,rc, this,bPaste);
}

void CDipView::MergeFloatDib()
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CFloatDibWnd *pFloat=pDoc->GetFloat();
	if (pFloat)
	{
		if(pFloat->Paste()){
			pDoc->Save();
		}else{
			if(pFloat->NotMove()){
				if(!pDoc->CanPop()){
					pDoc->FloatDeleteWnd();
					return;
				}else{
					pDoc->Save();
				}
			}
		}
		CRect rc;
		pFloat->GetWindowRect(&rc);
		CPoint t;
		t.x=rc.left;
		t.y=rc.bottom;
		ScreenToClient(&t);
		ClientToDib(t);
		CDipProcessor::MergePart(pDoc->GetImage(),pDoc->GetCurImage(),t.x,pDoc->GetImage()->GetHeight()-t.y);
		pDoc->FloatDeleteWnd();
		pDoc->SetModifiedFlag();
		m_rcClip.SetRectEmpty();
		SetStatus();
	}
}

void CDipView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView) 
{
	if (bActivate) SetStatus();
	CScrollView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}

void CDipView::SetStatus()
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CImage *image=pDoc->GetImage();
	CStatusBar& statusBar = ((CMainFrame *)(AfxGetApp()->m_pMainWnd))->GetStatusBar();
	CString s;
	s.Format("%dx%d",image->GetWidth(),image->GetHeight());
	statusBar.SetPaneText(PANE_IMAGE_SIZE, s);
	s.Format("%dλ",image->GetDepth());
	statusBar.SetPaneText(PANE_BIT_COUNT, s);
	statusBar.SetPaneText(PANE_TYPE, pDoc->GetColorType()?"��ɫ":"�Ҷ�");
}
void CDipView::CutSelectedRect()
{
	if (! m_rcClip.IsRectEmpty())
	{
		CRect rcInDib(m_rcClip);
		ClientToDib(rcInDib);
		CDipDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		
		pDoc->Save();
		CDipProcessor::CutPart(pDoc->GetImage(),rcInDib.left,pDoc->GetImage()->GetHeight()-rcInDib.bottom,rcInDib.Width(),rcInDib.Height());
		pDoc->SetModifiedFlag();
		m_rcClip.SetRectEmpty();
		Invalidate();
	}
}


CDipView * CDipView::GetActiveView()
{
	CMainFrame *pFrame=(CMainFrame *)(AfxGetApp()->GetMainWnd());
	CChildFrame *pChild=(CChildFrame *)pFrame->GetActiveFrame();
	VERIFY(pChild->GetActiveView()->IsKindOf(RUNTIME_CLASS(CDipView)));
	return (CDipView *)pChild->GetActiveView();
}

BOOL CDipView::OnPreparePrinting(CPrintInfo* pInfo) 
{
	return DoPreparePrinting(pInfo);	
}

void CDipView::OnPaint() 
{
	CPaintDC dc(this);
	OnDraw(&dc);	
}

void CDipView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CScrollView::OnBeginPrinting(pDC, pInfo);
}

void CDipView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CScrollView::OnEndPrinting(pDC, pInfo);
}

void CDipView::ReDraw(CDC *pDc)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->NotFloat()){
		OnDraw(pDc);
	}else{
		pDoc->GetFloat()->OnDraw(pDc);
	}
}

CDC * CDipView::GetCurDC()
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->NotFloat()){
		return GetDC();
	}else{
		return pDoc->GetFloat()->GetDC();
	}
}

void CDipView::ReleaseCurDC(CDC *pDc)
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->NotFloat()){
		ReleaseDC(pDc);
	}else{
		pDoc->GetFloat()->ReleaseDC(pDc);
	}
}

void CDipView::CopyToClipboard()
{
	if (OpenClipboard())
	{
		EmptyClipboard();

		HANDLE hDib;
	//	HBITMAP hBitmap;
		CDipDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		CImage *image=pDoc->GetCurImage();
		
		hDib = CDipProcessor::ImageToDIB(image);
		//hBitmap = CDipProcessor::ImageToDDB(image);
	
		if(SetClipboardData(CF_DIB, hDib)==NULL)
			AfxMessageBox("���а����ʧ��!");
	//	SetClipboardData(CF_BITMAP, hBitmap);
		CloseClipboard();
	}
}

void CDipView::OnEditCopy() 
{
	CopyToClipboard();
}

BOOL CDipView::PasteDibFromClipboard()
{
	HANDLE p;
	BITMAPINFO *hNewDIB = NULL;

	if (OpenClipboard())
	{
		if (IsClipboardFormatAvailable(CF_DIB))
			p = (CDipProcessor::CopyHandle(GetClipboardData(CF_DIB)));
		CloseClipboard();
	}
	hNewDIB= (BITMAPINFO *)GlobalLock(p);

	if (hNewDIB == NULL)
		return FALSE;
	CImage *image=new CImage;
	int width=hNewDIB->bmiHeader.biWidth;
	int height=hNewDIB->bmiHeader.biHeight;
	int bits=hNewDIB->bmiHeader.biBitCount;
	image->Create(width,height,bits);
	CDipProcessor::CopyData(image,hNewDIB);
	
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CImage *pImage=pDoc->GetCurImage();
	if(!pImage){
		pImage=image;
	}else{
		MergeFloatDib();
		CreateFloatWnd(image, CPoint(0, 0),TRUE);
	}
	GlobalUnlock(p);
	GlobalFree(p);
	return TRUE;
}

BOOL CDipView::PasteDDBFromClipboard()
{
	HBITMAP hNewDDB = NULL;
	if (OpenClipboard())
	{
		if (IsClipboardFormatAvailable(CF_BITMAP))
			hNewDDB = (HBITMAP)GetClipboardData(CF_BITMAP);
		CloseClipboard();
	}
	if (hNewDDB == NULL)
		return FALSE;
	CBitmap *bitmap = new CBitmap;
	bitmap->Attach(hNewDDB);
	CImage *image=new CImage(bitmap);
	bitmap->Detach();
	delete bitmap;
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CImage *pImage=pDoc->GetCurImage();
	if(!pImage){
		pImage=image;
	}else{
		MergeFloatDib();
		CreateFloatWnd(image, CPoint(0, 0),TRUE);
	}
	return TRUE;
}

void CDipView::Cut()
{
	CopyToClipboard();
	Delete();
}

void CDipView::Delete()
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(!pDoc->NotFloat()){
		CutSelectedRect();
		pDoc->FloatDeleteWnd();
	}
}

void CDipView::OnEditCut() 
{
	Cut();
}

void CDipView::OnEditPaste() 
{
	if(!PasteDibFromClipboard())
		PasteDDBFromClipboard();
}

void CDipView::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetDocument()->NotFloat());
}

void CDipView::OnUpdateEditCut(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetDocument()->NotFloat());
}

void CDipView::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(IsClipboardFormatAvailable(CF_BITMAP));//||IsClipboardFormatAvailable(CF_DIB));
}


void CDipView::OnSelectAll() 
{
	CDipDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->NotFloat()){
		CImage *image=pDoc->GetImage();
		m_rcClip.SetRect(0,0,image->GetWidth(),image->GetHeight());
		DibToClient(m_rcClip);
		CImage *pImage=CDipProcessor::GetPart(image,0,0,image->GetWidth(),image->GetHeight());
		CreateFloatWnd(pImage,m_rcClip.TopLeft());
	}	
}

void CDipView::OnSelectCancal() 
{
	MergeFloatDib();
}

void CDipView::OnUpdateSelectCancal(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetDocument()->NotFloat());
}
