// UnDo.h: interface for the CUnDo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UNDO_H__2C5F3106_A7A7_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_UNDO_H__2C5F3106_A7A7_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CImage;
class UnDoItem{
public:
	UnDoItem *m_next;
	CImage * m_data;
	BOOL m_bColor;
	BOOL m_bmodify;
	BOOL m_bfloat;
	UnDoItem(BOOL color,BOOL modify,CImage *pImage=NULL,BOOL bfloat=FALSE);
	~UnDoItem();
};
class CUnDo
{
public:
	void UpDate();
	BOOL GetPerModify(BOOL &b,BOOL &c);
	BOOL ClearFloat(BOOL &modify);
	CUnDo();
	void Add(CImage *pImage,BOOL color,BOOL modify,BOOL bfloat);
	void UnDo(CImage *&pImage,BOOL &color,BOOL &modify);
	void Clear();
	BOOL CanUnDo(){return theApp.GetStackSize()>0 && m_len>0;};
	BOOL GetFloat(){return m_len>0&&m_first->m_next->m_bfloat;};
	virtual ~CUnDo();
protected:
	int m_len;
	UnDoItem *m_first;
};

#endif // !defined(AFX_UNDO_H__2C5F3106_A7A7_11D4_A11E_0080C8D7131C__INCLUDED_)
