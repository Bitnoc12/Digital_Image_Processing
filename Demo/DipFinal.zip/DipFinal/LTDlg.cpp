// LTDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"

#include "lib/cimage.h"
#include "DipProcessor.h"

#include "DipDoc.h"
#include "DipView.h"
#include "LTDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLTDlg dialog


CLTDlg::CLTDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLTDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLTDlg)
	m_nCon = 0;
	m_nGray = 0;
	//}}AFX_DATA_INIT
}


void CLTDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLTDlg)
	DDX_Control(pDX, IDC_SLIDER_GRAY, m_gray);
	DDX_Control(pDX, IDC_SLIDER_CON, m_con);
	DDX_Control(pDX, IDC_STATIC_LINE_VIEW, m_line);
	DDX_Slider(pDX, IDC_SLIDER_CON, m_nCon);
	DDX_Slider(pDX, IDC_SLIDER_GRAY, m_nGray);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLTDlg, CDialog)
	//{{AFX_MSG_MAP(CLTDlg)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLTDlg message handlers

BOOL CLTDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_gray.SetRange(0,1020);
	m_gray.SetPos(510);
	m_con.SetRange(0,200);
	m_con.SetPos(100);
	CDipView * m_view=CDipView::GetActiveView();
	CRect rc;
	m_line.GetClientRect(&rc);
	m_bak=CDipProcessor::Sys_Size(m_view->GetDocument()->GetCurImage(),rc.Width(),rc.Height());
	m_image=CDipProcessor::Sys_Size(m_view->GetDocument()->GetCurImage(),rc.Width(),rc.Height());
	VERIFY(m_bak->IsOK());
	VERIFY(m_image->IsOK());
	m_line.SetImage(m_image);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CLTDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);	
	float b=float(m_gray.GetPos()-510)/512,a=float(m_con.GetPos())/100;
	CDipProcessor::CopyData(m_image,m_bak);
	CDipProcessor::PointLine(m_image,a,m_gray.GetPos()-510);
	m_line.Invalidate();
}

void CLTDlg::OnButtonReset() 
{
	m_gray.SetPos(510);
	m_con.SetPos(100);
	CDipProcessor::CopyData(m_image,m_bak);
	m_line.Invalidate();
}

void CLTDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	delete m_bak;
	m_bak=0;
}
