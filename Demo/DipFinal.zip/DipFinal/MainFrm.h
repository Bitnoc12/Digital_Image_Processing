// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__F20EB2A9_A477_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_MAINFRM_H__F20EB2A9_A477_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define PANE_OTHER    		    0
#define PANE_RGB_COLOR		    1
#define PANE_POS_RGB	        2
#define PANE_IMAGE_SIZE			3
#define PANE_BIT_COUNT			4
#define PANE_TYPE    		    5
#define PANE_CAP    		    6
#define PANE_NUM    		    7
#define PANE_SCRL    		    8

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	inline CStatusBar&	GetStatusBar() { return m_wndStatusBar; }

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnWindowNew();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__F20EB2A9_A477_11D4_A11E_0080C8D7131C__INCLUDED_)
