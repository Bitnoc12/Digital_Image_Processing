// DipView.h : interface of the CDipView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DIPVIEW_H__F20EB2AF_A477_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_DIPVIEW_H__F20EB2AF_A477_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define DT_SELECT			0

//#include "FloatDibWnd.h"

class CDipView : public CScrollView
{
protected: // create from serialization only
	CDipView();
	DECLARE_DYNCREATE(CDipView)

// Attributes
public:
	CDipDoc* GetDocument();
// Operations
public:
	void	StartDrawRubber(CPoint point);
	void	DrawRubber(CPoint point);
	void	StopDrawRubber();
	void	DoDrawRubber(CDC *pDC, CRect rc);
	void	ClientToDib(CPoint& point);
	void	ClientToDib(CRect& rect);
	void	DibToClient(CPoint& point);
	void	DibToClient(CRect& rect);
	BOOL	AdjustPointinDib(CPoint& point);
	BOOL	PointInDib(CPoint point);
	void	CreateFloatWnd(CImage *pImage, CPoint ptTopLeft,BOOL bPaste=FALSE);
	void	MergeFloatDib();
	void	CutSelectedRect();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDipView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	void Delete();
	void Cut();
	BOOL PasteDDBFromClipboard();
	BOOL PasteDibFromClipboard();
	void CopyToClipboard();
	void ReleaseCurDC(CDC *pDc);
	CDC * GetCurDC();
	void ReDraw(CDC *pDc);
	static CDipView * GetActiveView();
	void SetStatus();
	virtual ~CDipView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	int m_topX;
	int m_topY;
//	CFloatDibWnd* m_pFloatWnd;
	CRect	m_rcClip;
	CRect	m_rcRubber;
	CPoint	m_ptStart;
	BOOL	m_bDrawingRubber;
	int		m_nDrawType;

// Generated message map functions
protected:
	//{{AFX_MSG(CDipView)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnEditPaste();
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnEditCut();
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	afx_msg void OnSelectAll();
	afx_msg void OnSelectCancal();
	afx_msg void OnUpdateSelectCancal(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DipView.cpp
inline CDipDoc* CDipView::GetDocument()
   { return (CDipDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIPVIEW_H__F20EB2AF_A477_11D4_A11E_0080C8D7131C__INCLUDED_)
