// GraphStatic.cpp : implementation file
//

#include "stdafx.h"
#include "dip.h"

#include "lib/cimage.h"

#include "GraphStatic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGraphStatic

CGraphStatic::CGraphStatic()
{
	m_image=NULL;
}

CGraphStatic::~CGraphStatic()
{
}


BEGIN_MESSAGE_MAP(CGraphStatic, CStatic)
	//{{AFX_MSG_MAP(CGraphStatic)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGraphStatic message handlers

void CGraphStatic::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	if(m_image){
		CPalette *hOldPal = 0;
		if (m_image->GetPalette())
		{
			hOldPal = dc.SelectPalette(m_image->GetPalette(), TRUE);
			dc.RealizePalette();
		}
		m_image->Draw(&dc, 0, 0);
		return;
	}
	
}

void CGraphStatic::OnDestroy() 
{
	CStatic::OnDestroy();
	
	// TODO: Add your message handler code here
	delete m_image;
	m_image=NULL;
}
