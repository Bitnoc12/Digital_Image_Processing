#if !defined(AFX_AFFINEDLG_H__58085AA1_BDC0_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_AFFINEDLG_H__58085AA1_BDC0_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AffineDlg.h : header file
//
#include "GraphStatic.h"
/////////////////////////////////////////////////////////////////////////////
// CAffineDlg dialog

class CAffineDlg : public CDialog
{
// Construction
public:
	void Reset();
	CAffineDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAffineDlg)
	enum { IDD = IDD_DIALOG_AFFINE };
	CButton	m_two;
	CGraphStatic	m_graph;
	int		m_cd;
	int		m_nq;
	int		m_ss;
	int		m_xz;
	BOOL	m_inter;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAffineDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAffineDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnButtonReset();
	afx_msg void OnCheckTwo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void DoUpdate();
	CImage * m_image,* m_bak;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AFFINEDLG_H__58085AA1_BDC0_11D4_A11E_0080C8D7131C__INCLUDED_)
