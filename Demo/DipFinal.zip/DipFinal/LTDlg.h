#if !defined(AFX_LTDLG_H__B83CAEA5_EFA0_4877_9921_16C2EB0E7DDE__INCLUDED_)
#define AFX_LTDLG_H__B83CAEA5_EFA0_4877_9921_16C2EB0E7DDE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LTDlg.h : header file
//

#include "GraphStatic.h"
/////////////////////////////////////////////////////////////////////////////
// CLTDlg dialog

class CLTDlg : public CDialog
{
// Construction
public:
	CLTDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLTDlg)
	enum { IDD = IDD_DIALOG_POINTLINE };
	CSliderCtrl	m_gray;
	CSliderCtrl	m_con;
	CGraphStatic	m_line;
	int		m_nCon;
	int		m_nGray;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLTDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLTDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnButtonReset();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CImage * m_image,* m_bak;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LTDLG_H__B83CAEA5_EFA0_4877_9921_16C2EB0E7DDE__INCLUDED_)
