// AffineDlg.cpp : implementation file
//

#include "stdafx.h"
#include "dip.h"

#include "lib/cimage.h"
#include "DipProcessor.h"

#include "DipDoc.h"
#include "DipView.h"

#include "AffineDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAffineDlg dialog


CAffineDlg::CAffineDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAffineDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAffineDlg)
	m_cd = 0;
	m_nq = 0;
	m_ss = 0;
	m_xz = 0;
	m_inter = FALSE;
	//}}AFX_DATA_INIT
}


void CAffineDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAffineDlg)
	DDX_Control(pDX, IDC_CHECK_TWO, m_two);
	DDX_Control(pDX, IDC_STATIC_AFFINE_GRAPH, m_graph);
	DDX_Slider(pDX, IDC_SLIDER_CD, m_cd);
	DDX_Slider(pDX, IDC_SLIDER_NQ, m_nq);
	DDX_Slider(pDX, IDC_SLIDER_SS, m_ss);
	DDX_Slider(pDX, IDC_SLIDER_XZ, m_xz);
	DDX_Check(pDX, IDC_CHECK_TWO, m_inter);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAffineDlg, CDialog)
	//{{AFX_MSG_MAP(CAffineDlg)
	ON_WM_DESTROY()
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	ON_BN_CLICKED(IDC_CHECK_TWO, OnCheckTwo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAffineDlg message handlers

BOOL CAffineDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	Reset();
	m_two.SetCheck(1);
	CDipView * m_view=CDipView::GetActiveView();
	CRect rc;
	m_graph.GetClientRect(&rc);

	CImage *pImage=m_view->GetDocument()->GetCurImage();
	CImage *temp;
	BOOL bCopy=FALSE;
	if(pImage->GetDepth()<16){
		temp=CDipProcessor::Cov_8_To_24(pImage);
		bCopy=TRUE;
	}else{
		temp=pImage;
		bCopy=FALSE;
	}
	m_bak=CDipProcessor::Sys_Size(temp,rc.Width(),rc.Height());
	m_image=CDipProcessor::Sys_Size(temp,rc.Width(),rc.Height());
	VERIFY(m_bak->IsOK());
	VERIFY(m_image->IsOK());
	m_graph.SetImage(m_image);
	if(bCopy){
		delete temp;
		temp=NULL;
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAffineDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	delete m_bak;
	m_bak=NULL;
}

void CAffineDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	double s=8;
	CSliderCtrl * ps=(CSliderCtrl*)pScrollBar;
	CString str;
	switch(pScrollBar->GetDlgCtrlID()){
	case IDC_SLIDER_CD:
		if(ps->GetPos()>90)
			str.Format("s=%.2f",ps->GetPos()*0.1f-8);
		else
			str.Format("s=%.2f",ps->GetPos()*0.01f+0.1);
		SetDlgItemText(IDC_STATIC_CD,str);
		break;
	case IDC_SLIDER_SS:
		if(ps->GetPos()>90)
			str.Format("t=%.2f",ps->GetPos()*0.1f-8);
		else
			str.Format("t=%.2f",ps->GetPos()*0.01f+0.1);
		SetDlgItemText(IDC_STATIC_SS,str);
		break;
	case IDC_SLIDER_NQ:
		str.Format("u=%.2f",ps->GetPos()*0.01f-1);
		SetDlgItemText(IDC_STATIC_NQ,str);
		break;
	case IDC_SLIDER_XZ:
		str.Format("��=%.2f",ps->GetPos()/s-180);
		SetDlgItemText(IDC_STATIC_XZ,str);
		break;
	}
	DoUpdate();
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CAffineDlg::OnButtonReset() 
{
	Reset();
	CDipProcessor::CopyData(m_image,m_bak);
	m_graph.Invalidate();
}

void CAffineDlg::Reset()
{
	CString str;
	CSliderCtrl * ps;

	ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_CD);
	ps->SetRange(0,180);
	ps->SetPos(90);
	if(ps->GetPos()>90)
		str.Format("s=%.2f",ps->GetPos()*0.1f-8);
	else
		str.Format("s=%.2f",ps->GetPos()*0.01f+0.1);
	SetDlgItemText(IDC_STATIC_CD,str);
	
	ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_SS);
	ps->SetRange(0,180);
	ps->SetPos(90);
	if(ps->GetPos()>90)
		str.Format("t=%.2f",ps->GetPos()*0.1f-9);
	else
		str.Format("t=%.2f",ps->GetPos()*0.01f+0.1);
	SetDlgItemText(IDC_STATIC_SS,str);

	ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_NQ);
	ps->SetRange(0,200);
	ps->SetPos(100);
	str.Format("u=%.2f",ps->GetPos()*0.01f-1);
	SetDlgItemText(IDC_STATIC_NQ,str);
	
	int s = 8;
	ps=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_XZ);
	ps->SetRange(0,360*s);
	ps->SetPos(180*s);
	str.Format("��=%d",ps->GetPos()/s-180);
	SetDlgItemText(IDC_STATIC_XZ,str);
}

void CAffineDlg::OnCheckTwo() 
{
	DoUpdate();
}

void CAffineDlg::DoUpdate()
{
	UpdateData();
	float cd,ss,nq;
	float xz;
	if(m_cd>90)
		cd=m_cd*0.1f-8;
	else
		cd=m_cd*0.01f+0.1f;
	if(m_ss>90)
		ss=m_ss*0.1f-8;
	else
		ss=m_ss*0.01f+0.1f;
	nq=m_nq*0.01f-1;
	xz=m_xz/8.0f-180;
	CDipProcessor::CopyData(m_image,m_bak);
	CDipProcessor::GeoAffine(m_image,cd,ss,nq,xz,m_inter);
	m_graph.SetImage(m_image);
	m_graph.Invalidate();
}
