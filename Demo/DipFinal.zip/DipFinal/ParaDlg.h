#if !defined(AFX_PARADLG_H__B0544E07_A9A5_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_PARADLG_H__B0544E07_A9A5_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ParaDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CParaDlg dialog

class CParaDlg : public CDialog
{
// Construction
public:
	CParaDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CParaDlg)
	enum { IDD = IDD_DIALOG_PARAMETER };
	int		m_nIndex;
	UINT	m_nNumFile;
	UINT	m_nStack;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CParaDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CParaDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARADLG_H__B0544E07_A9A5_11D4_A11E_0080C8D7131C__INCLUDED_)
