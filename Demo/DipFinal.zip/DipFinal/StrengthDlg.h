#if !defined(AFX_STRENGTHDLG_H__0B3584A1_BFF0_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_STRENGTHDLG_H__0B3584A1_BFF0_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StrengthDlg.h : header file
//
#include "GraphStatic.h"
/////////////////////////////////////////////////////////////////////////////
// CStrengthDlg dialog

class CStrengthDlg : public CDialog
{
// Construction
public:
	void SetFilter(int nFilter){m_filter=nFilter;};
	CStrengthDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CStrengthDlg)
	enum { IDD = IDD_DIALOG_STRENGTH };
	CGraphStatic	m_graph;
	int		m_strength;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStrengthDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CStrengthDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CImage * m_image,* m_bak;
	int m_filter;
	BOOL m_color;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STRENGTHDLG_H__0B3584A1_BFF0_11D4_A11E_0080C8D7131C__INCLUDED_)
