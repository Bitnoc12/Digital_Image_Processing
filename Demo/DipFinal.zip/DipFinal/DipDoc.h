// DipDoc.h : interface of the CDipDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DIPDOC_H__F20EB2AD_A477_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_DIPDOC_H__F20EB2AD_A477_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CImage;
class CUnDo;
#include "FloatDibWnd.h"
class CDipDoc : public CDocument
{
protected: // create from serialization only
	CDipDoc();
	DECLARE_DYNCREATE(CDipDoc)

// Attributes
public:
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDipDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual BOOL DoSave(LPCTSTR pszPathName, BOOL bReplace =TRUE);
	virtual BOOL DoFileSave();
	virtual void SetPathName(LPCTSTR lpszPathName, BOOL bAddToMRU = TRUE);
	//}}AFX_VIRTUAL

// Implementation
public:
	void UpdateStack();
	void FloatCreat(CImage *pImage,CRect rc,CWnd* hwnd,BOOL bPaste);
	void FloatDeleteWnd();
	void FloatAdjust(BOOL bMove=FALSE);
	void Save();
	void UpDate();
	BOOL &GetColorType();
	BOOL NotFloat();
	void FloatClear();
	void Warn();
	BOOL CanPop();
	void Pop();
	void Push();
	CImage *& GetCurImage();
	BOOL GetStretchMode() { return m_bstretchMode; };
	CImage *& GetImage(){ return m_image; };
	CFloatDibWnd* GetFloat(){ return m_pFloatWnd;};
	virtual void SetModifiedFlag(BOOL bModified=TRUE);
	virtual ~CDipDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CUnDo * m_stack;
	BOOL m_bstretchMode;
 	BOOL m_bcolor;
	CImage *m_image;
	CFloatDibWnd* m_pFloatWnd;

// Generated message map functions
protected:
	//{{AFX_MSG(CDipDoc)
	afx_msg void OnStretchMode();
	afx_msg void OnUpdateStretchMode(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnTransformEllipse();
	afx_msg void OnDipRed();
	afx_msg void OnDipGreen();
	afx_msg void OnDipBlue();
	afx_msg void OnDipCvtColor(UINT nID);
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnPointContrast();
	afx_msg void OnPointNegative();
	afx_msg void OnPointThreshold();
	afx_msg void OnUpdateDipRed(CCmdUI* pCmdUI);
	afx_msg void OnMenuitemGray();
	afx_msg void OnUpdateDipGreen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDipBlue(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMenuitemGray(CCmdUI* pCmdUI);
	afx_msg void OnStyleEight();
	afx_msg void OnUpdateStyleEight(CCmdUI* pCmdUI);
	afx_msg void OnStyleColor();
	afx_msg void OnUpdateStyleColor(CCmdUI* pCmdUI);
	afx_msg void OnPointPseudo();
	afx_msg void OnUpdatePointPseudo(CCmdUI* pCmdUI);
	afx_msg void OnGeoMirror();
	afx_msg void OnGeoVeitical();
	afx_msg void OnPointN();
	afx_msg void OnGeoTranslate();
	afx_msg void OnPointAluP();
	afx_msg void OnGeoAffine();
	afx_msg void OnPointAluMinus();
	afx_msg void OnPointAluAdd();
	afx_msg void OnPointHisShow();
	afx_msg void OnPointLine();
	afx_msg void OnChangeSize();
	afx_msg void OnNeighborAverage();
	afx_msg void OnNeighborGauss();
	afx_msg void OnNeighborShape();
	afx_msg void OnEdgeSobel();
	afx_msg void OnEdgeRoberts();
	afx_msg void OnEdgePrewitt();
	afx_msg void OnEdgeLaplacian();
	afx_msg void OnEdgeIsobel();
	afx_msg void OnNeighborCenter();
	afx_msg void OnPointHisEqu();
	afx_msg void OnMorphErosion();
	afx_msg void OnMorphDilation();
	afx_msg void OnMorphOpen();
	afx_msg void OnMorphClose();
	afx_msg void OnMorphFrame();
	afx_msg void OnMorphEdge();
	afx_msg void OnEdgeSusan();
	afx_msg void OnEdgeCandy();
	afx_msg void OnMorphThine();
	afx_msg void OnPointAluAnd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIPDOC_H__F20EB2AD_A477_11D4_A11E_0080C8D7131C__INCLUDED_)
