// His.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"

#include "His.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHis

CHis::CHis()
{
	m_index=NULL;
	m_ch=0;
}

CHis::~CHis()
{
}


BEGIN_MESSAGE_MAP(CHis, CStatic)
	//{{AFX_MSG_MAP(CHis)
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHis message handlers

void CHis::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect rc;
	GetClientRect(&rc);

	int width=rc.Width();
	VERIFY(width>=256);
	float dh=float(rc.Height())/m_index[256];
	CRect trc(rc);
	trc.right=rc.left+1;
	for(int i=0;i<255;i++){
		trc.top=rc.top+rc.Height()-int(m_index[i]*dh);
		dc.FillSolidRect(&trc,RGB(0,0,0));
		trc.left++;
		trc.right++;
	}
}

void CHis::SetIndex(int ch,int *index)
{
	m_ch=ch;
	m_index=index;
	CStatic *max=(CStatic*)GetParent()->GetDlgItem(IDC_STATIC_MAX);
	CString str;
	str.Format("%d",index[256]);
	max->SetWindowText(str);
}

void CHis::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect rc;
	GetClientRect(&rc);
	if( rc.PtInRect(point)) {
		CString s;
		int r=0,g=0,b=0;
		r=m_ch==0||m_ch==1?~r:0;
		g=m_ch==0||m_ch==2?~g:0;
		b=m_ch==0||m_ch==3?~b:0;
		int i=point.x-rc.left;
		s.Format("%s:%d,����:%d",m_ch==0?"�Ҷ�ֵ":"����ֵ",i,m_index[i]);
		CStatusBar& statusBar = ((CMainFrame *)(AfxGetApp()->m_pMainWnd))->GetStatusBar();
		statusBar.SetPaneText(PANE_POS_RGB, s);
		CRect rect1;
		statusBar.GetItemRect(PANE_RGB_COLOR,&rect1);
		CRect size(-1,-1,-1,-1);
		rect1+=&size;
		CDC *pDc=statusBar.GetDC();
		pDc->FillSolidRect(&rect1,RGB(r&i,g&i,b&i));
		ReleaseDC(pDc);
	}
}
