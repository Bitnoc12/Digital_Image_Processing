// ConDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"
#include "ConDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConDlg dialog


CConDlg::CConDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConDlg)
	//}}AFX_DATA_INIT
}


void CConDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConDlg)
	DDX_Control(pDX, IDC_STATIC_PARA, m_static);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConDlg, CDialog)
	//{{AFX_MSG_MAP(CConDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConDlg message handlers

BOOL CConDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_static.init();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
