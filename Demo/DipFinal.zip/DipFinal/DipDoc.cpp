// DipDoc.cpp : implementation of the CDipDoc class
//

#include "stdafx.h"
#include "Dip.h"

#include "lib/cimage.h"
#include "DipProcessor.h"

#include "UnDo.h"
#include "DipDoc.h"
#include "DipView.h"

#include "MainFrm.h"
#include "ThrDlg.h"
#include "NDlg.h"
#include "TranDlg.h"
#include "HisDlg.h"
#include "ConDlg.h"
#include "LTDlg.h"
#include "SizeDlg.h"
#include "AffineDlg.h"
#include "TsDlg.h"
#include "StrengthDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDipDoc

IMPLEMENT_DYNCREATE(CDipDoc, CDocument)

BEGIN_MESSAGE_MAP(CDipDoc, CDocument)
	//{{AFX_MSG_MAP(CDipDoc)
	ON_COMMAND(ID_STRETCH_MODE, OnStretchMode)
	ON_UPDATE_COMMAND_UI(ID_STRETCH_MODE, OnUpdateStretchMode)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_COMMAND(ID_TRANSFORM_ELLIPSE, OnTransformEllipse)
	ON_COMMAND(ID_DIP_RED, OnDipRed)
	ON_COMMAND(ID_DIP_GREEN, OnDipGreen)
	ON_COMMAND(ID_DIP_BLUE, OnDipBlue)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_POINT_CONTRAST, OnPointContrast)
	ON_COMMAND(ID_POINT_NEGATIVE, OnPointNegative)
	ON_COMMAND(ID_POINT_THRESHOLD, OnPointThreshold)
	ON_UPDATE_COMMAND_UI(ID_DIP_RED, OnUpdateDipRed)
	ON_COMMAND(ID_MENUITEM_GRAY, OnMenuitemGray)
	ON_UPDATE_COMMAND_UI(ID_DIP_GREEN, OnUpdateDipGreen)
	ON_UPDATE_COMMAND_UI(ID_DIP_BLUE, OnUpdateDipBlue)
	ON_UPDATE_COMMAND_UI(ID_MENUITEM_GRAY, OnUpdateMenuitemGray)
	ON_COMMAND(ID_STYLE_EIGHT, OnStyleEight)
	ON_UPDATE_COMMAND_UI(ID_STYLE_EIGHT, OnUpdateStyleEight)
	ON_COMMAND(ID_STYLE_COLOR, OnStyleColor)
	ON_UPDATE_COMMAND_UI(ID_STYLE_COLOR, OnUpdateStyleColor)
	ON_COMMAND(ID_POINT_PSEUDO, OnPointPseudo)
	ON_UPDATE_COMMAND_UI(ID_POINT_PSEUDO, OnUpdatePointPseudo)
	ON_COMMAND(ID_GEO_MIRROR, OnGeoMirror)
	ON_COMMAND(ID_GEO_VEITICAL, OnGeoVeitical)
	ON_COMMAND(ID_POINT_N, OnPointN)
	ON_COMMAND(ID_GEO_TRANSLATE, OnGeoTranslate)
	ON_COMMAND(ID_POINT_ALU_P, OnPointAluP)
	ON_COMMAND(ID_GEO_AFFINE, OnGeoAffine)
	ON_COMMAND(ID_POINT_ALU_MINUS, OnPointAluMinus)
	ON_COMMAND(ID_POINT_ALU_ADD, OnPointAluAdd)
	ON_COMMAND(ID_POINT_HIS_SHOW, OnPointHisShow)
	ON_COMMAND(ID_POINT_LINE, OnPointLine)
	ON_COMMAND(ID_CHANGE_SIZE, OnChangeSize)
	ON_COMMAND(ID_NEIGHBOR_AVERAGE, OnNeighborAverage)
	ON_COMMAND(ID_NEIGHBOR_GAUSS, OnNeighborGauss)
	ON_COMMAND(ID_NEIGHBOR_SHAPE, OnNeighborShape)
	ON_COMMAND(ID_EDGE_SOBEL, OnEdgeSobel)
	ON_COMMAND(ID_EDGE_ROBERTS, OnEdgeRoberts)
	ON_COMMAND(ID_EDGE_PREWITT, OnEdgePrewitt)
	ON_COMMAND(ID_EDGE_LAPLACIAN, OnEdgeLaplacian)
	ON_COMMAND(ID_EDGE_ISOBEL, OnEdgeIsobel)
	ON_COMMAND(ID_NEIGHBOR_CENTER, OnNeighborCenter)
	ON_COMMAND(ID_POINT_HIS_EQU, OnPointHisEqu)
	ON_COMMAND(ID_MORPH_EROSION, OnMorphErosion)
	ON_COMMAND(ID_MORPH_DILATION, OnMorphDilation)
	ON_COMMAND(ID_MORPH_OPEN, OnMorphOpen)
	ON_COMMAND(ID_MORPH_CLOSE, OnMorphClose)
	ON_COMMAND(ID_MORPH_FRAME, OnMorphFrame)
	ON_COMMAND(ID_MORPH_EDGE, OnMorphEdge)
	ON_COMMAND(ID_EDGE_SUSAN, OnEdgeSusan)
	ON_COMMAND(ID_EDGE_CANDY, OnEdgeCandy)
	ON_COMMAND(ID_MORPH_THINE, OnMorphThine)
	ON_COMMAND(ID_POINT_ALU_AND, OnPointAluAnd)
	//}}AFX_MSG_MAP

	ON_COMMAND_RANGE(ID_DIP_HSV, ID_DIP_ST, OnDipCvtColor)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDipDoc construction/destruction
static CString FindExtension(const CString& name)
{
	int len = name.GetLength();
	int i;
	for (i = len-1; i >= 0; i--)
	{
		if (name[i] == '.')
		{
			return name.Mid(i+1);
		}
	}
	return CString("");
}

CDipDoc::CDipDoc()
{
	// TODO: add one-time construction code here
	m_stack=new CUnDo;
	m_image = NULL;
	m_pFloatWnd=NULL;
	m_bstretchMode = FALSE;
	m_bcolor=false;
}

CDipDoc::~CDipDoc()
{
	delete m_image;
	m_image=NULL;
	delete m_stack;
	m_stack=NULL;
	delete m_pFloatWnd;
	m_pFloatWnd=NULL;
}

BOOL CDipDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	m_image = NULL;
	m_pFloatWnd=NULL;
	m_stack=NULL;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CDipDoc diagnostics

#ifdef _DEBUG
void CDipDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDipDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDipDoc commands

BOOL CDipDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	CString filename(lpszPathName);
	CString ext(FindExtension(filename));
	ext.MakeLower();
	if (ext == "")
		return FALSE;

	int type = 0;
	if (ext == "jpg" || ext == "jpeg")
		type = CIMAGE_FORMAT_JPEG;
	else if (ext == "gif")
		type = CIMAGE_FORMAT_GIF;
	else if (ext == "png")
		type = CIMAGE_FORMAT_PNG;
	else if (ext == "bmp")
		type = CIMAGE_FORMAT_BMP;
	else
		return FALSE;

	m_image = new CImage(filename, type);
	if (!m_image->IsOK())
	{
		delete m_image;
		m_image = NULL;
		
		for (int i=0;i<NUM_DOC_TYPES&&!m_image;i++)
		{
			if (doctypes[i].bRead && doctypes[i].nID!=type)
			{
				m_image = new CImage(filename, doctypes[i].nID);
				if (!m_image->IsOK())
				{
					delete m_image;
					m_image = NULL;
				}
			}
		}
		if (!m_image){
			return FALSE;
		}
	}
	m_bcolor=CDipProcessor::GetColorSet(m_image);
	m_pFloatWnd=NULL;
	return TRUE;
}

BOOL CDipDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	CString filename(lpszPathName);
	CString ext(FindExtension(filename));
	ext.MakeLower();
	if (ext == "")
		return FALSE;

	int type = 0;
	if (ext == "jpg" || ext == "jpeg")
		type = CIMAGE_FORMAT_JPEG;
	else if (ext == "gif")
		type = CIMAGE_FORMAT_GIF;
	else if (ext == "png")
		type = CIMAGE_FORMAT_PNG;
	else if (ext == "bmp")
		type = CIMAGE_FORMAT_BMP;
	else
		return FALSE;
	CImage *image=GetCurImage();
	if (image)
		return image->SaveFile(filename, type);
	else
		return FALSE;
}

void CDipDoc::OnStretchMode() 
{
	m_bstretchMode = !m_bstretchMode;
	FloatAdjust();
	UpdateAllViews(NULL);
}

void CDipDoc::OnUpdateStretchMode(CCmdUI* pCmdUI) 
{
	pCmdUI->SetText(m_bstretchMode?_T("����\tCtrl+E"):_T("����\tCtrl+E"));
}

void CDipDoc::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((GetCurImage() != NULL));	
}

void CDipDoc::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((GetCurImage() != NULL) &&
	theApp.GetWritableType(GetCurImage()->GetFileType()));	
}

BOOL CDipDoc::DoFileSave(){
	if(AfxMessageBox("Ҫ������?",MB_YESNO)==IDYES){
		return CDocument::DoFileSave();
	}
	return false;
}

BOOL CDipDoc::DoSave(LPCTSTR pszPathName, BOOL bReplace/*=true*/)
{

//	if (!m_image)
//	CImage *image=;
	if (!GetCurImage())
		return FALSE;

	CString newName = pszPathName;
	BOOL bModified = IsModified();

	BOOL bSaveAs = FALSE;
	if (newName.IsEmpty())
		bSaveAs = TRUE;
	else if (!theApp.GetWritableType(m_image->GetFileType()))
		bSaveAs = TRUE;
	if (bSaveAs)
	{
		newName = m_strPathName;
		if (bReplace && newName.IsEmpty())
		{
			newName = m_strTitle;
			int iBad = newName.FindOneOf(_T(" #%;/\\"));    // dubious filename
			if (iBad != -1)
				newName.ReleaseBuffer(iBad);

			// append the default suffix if there is one
			newName += theApp.GetExtFromType(m_image->GetFileType());
		}

		int nDocType = m_image->GetFileType();
		if (!theApp.PromptForFileName(newName, 
			bReplace ? AFX_IDS_SAVEFILE : AFX_IDS_SAVEFILECOPY,
			OFN_HIDEREADONLY | OFN_PATHMUSTEXIST, FALSE, &nDocType))
		{
			return FALSE;// don't even try to save
		}
	}
	
	CStatusBar& statusBar = ((CMainFrame *)(AfxGetApp()->m_pMainWnd))->GetStatusBar();
	statusBar.SetPaneText(0, "Saving Image File!");

	BeginWaitCursor();
	if (!OnSaveDocument(newName))
	{
		if (pszPathName == NULL)
		{
			// be sure to delete the file
			TRY 
			{
				CFile::Remove(newName);
			}
			CATCH_ALL(e)
			{
				TRACE0("Warning: failed to delete file after failed SaveAs\n");
			}
			END_CATCH_ALL
		}
		EndWaitCursor();
		return FALSE;
	}

	EndWaitCursor();
	if (bReplace)
	{
		// Reset the title and change the document name
		SetPathName(newName, TRUE);
		ASSERT(m_strPathName == newName);// must be set
	}

	SetModifiedFlag(FALSE);//bModified);
	statusBar.SetPaneText(0, "File Saved!");
	if(m_stack)
		m_stack->Clear();
	return TRUE;        // success
}

void CDipDoc::OnTransformEllipse() 
{
	Push();
	CDipProcessor::ComputeNewImage(GetCurImage());
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnDipCvtColor(UINT nID) 
{
	Push();

	switch (nID)
	{
	case ID_DIP_HSV:
		CDipProcessor::CvtColorHSV(GetCurImage());
		break;
	case ID_DIP_LAB:
		CDipProcessor::CvtColorLab(GetCurImage());
		break;
	case ID_DIP_XYZ:
		CDipProcessor::CvtColorXYZ(GetCurImage());
		break;
	case ID_DIP_YCrCb:
		CDipProcessor::CvtColorYCrCb(GetCurImage());
		break;
	case ID_DIP_ST:
		break;
	default:
		;
	}
	
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnDipRed() 
{
	Push();
	CDipProcessor::SetOneColor(GetCurImage(),2);
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnDipGreen() 
{
	Push();
	CDipProcessor::SetOneColor(GetCurImage(),1);	
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnDipBlue() 
{
	Push();
	CDipProcessor::SetOneColor(GetCurImage(),0);
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnEditUndo() 
{
	Pop();
}

void CDipDoc::OnUpdateEditUndo(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(CanPop());
}

void CDipDoc::OnPointContrast() 
{
	CConDlg dlg;
	if(dlg.DoModal()==IDOK){
		CPoint a,b;
		dlg.m_static.GetPoint(a,b);
		Push();
		CDipProcessor::PointContrast(GetCurImage(),a,b);
		SetModifiedFlag();
	}
	UpDate();	
}

void CDipDoc::OnPointNegative() 
{
	Push();
	CDipProcessor::PointNegative(GetCurImage());
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::SetModifiedFlag(BOOL bModified)
{
    CString strTitle = GetPathName();
    CString strDirtyFlag = " *"; 
	CString str;
	str.Format(" %dx%d %dλ%s",m_image->GetWidth(),m_image->GetHeight(),m_image->GetDepth(),m_bcolor ? "��ɫ" : "�Ҷ�");
	
    if (bModified)
		SetTitle(strTitle+str+strDirtyFlag);
    else
		SetTitle(strTitle+str);
    UpdateFrameCounts();
    CDocument::SetModifiedFlag(bModified);
}

void CDipDoc::OnPointThreshold() 
{
	/*
	Push();
	CDipProcessor::PointThreshold(GetCurImage(),7);
	SetModifiedFlag();
	UpDate();	
	/*/
	Push();
	CThrDlg pThr;
	if(pThr.DoModal()==IDOK){
		SetModifiedFlag();
	}else{
		Pop();
	}
	//*/
}

void CDipDoc::OnUpdateDipRed(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetColorType());
}

void CDipDoc::OnMenuitemGray() 
{
	if(GetColorType()){
		Push();
		CDipProcessor::DoGray(GetCurImage());	
		GetColorType()=FALSE;
		SetModifiedFlag();
		UpDate();	
	}
}

void CDipDoc::OnUpdateDipGreen(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetColorType());
}

void CDipDoc::OnUpdateDipBlue(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetColorType());
}

void CDipDoc::OnUpdateMenuitemGray(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(!GetColorType());	
}

void CDipDoc::OnStyleEight() 
{
	if(!NotFloat()){
		Warn();
		return;
	}
	if(m_image->GetDepth()==24){
		if(m_bcolor){
			AfxMessageBox("ֻ��ת���Ҷ�ͼ!");
			return;
		}
		CImage *temp=CDipProcessor::Cov_24_To_8(m_image,m_bcolor);
		if(temp){
			Push();
			delete m_image;
			m_image=temp;
			SetModifiedFlag();
			UpDate();	
		}
	}
}

void CDipDoc::OnUpdateStyleEight(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_image->GetDepth()<=8);
}

void CDipDoc::OnStyleColor() 
{
	if(!NotFloat()){
		Warn();
		return;
	}
	if(m_image->GetDepth()<=8){
		CImage * temp=CDipProcessor::Cov_8_To_24(m_image);
		if(temp){
			Push();
			delete m_image;
			m_image=temp;
			SetModifiedFlag();
			UpDate();	
		}
	}
}

void CDipDoc::OnUpdateStyleColor(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_image->GetDepth()==24);
}

void CDipDoc::OnPointPseudo() 
{
	if(GetColorType()) return;
	if(!NotFloat()){
		Warn();
		return;
	}
	Push();
	CDipProcessor::PointPseudo(m_image);
	m_bcolor=TRUE;
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnUpdatePointPseudo(CCmdUI* pCmdUI) 
{
	if(GetColorType()){
		pCmdUI->SetText("��ɫ");
		pCmdUI->SetCheck(TRUE);
	}else{
		pCmdUI->SetText("α��ɫ");
		pCmdUI->SetCheck(FALSE);
	}
}

void CDipDoc::OnGeoMirror() 
{
	Push();
	CDipProcessor::GeoMirror_L(GetCurImage());
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnGeoVeitical() 
{
	Push();
	CDipProcessor::GeoMirror_H(GetCurImage());
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::SetPathName(LPCTSTR lpszPathName, BOOL bAddToMRU) 
{
	CDocument::SetPathName(lpszPathName, bAddToMRU);
	CString str;
	str.Format(" %dx%d %dλ%s",m_image->GetWidth(),m_image->GetHeight(),m_image->GetDepth(),m_bcolor ? "��ɫ" : "�Ҷ�");
	SetTitle(lpszPathName+str);
}

void CDipDoc::OnPointN() 
{
	Push();
	CNDlg pN;
	if(pN.DoModal()==IDOK){
		SetModifiedFlag();
	}else{
		Pop();
	}
}

void CDipDoc::OnGeoTranslate() 
{
	Push();
	CTranDlg pTran;
	if(pTran.DoModal()==IDOK){
		SetModifiedFlag();
	}else{
		Pop();
	}
}

void CDipDoc::OnPointAluP() 
{
	if(!NotFloat()){
		Warn();
		return;
	}

	Push();
	CDipProcessor::PointTransMinus(m_image);
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnGeoAffine() 
{
	CAffineDlg dlg;
	if(dlg.DoModal()==IDOK){
		Push();
		float cd,ss,nq;
		float xz;
		if(dlg.m_cd>90)
			cd=dlg.m_cd*0.1f-8;
		else
			cd=dlg.m_cd*0.01f+0.1f;
		if(dlg.m_ss>90)
			ss=dlg.m_ss*0.1f-8;
		else
			ss=dlg.m_ss*0.01f+0.1f;
		nq=dlg.m_nq*0.01f-1;
		xz=dlg.m_xz/8.0f-180;
		CDipProcessor::GeoAffine(GetCurImage(),cd,ss,nq,xz,dlg.m_inter);
		
		SetModifiedFlag();
		UpDate();
	}
}

void CDipDoc::OnPointAluMinus() 
{
	if(!NotFloat()){
		Warn();
		return;
	}

	CString newName;
	int nType = CIMAGE_FORMAT_BMP;
	if (!theApp.PromptForFileName(newName, AFX_IDS_OPENFILE,
	  OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, TRUE, &nType))
		return; // open cancelled
	CDipDoc *pDoc=new CDipDoc;
	VERIFY(pDoc);
	if(pDoc->OnOpenDocument(newName)){
		if(pDoc->m_image->GetWidth()!=m_image->GetWidth()||pDoc->m_image->GetHeight()!=m_image->GetHeight())
			if(AfxMessageBox("ͼ���С��ͬ��Ҫ�ı��С��?",MB_YESNO)!=IDYES) return;
			CImage *temp=CDipProcessor::PointMinus(m_image,pDoc->m_image);
			VERIFY(temp);
			Push();
			delete m_image;
			m_image=temp;
			m_bcolor = TRUE;
			SetModifiedFlag();
			UpDate();	
	}else{
		AfxMessageBox("Open File Failed!");
	}
	delete pDoc;
}

void CDipDoc::OnPointAluAdd() 
{
	if(!NotFloat()){
		Warn();
		return;
	}
	CString newName;
	int nType = CIMAGE_FORMAT_BMP;
	if (!theApp.PromptForFileName(newName, AFX_IDS_OPENFILE,
	  OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, TRUE, &nType))
		return; // open cancelled
	CDipDoc *pDoc=new CDipDoc;
	VERIFY(pDoc);
	if(pDoc->OnOpenDocument(newName)){
		if(pDoc->m_image->GetWidth()!=m_image->GetWidth()||pDoc->m_image->GetHeight()!=m_image->GetHeight())
			if(AfxMessageBox("ͼ���С��ͬ��Ҫ�ı��С��?",MB_YESNO)!=IDYES) return;
			CImage *temp=CDipProcessor::PointAdd(m_image,pDoc->m_image);
			VERIFY(temp);
			Push();
			delete m_image;
			m_image=temp;
			SetModifiedFlag();
			UpDate();	
	}else{
		AfxMessageBox("Open File Failed!");
	}
	delete pDoc;
}

void CDipDoc::OnPointHisShow() 
{
	CHisDlg dlg;
	dlg.DoModal();
}

void CDipDoc::OnPointLine() 
{
	CLTDlg dlg;
	if(dlg.DoModal()==IDOK){
		Push();
		float a=float(dlg.m_nCon)/100;
		CDipProcessor::PointLine(GetCurImage(),a,dlg.m_nGray-510);
		SetModifiedFlag();
		UpDate();
	}
}

CImage *& CDipDoc::GetCurImage()
{
	if(NotFloat()){
		return m_image;
	}
	return m_pFloatWnd->m_image;
}

void CDipDoc::Push()
{
	m_stack->Add(GetCurImage(),GetColorType(),IsModified(),m_pFloatWnd!=NULL);
}

void CDipDoc::Save()
{
	BOOL b,c;
	if(!m_stack->GetPerModify(b,c)){
		b=IsModified();
		c=GetColorType();
	}
	m_stack->Add(m_image,c,b,FALSE);
}

void CDipDoc::Pop()
{
	if(CanPop()){
		BOOL modify;
		m_stack->UnDo(GetCurImage(),GetColorType(),modify);
		SetModifiedFlag(modify);
		UpDate();
	}else{
		AfxMessageBox("Can not Undo!");
	}
}

BOOL CDipDoc::CanPop()
{
	int i=m_stack->GetFloat()?1:0,j=m_pFloatWnd!=NULL?1:0;
	return m_stack->CanUnDo()&&(i==j);
}

void CDipDoc::Warn()
{
	AfxMessageBox("�������!");
}

void CDipDoc::FloatClear()
{
	BOOL modify;
	if(m_stack->ClearFloat(modify)){
		SetModifiedFlag(modify);
		UpDate();
	}
}

BOOL CDipDoc::NotFloat()
{
	return (m_pFloatWnd==NULL);
}

BOOL &CDipDoc::GetColorType()
{
	if(NotFloat())
		return m_bcolor;
	else
		return m_pFloatWnd->m_bcolor;
}

void CDipDoc::UpDate()
{
	if(NotFloat()){
		UpdateAllViews(NULL);
	}else{
		m_pFloatWnd->Invalidate();
	}
}

void CDipDoc::OnChangeSize() 
{
	// TODO: Add your command handler code here
	CSizeDlg dlg;
	CImage *image=GetCurImage();
	UINT w=image->GetWidth(),h=image->GetHeight();
	dlg.SetData(w,h);
	if(dlg.DoModal()==IDOK){
		if(w==dlg.m_nWidth&&h==dlg.m_nHeight){
			return;
		}
		CImage *temp=CDipProcessor::Sys_Size(image,dlg.m_nWidth,dlg.m_nHeight);
		if(temp){
			Push();
			delete image;
			GetCurImage()=temp;
			FloatAdjust(TRUE);
			SetModifiedFlag();
			UpDate();
		}
	}
}

void CDipDoc::FloatAdjust(BOOL bMove)
{
	if(!NotFloat()){
		CRect orc;
		m_pFloatWnd->GetWindowRect(&orc);
		CPoint t=orc.TopLeft();
		CDipView *pView=CDipView::GetActiveView();
		pView->ScreenToClient(&t);
		int nWidth=m_pFloatWnd->m_image->GetWidth();
		int nHeight=m_pFloatWnd->m_image->GetHeight();
		if(m_bstretchMode){
			CRect rc;
			pView->GetClientRect(&rc);
			nWidth=int(float(rc.Width()*nWidth)/float(m_image->GetWidth()));
			nHeight=int(float(rc.Height()*nHeight)/float(m_image->GetHeight()));
		}
		m_pFloatWnd->MoveWindow(t.x,t.y,nWidth,nHeight);
		if(bMove)
			m_pFloatWnd->SendMessage(WM_MOVE);
	}
}

void CDipDoc::FloatDeleteWnd()
{
	delete m_pFloatWnd;
	m_pFloatWnd = NULL;
	FloatClear();
}

void CDipDoc::FloatCreat(CImage *pImage, CRect rc, CWnd *hwnd,BOOL bPaste)
{
	m_pFloatWnd	= new CFloatDibWnd(pImage,m_bcolor, rc, hwnd,bPaste);
}

void CDipDoc::UpdateStack()
{
	m_stack->UpDate();
}

void CDipDoc::OnNeighborAverage() 
{
	CStrengthDlg dlg;
	dlg.SetFilter(LF2);
	if(dlg.DoModal()==IDOK){
		Push();
		CWaitCursor wait;
		CDipProcessor::Convolute(GetCurImage(),dlg.m_strength,LF2,GetColorType());
		SetModifiedFlag();
		UpDate();
	}
}

void CDipDoc::OnNeighborGauss() 
{
	CStrengthDlg dlg;
	dlg.SetFilter(GAUSS);
	if(dlg.DoModal()==IDOK){
		Push();
		CWaitCursor wait;
		CDipProcessor::Convolute(GetCurImage(),dlg.m_strength,GAUSS,GetColorType());
		SetModifiedFlag();
		UpDate();
	}
}

void CDipDoc::OnNeighborShape() 
{
	CStrengthDlg dlg;
	dlg.SetFilter(HF1);
	if(dlg.DoModal()==IDOK){
		Push();
		CWaitCursor wait;
		CDipProcessor::Convolute(GetCurImage(),dlg.m_strength,HF1,GetColorType());
		SetModifiedFlag();
		UpDate();
	}
}

void CDipDoc::OnEdgeRoberts() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::Convolute(GetCurImage(),MAX_STRENGTH,ROBERTS,GetColorType());
	SetModifiedFlag();
	UpDate();
}

void CDipDoc::OnEdgePrewitt() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::Convolute(GetCurImage(),MAX_STRENGTH,PREWITT,GetColorType());
	SetModifiedFlag();
	UpDate();
}

void CDipDoc::OnEdgeSobel() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::Convolute(GetCurImage(),MAX_STRENGTH,SOBEL,GetColorType());
	SetModifiedFlag();
	UpDate();
}

void CDipDoc::OnEdgeIsobel() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::Convolute(GetCurImage(),MAX_STRENGTH,ISOBEL,GetColorType());
	SetModifiedFlag();
	UpDate();
}

void CDipDoc::OnEdgeLaplacian() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::GaussLap(GetCurImage(),GetColorType());
	SetModifiedFlag();
	UpDate();
}

void CDipDoc::OnNeighborCenter() 
{	
	Push();
	CWaitCursor wait;
	CDipProcessor::MedianFilter(GetCurImage(),GetColorType());
	SetModifiedFlag();
	UpDate();
}

void CDipDoc::OnPointHisEqu() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::HisEqu(GetCurImage());
	SetModifiedFlag();
	UpDate();
}

int *lpT = D3;
int lnT = 3;

void CDipDoc::OnMorphErosion() 
{	
	Push();
	CWaitCursor wait;
	CDipProcessor::MorphErosion(GetCurImage(),lpT,lnT,lnT);
	SetModifiedFlag();
	UpDate();
}

void CDipDoc::OnMorphDilation() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::MorphDilation(GetCurImage(),lpT,lnT,lnT);
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnMorphOpen() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::MorphErosion(GetCurImage(),lpT,lnT,lnT);
	CDipProcessor::MorphDilation(GetCurImage(),lpT,lnT,lnT);
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnMorphClose() 
{
	Push();
	CWaitCursor wait;
	CDipProcessor::MorphDilation(GetCurImage(),lpT,lnT,lnT);
	CDipProcessor::MorphErosion(GetCurImage(),lpT,lnT,lnT);
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnMorphFrame() 
{
	if(GetColorType()){
		AfxMessageBox("��Ҷ�ͼ!");
		return;
	}
	Push();
	CWaitCursor wait;
	CImage *pImage=NULL;
	CImage *Eimage=NULL;
	CImage *Oimage=NULL;
	//white
	int T[100*100];
	int i;
	for(i=0;i<100*100;i++)
		T[i]=1;
	for(i=0;i<10;i++){
		Eimage=CDipProcessor::MorphErosion(GetCurImage(),T,i+1,i+1,FALSE);
		if(!CDipProcessor::Empty(Eimage)){
			Oimage=CDipProcessor::MorphErosion(Eimage,T,2,2,FALSE);
			CDipProcessor::MorphDilation(Oimage,T,2,2);
		
			CDipProcessor::ImageMinus(Eimage,Oimage);
			if(i==0){
				pImage=Eimage;
			}else{
				CDipProcessor::ImageMax(pImage,Eimage);
				delete Eimage;
				Eimage=NULL;
			}
			delete Oimage;
			Oimage=NULL;
		}else{
			delete Eimage;
			break;
		}
	}
	if(i){
		delete GetCurImage();
		GetCurImage()=pImage;
	}
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnMorphEdge() 
{
	Push();
	CWaitCursor wait;
	CImage *image=CDipProcessor::MorphErosion(GetCurImage(),D3,3,3,FALSE);
	CDipProcessor::ImageMinus(GetCurImage(),image);
	delete image;
	SetModifiedFlag();
	UpDate();
}

void CDipDoc::OnEdgeSusan() 
{
	if(GetColorType()){
		AfxMessageBox("��Ҷ�ͼ!");
		return;
	}
	Push();
	CWaitCursor wait;
	CDipProcessor::SUSAN(GetCurImage(),3,20,GetColorType());
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnEdgeCandy() 
{
	if(GetColorType()){
		AfxMessageBox("��Ҷ�ͼ!");
		return;
	}
	Push();
	CWaitCursor wait;
	CDipProcessor::Canny(GetCurImage());
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnMorphThine() 
{
	if(GetColorType()){
		AfxMessageBox("��Ҷ�ͼ!");
		return;
	}
	Push();
	BOOL b;
	b=(AfxMessageBox("Black(Y)/White(N)?",MB_YESNO)==IDNO);
	CWaitCursor wait;
	CDipProcessor::Thin(GetCurImage(),b);
	SetModifiedFlag();
	UpDate();	
}

void CDipDoc::OnPointAluAnd() 
{
	// TODO: Add your command handler code here
	if(!NotFloat()){
		Warn();
		return;
	}
	CString newName;
	int nType = CIMAGE_FORMAT_BMP;
	if (!theApp.PromptForFileName(newName, AFX_IDS_OPENFILE,
	  OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, TRUE, &nType))
		return; // open cancelled
	CDipDoc *pDoc=new CDipDoc;
	VERIFY(pDoc);
	if(pDoc->OnOpenDocument(newName)){
		if(pDoc->m_image->GetWidth()!=m_image->GetWidth()||pDoc->m_image->GetHeight()!=m_image->GetHeight())
			if(AfxMessageBox("ͼ���С��ͬ��Ҫ�ı��С��?",MB_YESNO)!=IDYES) return;
			CImage *temp=CDipProcessor::PointAnd(m_image,pDoc->m_image);
			VERIFY(temp);
			Push();
			delete m_image;
			m_image=temp;
			SetModifiedFlag();
			UpDate();	
	}else{
		AfxMessageBox("Open File Failed!");
	}
	delete pDoc;	
}
