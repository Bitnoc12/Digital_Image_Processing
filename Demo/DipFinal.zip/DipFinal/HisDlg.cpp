// HisDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"

#include "lib/cimage.h"
#include "DipProcessor.h"

#include "DipDoc.h"
#include "DipView.h"
#include "HisDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHisDlg dialog


CHisDlg::CHisDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHisDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHisDlg)
	//}}AFX_DATA_INIT
}


void CHisDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHisDlg)
	DDX_Control(pDX, IDC_STATIC_GRAPH, m_his);
	DDX_Control(pDX, IDC_STATIC_COLOR, m_color);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHisDlg, CDialog)
	//{{AFX_MSG_MAP(CHisDlg)
	ON_CBN_SELCHANGE(IDC_COMBO_CH, OnSelchangeComboCh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHisDlg message handlers

BOOL CHisDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CComboBox *ch=(CComboBox*)GetDlgItem(IDC_COMBO_CH);
	ch->SetCurSel(0);
	CDipView * pView=CDipView::GetActiveView();
	m_image=pView->GetDocument()->GetCurImage();
	m_bcolor=pView->GetDocument()->GetColorType();

	m_his.SetIndex(0,CDipProcessor::His(m_image,0,m_bcolor));
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CHisDlg::OnSelchangeComboCh() 
{
	// TODO: Add your control notification handler code here
	CComboBox *ch=(CComboBox*)GetDlgItem(IDC_COMBO_CH);
	m_color.SetCh(ch->GetCurSel());
	m_his.SetIndex(ch->GetCurSel(),CDipProcessor::His(m_image,ch->GetCurSel(),m_bcolor));
	Invalidate();
}
