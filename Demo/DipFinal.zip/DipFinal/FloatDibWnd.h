#if !defined(AFX_FLOATDIBWND_H__0B12E5E1_AFF2_11D2_9481_000021003EA5__INCLUDED_)
#define AFX_FLOATDIBWND_H__0B12E5E1_AFF2_11D2_9481_000021003EA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FloatDibWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFloatDibWnd window

class CFloatDibWnd : public CWnd
{
// Construction
public:
	CFloatDibWnd(CImage *pImage,BOOL bcolor, CRect rc, CWnd* pParentWnd,BOOL bPaste=FALSE);

// Attributes
public:
	CImage*	m_image;
	BOOL m_bcolor;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFloatDibWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	void OnDraw(CDC *pDC);
	virtual ~CFloatDibWnd();
	BOOL NotMove(){return m_nFirst<2;};
	BOOL Paste(){ return m_bPaste;};
	// Generated message map functions
protected:
	BOOL m_bPaste;
	HCURSOR	m_hCursorFloat;
	int	m_nFirst;
	//{{AFX_MSG(CFloatDibWnd)
	afx_msg void OnPaint();
	afx_msg UINT OnNcHitTest(CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnDestroy();
	afx_msg void OnMove(int x, int y);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLOATDIBWND_H__0B12E5E1_AFF2_11D2_9481_000021003EA5__INCLUDED_)
