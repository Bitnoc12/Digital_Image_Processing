//////////////////////////////////////////////////////////////////////
//
// DipProcessor.cpp: implementation of the CDipProcessor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Dip.h"
#include "DipProcessor.h"
#include "lib/Dibutils.h"
#include <math.h>
#include <time.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
typedef void (*JFun)(int *red, int *green, int *blue, ImagePointerType pt,
					int sDepth,long EffWidth, KERNEL *lpKernel,int bColor);

typedef void (*MFun)(int *red, int *green, int *blue, ImagePointerType pt,
					int sDepth,long EffWidth);

BYTE CDipProcessor::r[];
BYTE CDipProcessor::g[];
BYTE CDipProcessor::b[];

int D1[1]={
	1
};
int D2[4]={
	1,1,
	1,1
};
int D3[9]={
	1,1,1,
	1,1,1,
	1,1,1
};
// The following kernel definitions are for convolution filtering.
// Kernel entries are specified with a divisor to get around the
// requirement for floating point numbers in the low pass filters. 

KERNEL HP1 = {                    // HP filter #1
  {-1, -1, -1,
   -1,  9, -1,
   -1, -1, -1},
    1                             // Divisor = 1
};

KERNEL HP2 = {                    // HP filter #2
  { 0, -1,  0,
   -1,  5, -1,
    0, -1,  0},
    1                             // Divisor = 1
};

KERNEL HP3 = {                    // HP filter #3
  { 1, -2,  1,
   -2,  5, -2,
    1, -2,  1},
    1                             // Divisor = 1
};

KERNEL LP1 = {                    // LP filter #1
  { 1,  1,  1,
    1,  1,  1,
    1,  1,  1},
    9                             // Divisor = 9
};

KERNEL LP2 = {                    // LP filter #2
  { 1,  1,  1,
    1,  2,  1,
    1,  1,  1},
    10                            // Divisor = 10
};

KERNEL Gauss = {                    // LP filter #3
  { 1,  2,  1,
    2,  4,  2,
    1,  2,  1},
    16                            // Divisor = 16
};

KERNEL VertEdge = {              // Vertical edge
  { 0,  0,  0,
    -1, 1,  0,
    0,  0,  0},
    1                             // Divisor = 1
};

KERNEL HorzEdge = {              // Horizontal edge
  { 0,  -1,  0,
    0,  1,  0,
    0,  0,  0},
    1                             // Divisor = 1
};

KERNEL VertHorzEdge = {           // Vertical Horizontal edge
  { -1, 0,  0,
    0,  1,  0,
    0,  0,  0},
    1                             // Divisor = 1
};

KERNEL EdgeNorth = {              // North gradient
  { 1,  1,  1,
    1, -2,  1,
   -1, -1, -1},
    1                             // Divisor = 1
};

KERNEL EdgeNorthEast = {          // North East gradient
  { 1,  1,  1,
   -1, -2,  1,
   -1, -1,  1},
    1                             // Divisor = 1
};

KERNEL EdgeEast = {               // East gradient
  {-1,  1,  1,
   -1, -2,  1,
   -1,  1,  1},
    1                             // Divisor = 1
};

KERNEL EdgeSouthEast = {          // South East gradient
  {-1, -1,  1,
   -1, -2,  1,
    1,  1,  1},
    1                             // Divisor = 1
};

KERNEL EdgeSouth = {              // South gadient
  {-1, -1, -1,
    1, -2,  1,
    1,  1,  1},
    1                             // Divisor = 1
};

KERNEL EdgeSouthWest = {          // South West gradient
  { 1, -1, -1,
    1, -2, -1,
    1,  1,  1},
    1                             // Divisor = 1
};

KERNEL EdgeWest = {               // West gradient
  { 1,  1, -1,
    1, -2, -1,
    1,  1, -1},
    1                             // Divisor = 1
};

KERNEL EdgeNorthWest = {          // North West gradient
  { 1,  1,  1,
    1, -2, -1,
    1, -1, -1},
    1                             // Divisor = 1
};

KERNEL Lap1 = {					  // Laplace filter 1
  { 0,  -1,  0,
    -1, 4,  -1,
    0,  -1,  0},
    1                             // Divisor = 1
};

KERNEL Lap2 = {					  // Laplace filter 2
  { -1, -1, -1,
    -1,  8, -1,
    -1, -1, -1},
    1                             // Divisor = 1
};

KERNEL Lap3 = {					  // Laplace filter 3
  { -1, -1, -1,
    -1,  9, -1,
    -1, -1, -1},
    1                             // Divisor = 1
};

KERNEL Lap4 = {					  // Laplace filter 4
  { 1, -2, 1,
    -2, 4, -2,
    1, -2, 1},
    1                             // Divisor = 1
};

KERNEL Roberts[2] = {
	{{0, 0, 0,
     0, 0, 1,
	 0,-1, 0},
	 1
	},
	{{ 0, 0, 0,
      0, 1, 0,
	  0, 0,-1},
	 1
	}
};
KERNEL Prewitt[2] = {
	{
		{-1,0,1,
		 -1,0,1,
		 -1,0,1},
		3
	},
	{
		{-1,-1,-1,
		 0, 0, 0,
		 1, 1, 1},
		3
	}
};

KERNEL Sobel[2] = {
	{                    // Sobel1
		{-1, 0, 1,
		 -2, 0, 2,
		 -1, 0, 1},
		4                             // Divisor = 1
	},
	{                    // Sobel2
		{-1, -2, -1,
		  0,  0,  0,
		  1,  2,  1},
		4                             // Divisor = 1
	}

};

/*
,
	{                    // Sobel3
		{-2, -1, 0,
		 -1,  0, 1,
		  0,  1, 2},
		1                             // Divisor = 1
	},
	{                    // Sobel4
		{0, -1, -2,
		 1,  0, -1,
		 2,  1, 0},
		1                             // Divisor = 1
	}
*/

KERNEL ISobel[2] = {
	{                    // Sobel1
		{-100, 0, 100,
		 -141, 0, 141,
		 -100, 0, 100},
		341                             // Divisor = 1
	},
	{                    // Sobel2
		{-100, -141, -100,
		  0   ,  0,  0,
		  100,  141,  100},
		341                             // Divisor = 1
	}

};
			
KERNEL Hough[4] = {
	{                    // Hough1
		{-1, 0, 1,
		 -1, 0, 1,
		 -1, 0, 1},
		1                             // Divisor = 1
	},
	{                    // Hough2
		{-1, -1, 0,
		 -1,  0, 1,
		  0,  1, 1},
		1                             // Divisor = 1
	},
	{                    // Hough3
		{-1, -1, -1,
		  0,  0, 0,
		  1,  1, 1},
		1                             // Divisor = 1
	},
	{                    // Hough4
		{0, -1, -1,
		 1,  0, -1,
		 1,  1, 0},
		1                             // Divisor = 1
	}
};

BOOL CDipProcessor::CanCopy(CImage *p1,CImage *p2)
{
	return p1->GetWidth()==p2->GetWidth() 
		&& p1->GetHeight()==p2->GetHeight() 
		&& p1->GetDepth()==p2->GetDepth() 
		&& p1->GetEffWidth()==p2->GetEffWidth();
}

void CDipProcessor::ComputeNewImage(CImage *&m_image)
{
	CWaitCursor wait;
	int x, y, x1, y1;
	float fx, fy, xmid, ymid, ar;
	CImage *image2 = new CImage(m_image);
	ImagePointerType RawImage1=m_image->GetRawImage(),
		             RawImage2=image2->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2;
	int Width=m_image->GetWidth(),
		Height=m_image->GetHeight();
	long EffWidth=m_image->GetEffWidth();
	int sDepth=m_image->GetDepth()>>3;
	xmid = (float) (Width/2.0);
	ymid = (float) (Height/2.0);
	ar = (float)(Height)/(float)(Width);
	if(m_image->GetDepth()>8){
		for (y=0; y<Height; y++) {
			ImagePointer2 = RawImage2 + EffWidth*y;;
			for (x=0; x<Width; x++) {
				ComputePixel(ar*(x-xmid), y-ymid, fx, fy);
				x1 = (int)(xmid+fx/ar);
				y1 = (int)(ymid+fy);
			//	x1=x+10;
			//	y1=y+10;
				ImagePointer1 = RawImage1 + EffWidth*y1 + x1*sDepth;
				if (m_image->Inside(x1, y1)){
					ImagePointer2[0]=ImagePointer1[0];
					ImagePointer2[1]=ImagePointer1[1];
					ImagePointer2[2]=ImagePointer1[2];
				}else{
					ImagePointer2[0]=ImagePointer2[1]=ImagePointer2[2]=0;
				}
				ImagePointer2+=sDepth;
			}
		}
	}else{
		for (int y=0; y<Height; y++) {
			ImagePointer2 = RawImage2 + EffWidth*y;
			for (int x=0; x<Width; x++) {
				ComputePixel(ar*(x-xmid), y-ymid, fx, fy);
				x1 = (int)(xmid+fx/ar);
				y1 = (int)(ymid+fy);
			//	x1=x/2;
			//	y1=y/2;
				ImagePointer1 = RawImage1 + EffWidth*y1 + x1;//*sDepth;
				if (m_image->Inside(x1, y1)){
					ImagePointer2[0]=ImagePointer1[0];
				}else{
					ImagePointer2[0]=0;
				}
				ImagePointer2++;//=sDepth;
			}
		}

	}
	delete m_image;
	m_image = image2;
}

int CDipProcessor::ComputePixel(float x, float y, float &x1, float &y1)
{
  float r, nn;

  if (x==0 && y==0) {
	 x1 = x;
	 y1 = y;
	 return 1;
  }

  nn =(float) sqrt(x*x + y*y);
  r =(float)( (fabs(x) > fabs(y)) ? fabs(nn/x): fabs(nn/y));

  x1 = (r*x);
  y1 = (r*y);

  return 1;
}

BOOL CDipProcessor::GetColorSet(CImage * pImage)
{
	int ctype=pImage->GetDepth();
	if(ctype>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer,head;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		long EffWidth=pImage->GetEffWidth();
		int sDepth=pImage->GetDepth()>>3;
		head=RawImage;
		for (int y=0; y<Height; y++) {
			ImagePointer = head;
			for (int x=0; x<Width; x++) {
				if(ImagePointer[0]!=ImagePointer[1]||ImagePointer[0]!=ImagePointer[2])
					 return TRUE;
				ImagePointer+=sDepth;
			}
			head += EffWidth;
		}
		return FALSE;
	}
	CImagePalette* pPal=pImage->GetPalette();
	if(!pPal) return FALSE;
	int size=pPal->GetEntryCount();
	for(int i=0;i<size;i++){
		  PALETTEENTRY entry;
		  if (::GetPaletteEntries((HPALETTE) (*pPal), i, 1, &entry))
		  {
			  if(entry.peRed!=entry.peGreen||entry.peBlue!=entry.peGreen)
				  return TRUE;
		  }
	}
	return FALSE;
}

void CDipProcessor::DoGray(CImage *pImage)
{
	if(pImage->GetDepth()>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		long EffWidth=pImage->GetEffWidth();
		int Depth=pImage->GetDepth();
		for (int y=0; y<Height; y++) {
			for (int x=0; x<Width; x++) {
				ImagePointer = RawImage + EffWidth*y + (x*Depth >> 3);
				ImagePointer[0]=ImagePointer[1]=ImagePointer[2]=(BYTE)(0.2989*ImagePointer[0]+0.5866*ImagePointer[1]+0.1144*ImagePointer[2]);
			}
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		int size=pPal->GetEntryCount();
		PALETTEENTRY entry;
		for(int j=0;j<size;j++){
			if (::GetPaletteEntries((HPALETTE) (*pPal), j, 1, &entry))
			{
				entry.peRed=entry.peGreen=entry.peBlue=(BYTE)(0.2989*entry.peRed+0.5866*entry.peGreen+0.1144*entry.peBlue);
				VERIFY(::SetPaletteEntries((HPALETTE) (*pPal),j,1,&entry));
			}
		}
	}
}

void CDipProcessor::PointContrast(CImage *pImage,CPoint &aa,CPoint &bb)
{
	BYTE A=BYTE(aa.x),B=BYTE(bb.x);
	float alpha=float(aa.y)/aa.x;
	float beta=float(bb.y-aa.y)/(bb.x-aa.x);
	float gama=float(255-bb.y)/(255-bb.x);
	for(int i=0;i<A;i++)
		r[i]=g[i]=b[i]=(byte)(alpha*i);
	for(i=A;i<B;i++)
		r[i]=g[i]=b[i]=(byte)(aa.y+beta*(i-A));
	for(i=B;i<256;i++)
		r[i]=g[i]=b[i]=(byte)(bb.y+gama*(i-B));
	DoPoint(pImage);
}

void CDipProcessor::PointNegative(CImage *pImage)
{
	for(int i=0;i<256;i++){
		r[i]=g[i]=b[i]=255-i;
	}
	DoPoint(pImage);
}

void CDipProcessor::PointThreshold(CImage *pImage,byte k)
{
	for(int i=0;i<256;i++){
		r[i]=g[i]=b[i]=i<k?0:255;
//		r[i]=g[i]=b[i]=i<k?0:i;
//		r[i]=g[i]=b[i]=abs(i-k)>5?0:255;
//		r[i]=g[i]=b[i]=(i==k)?255:0;
	}
	DoPoint(pImage);
}

void CDipProcessor::CopyData(CImage *image,const BITMAPINFO *info)
{
	if(!info) return;
	DWORD dwSizeImage = image->GetHeight()*(DWORD)((image->GetWidth()*image->GetDepth()/8+3)&~3);
	CopyMemory(image->GetImplementation()->GetBits(),info,sizeof(BITMAPINFOHEADER)+dwSizeImage + 1024);
	if(image->GetDepth()<=8){
		HPALETTE hPal=MakePalette((const BITMAPINFO FAR*)info,0);
		if(hPal){
			delete image->GetPalette();
			CImagePalette *pal=new CImagePalette;
			pal->Attach(hPal);
			image->SetPalette(pal);
		}
	}
}

void CDipProcessor::CopyData(CImage *image,CImage *pImage)
{
	DWORD dwSizeImage = image->GetHeight()*(DWORD)((image->GetWidth()*image->GetDepth()/8+3)&~3);
	CopyMemory(image->GetImplementation()->GetBits(),pImage->GetImplementation()->GetBits(),sizeof(BITMAPINFOHEADER)+dwSizeImage + 1024);
	if(pImage->GetPalette()){
		delete image->GetPalette();
		image->SetPalette(new CImagePalette(pImage->GetPalette()));
	}
}

HANDLE CDipProcessor::CopyHandle(HANDLE h)
{
	if (h == NULL)
		return NULL;

	DWORD  dwLen = ::GlobalSize((HGLOBAL)h);
	HANDLE hCopy = ::GlobalAlloc(GHND, dwLen);
	if (hCopy == NULL)
		return NULL;

	void* lpCopy = ::GlobalLock((HGLOBAL) hCopy);
	void* lp     = ::GlobalLock((HGLOBAL) h);
	::CopyMemory(lpCopy, lp, dwLen);
	::GlobalUnlock(hCopy);
	::GlobalUnlock(h);

	return hCopy;
}

void CDipProcessor::SetOneColor(CImage *pImage, int i)
{
	if(pImage->GetDepth()>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		int m=(i+3-1)%3,n=(i+3-2)%3;
		long EffWidth=pImage->GetEffWidth();
		int Depth=pImage->GetDepth();
		for (int y=0; y<Height; y++) {
			for (int x=0; x<Width; x++) {
				ImagePointer = RawImage + EffWidth*y + (x*Depth >> 3);
				ImagePointer[n]=ImagePointer[i];
				ImagePointer[m]=ImagePointer[i];
			}
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		int size=pPal->GetEntryCount();
		PALETTEENTRY entry;
		byte *p,*q,*s;
		switch(i){
		case 0:
			p=&entry.peBlue;
			q=&entry.peRed;
			s=&entry.peGreen;
			break;
		case 1:
			p=&entry.peGreen;
			q=&entry.peRed;
			s=&entry.peBlue;
			break;
		default:
			p=&entry.peRed;
			q=&entry.peGreen;
			s=&entry.peBlue;
		}
		for(int j=0;j<size;j++){
			if (::GetPaletteEntries((HPALETTE) (*pPal), j, 1, &entry))
			{
				*q=0;
				*s=0;
				VERIFY(::SetPaletteEntries((HPALETTE) (*pPal),j,1,&entry));
			}
		}
	}
}

void CDipProcessor::CvtColorLab(CImage *pImage)
{
	double X,Y,Z,L,a,b;
	if(pImage->GetDepth()>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		long EffWidth=pImage->GetEffWidth();
		int Depth=pImage->GetDepth();
		for (int y=0; y<Height; y++) {
			for (int x=0; x<Width; x++) {
				ImagePointer = RawImage + EffWidth*y + (x*Depth >> 3);
				X = 0.433910*ImagePointer[2] + 0.376220*ImagePointer[1] + 0.189860*ImagePointer[0];
				Y = 0.212649*ImagePointer[2] + 0.715169*ImagePointer[1] + 0.072182*ImagePointer[0];
				Z = 0.017756*ImagePointer[2] + 0.109478*ImagePointer[1] + 0.872915*ImagePointer[0];
				X /= 255;
				Y /= 255;
				Z /= 255;
				
				L = (Y>0.008856) ? 116*pow(Y,1.0/3) : 903.3*Y;
				a = 500*(Lab_f(X)-Lab_f(Y)) + 128;
				b = 200*(Lab_f(Y)-Lab_f(Z)) + 128;

				ImagePointer[2] = FloatToByte(L);
				ImagePointer[1] = FloatToByte(a);
				ImagePointer[0] = FloatToByte(b);
			}
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		int size=pPal->GetEntryCount();
		PALETTEENTRY entry;
		for(int j=0;j<size;j++){
			if (::GetPaletteEntries((HPALETTE) (*pPal), j, 1, &entry))
			{
				X = 0.433910*entry.peRed + 0.376220*entry.peGreen + 0.189860*entry.peBlue;
				Y = 0.212649*entry.peRed + 0.715169*entry.peGreen + 0.072182*entry.peBlue;
				Z = 0.017756*entry.peRed + 0.109478*entry.peGreen + 0.872915*entry.peBlue;
				X /= 255;
				Y /= 255;
				Z /= 255;
				
				L = (Y>0.008856) ? 116*pow(Y,1.0/3) : 903.3*Y;
				a = 500*(Lab_f(X)-Lab_f(Y));
				b = 200*(Lab_f(Y)-Lab_f(Z));

				entry.peRed = FloatToByte(L);
				entry.peGreen = FloatToByte(a);
				entry.peBlue = FloatToByte(b);

				VERIFY(::SetPaletteEntries((HPALETTE) (*pPal),j,1,&entry));
			}
		}
	}
}

void CDipProcessor::CvtColorXYZ(CImage *pImage)
{
	double X,Y,Z;
	if(pImage->GetDepth()>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		long EffWidth=pImage->GetEffWidth();
		int Depth=pImage->GetDepth();
		for (int y=0; y<Height; y++) {
			for (int x=0; x<Width; x++) {
				ImagePointer = RawImage + EffWidth*y + (x*Depth >> 3);
				X = 0.412411*ImagePointer[2] + 0.357585*ImagePointer[1] + 0.180454*ImagePointer[0];
				Y = 0.212649*ImagePointer[2] + 0.715169*ImagePointer[1] + 0.072182*ImagePointer[0];
				Z = 0.019332*ImagePointer[2] + 0.119195*ImagePointer[1] + 0.950390*ImagePointer[0];

				ImagePointer[2] = FloatToByte(X);
				ImagePointer[1] = FloatToByte(Y);
				ImagePointer[0] = FloatToByte(Z);
			}
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		int size=pPal->GetEntryCount();
		PALETTEENTRY entry;
		for(int j=0;j<size;j++){
			if (::GetPaletteEntries((HPALETTE) (*pPal), j, 1, &entry))
			{
				X = 0.412411*entry.peRed + 0.357585*entry.peGreen + 0.180454*entry.peBlue;
				Y = 0.212649*entry.peRed + 0.715169*entry.peGreen + 0.072182*entry.peBlue;
				Z = 0.019332*entry.peRed + 0.119195*entry.peGreen + 0.950390*entry.peBlue;
				
				entry.peRed = FloatToByte(X);
				entry.peGreen = FloatToByte(Y);
				entry.peBlue = FloatToByte(Z);

				VERIFY(::SetPaletteEntries((HPALETTE) (*pPal),j,1,&entry));
			}
		}
	}
}

void CDipProcessor::CvtColorSTV(CImage *pImage)
{
	double X,Y,Z;
	if(pImage->GetDepth()>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		long EffWidth=pImage->GetEffWidth();
		int Depth=pImage->GetDepth();
		for (int y=0; y<Height; y++) {
			for (int x=0; x<Width; x++) {
				ImagePointer = RawImage + EffWidth*y + (x*Depth >> 3);
				X = 0.412411*ImagePointer[2] + 0.357585*ImagePointer[1] + 0.180454*ImagePointer[0];
				Y = 0.212649*ImagePointer[2] + 0.715169*ImagePointer[1] + 0.072182*ImagePointer[0];
				Z = 0.019332*ImagePointer[2] + 0.119195*ImagePointer[1] + 0.950390*ImagePointer[0];

				ImagePointer[2] = FloatToByte(X);
				ImagePointer[1] = FloatToByte(Y);
				ImagePointer[0] = FloatToByte(Z);
			}
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		int size=pPal->GetEntryCount();
		PALETTEENTRY entry;
		for(int j=0;j<size;j++){
			if (::GetPaletteEntries((HPALETTE) (*pPal), j, 1, &entry))
			{
				X = 0.412411*entry.peRed + 0.357585*entry.peGreen + 0.180454*entry.peBlue;
				Y = 0.212649*entry.peRed + 0.715169*entry.peGreen + 0.072182*entry.peBlue;
				Z = 0.019332*entry.peRed + 0.119195*entry.peGreen + 0.950390*entry.peBlue;
				
				entry.peRed = FloatToByte(X);
				entry.peGreen = FloatToByte(Y);
				entry.peBlue = FloatToByte(Z);

				VERIFY(::SetPaletteEntries((HPALETTE) (*pPal),j,1,&entry));
			}
		}
	}
}

void CDipProcessor::CvtColorYCrCb(CImage *pImage)
{
	double Y,Cr,Cb;
	if(pImage->GetDepth()>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		long EffWidth=pImage->GetEffWidth();
		int Depth=pImage->GetDepth();
		for (int y=0; y<Height; y++) {
			for (int x=0; x<Width; x++) {
				ImagePointer = RawImage + EffWidth*y + (x*Depth >> 3);
				Y = 0.299*ImagePointer[2] + 0.587*ImagePointer[1] + 0.114*ImagePointer[0];
				Cr=(ImagePointer[2]-Y)*0.713 + 128;
				Cb=(ImagePointer[0]-Y)*0.564 + 128;

				ImagePointer[2] = FloatToByte(Y);
				ImagePointer[1] = FloatToByte(Cr);
				ImagePointer[0] = FloatToByte(Cb);
			}
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		int size=pPal->GetEntryCount();
		PALETTEENTRY entry;
		for(int j=0;j<size;j++){
			if (::GetPaletteEntries((HPALETTE) (*pPal), j, 1, &entry))
			{
				Y = 0.299*entry.peRed + 0.587*entry.peGreen + 0.114*entry.peBlue;
				Cr=(entry.peRed-Y)*0.713 + 128;
				Cb=(entry.peBlue-Y)*0.564 + 128;
				
				entry.peRed = FloatToByte(Y);
				entry.peGreen = FloatToByte(Cr);
				entry.peBlue = FloatToByte(Cb);

				VERIFY(::SetPaletteEntries((HPALETTE) (*pPal),j,1,&entry));
			}
		}
	}
}

void CDipProcessor::CvtColorHSV(CImage *pImage)
{
	double H,S;
	BYTE V,diff;
	double maxt,mint,t;
	maxt = -1000000000;
	mint = 1000000000;
	if(pImage->GetDepth()>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		long EffWidth=pImage->GetEffWidth();
		int Depth=pImage->GetDepth();
		for (int y=0; y<Height; y++) {
			for (int x=0; x<Width; x++) {
				ImagePointer = RawImage + EffWidth*y + (x*Depth >> 3);
				V = max3(ImagePointer[2],ImagePointer[1],ImagePointer[0]);
				diff = V-min3(ImagePointer[2],ImagePointer[1],ImagePointer[0]);
				S = (V!=0) ? diff*255.0/V : 0;

				if (fabs(S)<0.0001) H = 0;
				else
				{
					if (V == ImagePointer[2]) H = ((int)ImagePointer[1] - ImagePointer[0]);
					else if (V == ImagePointer[1]) H = ((int)ImagePointer[0] - ImagePointer[2]) + 2*diff;
					else H = ((int)ImagePointer[2] - ImagePointer[1]) + 4*diff;

					H *= 255*15/diff/(1<<7) + (H < 0 ? 30*6 : 0);
				}

				t = H;
				if (t>maxt) maxt = t;
				else if (t<mint) mint = t;

				ImagePointer[2] = V;
				ImagePointer[1] = FloatToByte(S);
				ImagePointer[0] = FloatToByte(H);
			}
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		int size=pPal->GetEntryCount();
		PALETTEENTRY entry;
		for(int j=0;j<size;j++){
			if (::GetPaletteEntries((HPALETTE) (*pPal), j, 1, &entry))
			{
				V = max3(entry.peRed, entry.peGreen, entry.peBlue);
				S = (V!=0) ? (V-min3(entry.peRed, entry.peGreen, entry.peBlue))*255.0/V : 0;

				if (V == entry.peRed) H = (entry.peGreen - entry.peBlue)*60/S;
				else if (V == entry.peGreen) H = 180 + (entry.peBlue - entry.peRed)*60/S;
				else if (V == entry.peBlue) H = 240 + (entry.peRed - entry.peGreen)*60/S;

				if (H<0) H=H+360;
				H /= 2;
			
				entry.peRed = V;
				entry.peGreen = FloatToByte(S);
				entry.peBlue = FloatToByte(H);

				VERIFY(::SetPaletteEntries((HPALETTE) (*pPal),j,1,&entry));
			}
		}
	}

	CString str;
	str.Format("%f,%f", mint, maxt);
	AfxMessageBox(str);
}

CImage * CDipProcessor::Cov_8_To_24(CImage *pImage)
{
	if(pImage->GetDepth()>8){
		return NULL;
	}
	int width=pImage->GetWidth(),height=pImage->GetHeight(),colortype=pImage->GetColorType();
	CImage *image=new CImage;
	image->Create(width, height, 24, -1);
	ImagePointerType RawImage1=image->GetRawImage(),RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	CImagePalette* pPal=pImage->GetPalette();
	VERIFY(pPal);
	PALETTEENTRY entry;
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2;
	long EffWidth1=image->GetEffWidth(),EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,index;
	head1=RawImage1;
	head2=RawImage2;
	for (y=0; y<height; y++) {
		ImagePointer1=head1;
		ImagePointer2=head2;
		for (x=0; x<width; x++) {
			index=ImagePointer2[0];
			::GetPaletteEntries((HPALETTE) (*pPal), index, 1, &entry);
			ImagePointer1[0]=entry.peBlue;
			ImagePointer1[1]=entry.peGreen;
			ImagePointer1[2]=entry.peRed;
			ImagePointer1 +=3;
			ImagePointer2 ++;//=sDepth;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
	}
	return image;
}

CImage * CDipProcessor::Cov_24_To_8(CImage *pImage,BOOL bcolor)
{
	if(pImage->GetDepth()!=24||bcolor){
		return NULL;
	}
	int width=pImage->GetWidth(),height=pImage->GetHeight(),colortype=pImage->GetColorType();
	CImage *image=new CImage;
	image->Create(width, height, 8, colortype);

	ImagePointerType RawImage1=image->GetRawImage(),RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2;
	long EffWidth1=image->GetEffWidth(),EffWidth2=pImage->GetEffWidth();
	int x,y;
	static BYTE arr_byte[256];
	for(x=0;x<256;x++){
		arr_byte[x]=x;
	}
	CImagePalette* pPal=new CImagePalette(256,arr_byte,arr_byte,arr_byte);//green,blue);
	VERIFY(pPal);
	image->SetPalette(pPal);
	head1=RawImage1;
	head2=RawImage2;
	for (y=0; y<height; y++) {
		ImagePointer1=head1;
		ImagePointer2=head2;
		for (x=0; x<width; x++) {
			ImagePointer1[0]=ImagePointer2[0];
			ImagePointer1 ++;
			ImagePointer2 +=3;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
	}
	return image;
}

CImage * CDipProcessor::GetPart(CImage *pImage, int left, int top, int width, int height)
{
	if(left<-1||top<-1||left>=pImage->GetWidth()||top>=pImage->GetHeight()||width<1||height<1){
		return NULL;
	}
	if(left+width>pImage->GetWidth()){
		width=pImage->GetWidth()-left;
	}
	if(top+height>pImage->GetHeight()){
		height=pImage->GetHeight()-top;
	}
	CImage *image=new CImage;
	image->Create(width, height, pImage->GetDepth(), pImage->GetColorType());
	ImagePointerType RawImage1=image->GetRawImage(),RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2;
	long EffWidth1=image->GetEffWidth(),EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y;
	head1=RawImage1;
	head2=RawImage2 + EffWidth2*top;
	if(pImage->GetDepth()<16){
		VERIFY(pImage->GetPalette());
		image->SetPalette(new CImagePalette(pImage->GetPalette()));
		for (y=0; y<height; y++) {
			ImagePointer1=head1;
			ImagePointer2=head2+left;//*sDepth;
			for (x=0; x<width; x++) {
				ImagePointer1[0]=ImagePointer2[0];
				ImagePointer1 ++;//= sDepth;
				ImagePointer2 ++;//= sDepth;
			}
			head1+=EffWidth1;
			head2+=EffWidth2;
		}
	}else{
		for (y=0; y<height; y++) {
			ImagePointer1=head1;
			ImagePointer2=head2+left*sDepth;
			for (x=0; x<width; x++) {
				ImagePointer1[0]=ImagePointer2[0];
				ImagePointer1[1]=ImagePointer2[1];
				ImagePointer1[2]=ImagePointer2[2];
				ImagePointer1 +=sDepth;
				ImagePointer2 +=sDepth;
			}
			head1+=EffWidth1;
			head2+=EffWidth2;
		}
	}
	return image;
}

void CDipProcessor::GeoMirror_L(CImage *pImage)
{
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer1,ImagePointer2;
	int Width=pImage->GetWidth(),Height=pImage->GetHeight();
	int hWidth=(Width+1)/2;
	long EffWidth=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y;
	BYTE temp;
	ImagePointerType head=RawImage;
	if(pImage->GetDepth()>8){
		for (y=0; y<Height; y++) {
			ImagePointer1=head;
			ImagePointer2=head+(Width-1)*sDepth;
			for (x=0; x<hWidth; x++) {
				 temp=ImagePointer1[0];
				 ImagePointer1[0]=ImagePointer2[0];
				 ImagePointer2[0]=temp;
				 temp=ImagePointer1[1];
				 ImagePointer1[1]=ImagePointer2[1];
				 ImagePointer2[1]=temp;
				 temp=ImagePointer1[2];
				 ImagePointer1[2]=ImagePointer2[2];
				 ImagePointer2[2]=temp;
				 ImagePointer1+=sDepth;
				 ImagePointer2-=sDepth;
			}
			head+=EffWidth;
		}
	}else{
		for (y=0; y<Height; y++) {
			ImagePointer1=head;
			ImagePointer2=head+(Width-1);//*sDepth;
			for (x=0; x<hWidth; x++) {
				 temp=ImagePointer1[0];
				 ImagePointer1[0]=ImagePointer2[0];
				 ImagePointer2[0]=temp;
				 ImagePointer1++;//=sDepth;
				 ImagePointer2--;//=sDepth;
			}
			head+=EffWidth;
		}
	}
}

void CDipProcessor::GeoMirror_H(CImage *pImage)
{
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer1,ImagePointer2;
	int Width=pImage->GetWidth(),Height=pImage->GetHeight();
	int hHeight=(Height+1)/2;
	long EffWidth=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y;
	BYTE temp;
	ImagePointerType head1=RawImage,head2=RawImage+(Height-1)*EffWidth;
	if(pImage->GetDepth()>8){
		for (y=0; y<hHeight; y++) {
			ImagePointer1=head1;
			ImagePointer2=head2;
			for (x=0; x<Width; x++) {
				 temp=ImagePointer1[0];
				 ImagePointer1[0]=ImagePointer2[0];
				 ImagePointer2[0]=temp;
				 temp=ImagePointer1[1];
				 ImagePointer1[1]=ImagePointer2[1];
				 ImagePointer2[1]=temp;
				 temp=ImagePointer1[2];
				 ImagePointer1[2]=ImagePointer2[2];
				 ImagePointer2[2]=temp;
				 ImagePointer1+=sDepth;
				 ImagePointer2+=sDepth;
			}
			head1+=EffWidth;
			head2-=EffWidth;
		}
	}else{
		for (y=0; y<hHeight; y++) {
			ImagePointer1=head1;
			ImagePointer2=head2;
			for (x=0; x<Width; x++) {
				 temp=ImagePointer1[0];
				 ImagePointer1[0]=ImagePointer2[0];
				 ImagePointer2[0]=temp;
				 ImagePointer1++;//=sDepth;
				 ImagePointer2++;//=sDepth;
			}
			head1+=EffWidth;
			head2-=EffWidth;
		}
	}
}

CImage * CDipProcessor::PointMinus(CImage *p1, CImage *p2)
{
	CImage *np1,*np2,*image;
	BOOL bCopy1=FALSE,bCopy2=FALSE;
	if(p1->GetDepth()<16){
		np1=Cov_8_To_24(p1);
		VERIFY(np1);
		bCopy1=TRUE;
	}else{
		np1=p1;
	}
	if(p2->GetDepth()<16){
		np2=Cov_8_To_24(p2);
		VERIFY(np2);
		bCopy2=TRUE;
	}else{
		np2=p2;
	}
	int Width=p1->GetWidth(),Height=p1->GetHeight();
	if(Width!=p2->GetWidth()||Height!=p2->GetHeight()){
		CImage *temp=Sys_Size(np2,Width,Height);
		VERIFY(temp);
		if(bCopy2){
			delete np2;
			np2=temp;
		}else{
			np2=temp;
		}
		bCopy2=TRUE;
	}
	image=new CImage;
	VERIFY(image);
	image->Create(Width,Height,24,-1);
	ImagePointerType RawImage=image->GetRawImage();
	ImagePointerType RawImage1=np1->GetRawImage();
	ImagePointerType RawImage2=np2->GetRawImage();
	VERIFY(RawImage);
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,ImagePointer;
	long EffWidth=image->GetEffWidth();
	int sDepth1=np1->GetDepth()>>3,
		sDepth2=np2->GetDepth()>>3;
	int x,y;
	for (y=0; y<Height; y++) {
		for (x=0; x<Width; x++) {
			ImagePointer=RawImage+y*EffWidth+x*3;
			ImagePointer1=RawImage1+y*EffWidth+x*sDepth1;
			ImagePointer2=RawImage2+y*EffWidth+x*sDepth2;
			/*
			if(ImagePointer1[0]>ImagePointer2[0])
			{
				ImagePointer[0]=0;//BYTE(abs(ImagePointer1[0]-ImagePointer2[0]));
				ImagePointer[1]=BYTE(abs(ImagePointer1[1]-ImagePointer2[1]));
				ImagePointer[2]=0;//BYTE(abs(ImagePointer1[2]-ImagePointer2[2]));
			}
			else if (ImagePointer1[0]<ImagePointer2[0])
			{
				ImagePointer[0]=0;//BYTE(abs(ImagePointer1[0]-ImagePointer2[0]));
				ImagePointer[1]=0;//BYTE(abs(ImagePointer1[1]-ImagePointer2[1]));
				ImagePointer[2]=BYTE(abs(ImagePointer1[2]-ImagePointer2[2]));
			}
			else
			{
				ImagePointer[0]=ImagePointer1[2];//BYTE(abs(ImagePointer1[0]-ImagePointer2[0]));
				ImagePointer[1]=0;
				ImagePointer[2]=0;//BYTE(abs(ImagePointer1[2]-ImagePointer2[2]));
			}
			*/

			ImagePointer[0]=BYTE(abs(ImagePointer1[0]-ImagePointer2[0]));
			ImagePointer[1]=BYTE(abs(ImagePointer1[1]-ImagePointer2[1]));
			ImagePointer[2]=BYTE(abs(ImagePointer1[2]-ImagePointer2[2]));
		}
	}
	if(bCopy1) delete np1;
	if(bCopy2) delete np2;
	return image;
}

void CDipProcessor::SetNColor(CImage *pImage, BYTE n)
{
	BYTE per=255/n,t;
	for(int i=0;i<256;i++){
		t=i/per;
		if(t==n-1)
			r[i]=g[i]=b[i]=255;
		else
			r[i]=g[i]=b[i]=t*per;
	}
	DoPoint(pImage);
}

void CDipProcessor::GeoTranlate_L(CImage *&pImage, int i)
{
	if(!i) return;
	int Width=pImage->GetWidth(),Height=pImage->GetHeight();
	if(i>=Width||-i>=Width){
		CImage *temp=new CImage(pImage);
		VERIFY(temp);
		delete pImage;
		pImage=temp;
		return;
	}
	int begin,end,len;
	int sDepth=pImage->GetDepth()>>3;
	if(sDepth==0) sDepth=1;
	int psDepth,sDepth1,sDepth2;
	if(i>0){
		begin=0;
		end=i;
		len=Width-i;
		psDepth=-sDepth;
		sDepth1=(Width-1)*sDepth;
		sDepth2=(Width-i-1)*sDepth;
	}else{
		begin=Width+i;
		end=Width;
		len=Width+i;
		psDepth=sDepth;
		sDepth1=0;
		sDepth2=-i*sDepth;
	}
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer1,ImagePointer2;
	long EffWidth=pImage->GetEffWidth();
	int x,y;
	ImagePointerType head=RawImage;
	if(pImage->GetDepth()>8){
		for (y=0; y<Height; y++) {
			ImagePointer1=head+sDepth1;
			ImagePointer2=head+sDepth2;
			for (x=0; x<len; x++) {
				ImagePointer1[0]=ImagePointer2[0];
				ImagePointer1[1]=ImagePointer2[1];
				ImagePointer1[2]=ImagePointer2[2];
				ImagePointer1+=psDepth;
				ImagePointer2+=psDepth;
			}
			ImagePointer1=head+begin*sDepth;
			for(x=begin;x<end;x++){
				ImagePointer1[0]=0;
				ImagePointer1[1]=0;
				ImagePointer1[2]=0;
				ImagePointer1+=sDepth;
			}
			head+=EffWidth;
		}
	}else{
		VERIFY(pImage->GetPalette());
		int index=pImage->GetPalette()->GetPixel(0,0,0);
		for (y=0; y<Height; y++) {
			ImagePointer1=head+sDepth1;
			ImagePointer2=head+sDepth2;
			for (x=0; x<len; x++) {
				ImagePointer1[0]=ImagePointer2[0];
				ImagePointer1+=psDepth;
				ImagePointer2+=psDepth;
			}
			ImagePointer1=head+begin*sDepth;
			for(x=begin;x<end;x++){
				ImagePointer1[0]=index;
				ImagePointer1+=sDepth;
			}
			head+=EffWidth;
		}
	}
}

void CDipProcessor::GeoTranlate_H(CImage *&pImage, int i)
{
	if(!i) return;
	int Width=pImage->GetWidth(),Height=pImage->GetHeight();
	if(i>=Height||-i>=Height){
		CImage *temp=new CImage(pImage);
		VERIFY(temp);
		delete pImage;
		pImage=temp;
		return;
	}
	int begin,end,len;
	int sDepth=pImage->GetDepth()>>3;
	if(sDepth==0) sDepth=1;
	long EffWidth=pImage->GetEffWidth();
	int pEffWidth,Eff1,Eff2;
	if(i>0){
		begin=0;
		end=i;
		len=Height-i;
		pEffWidth=-EffWidth;
		Eff1=(Height-1)*EffWidth;
		Eff2=(Height-i-1)*EffWidth;
	}else{
		begin=Height+i;
		end=Height;
		len=Height+i;
		pEffWidth=EffWidth;
		Eff1=0;
		Eff2=-i*EffWidth;
	}
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer1,ImagePointer2;
	int x,y;
	ImagePointerType head1=RawImage+Eff1,head2=RawImage+Eff2;
	if(pImage->GetDepth()>8){
		for (y=0; y<len; y++) {
			ImagePointer1=head1;
			ImagePointer2=head2;
			for (x=0; x<Width; x++) {
				ImagePointer1[0]=ImagePointer2[0];
				ImagePointer1[1]=ImagePointer2[1];
				ImagePointer1[2]=ImagePointer2[2];
				ImagePointer1+=sDepth;
				ImagePointer2+=sDepth;
			}
			head1+=pEffWidth;
			head2+=pEffWidth;
		}
		ZeroMemory(RawImage+begin*EffWidth,(end-begin)*EffWidth);
	}else{
		VERIFY(pImage->GetPalette());
		int index=pImage->GetPalette()->GetPixel(0,0,0);
		for (y=0; y<len; y++) {
			ImagePointer1=head1;
			ImagePointer2=head2;
			for (x=0; x<Width; x++) {
				ImagePointer1[0]=ImagePointer2[0];
				ImagePointer1+=sDepth;
				ImagePointer2+=sDepth;
			}
			head1+=pEffWidth;
			head2+=pEffWidth;
		}
		FillMemory(RawImage+begin*EffWidth,(end-begin)*EffWidth,index);
	}
}

void CDipProcessor::GeoTranlate(CImage *&pImage, int i, int j)
{
	if(!i&&!j) return;
	if(!i){
		GeoTranlate_H(pImage,j);
		return;
	}
	if(!j){
		GeoTranlate_L(pImage,i);
		return;
	}
	int Width=pImage->GetWidth(),Height=pImage->GetHeight();
	if(j>=Height||-j>=Height||i>=Width||-i>=Width){
		CImage *temp=new CImage(pImage);
		VERIFY(temp);
		delete pImage;
		pImage=temp;
		return;
	}
	int ybegin,yend,ylen;
	long EffWidth=pImage->GetEffWidth();
	int pEffWidth,Eff1,Eff2;
	if(j>0){
		ybegin=0;
		yend=j;
		ylen=Height-j;
		pEffWidth=-EffWidth;
		Eff1=(Height-1)*EffWidth;
		Eff2=(Height-j-1)*EffWidth;
	}else{
		ybegin=Height+j;
		yend=Height;
		ylen=Height+j;
		pEffWidth=EffWidth;
		Eff1=0;
		Eff2=-j*EffWidth;
	}
	int xbegin,xend,xlen;
	int sDepth=pImage->GetDepth()>>3;
	if(sDepth==0) sDepth=1;
	int psDepth,sDepth1,sDepth2;
	if(i>0){
		xbegin=0;
		xend=i;
		xlen=Width-i;
		psDepth=-sDepth;
		sDepth1=(Width-1)*sDepth;
		sDepth2=(Width-i-1)*sDepth;
	}else{
		xbegin=Width+i;
		xend=Width;
		xlen=Width+i;
		psDepth=sDepth;
		sDepth1=0;
		sDepth2=-i*sDepth;
	}
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer1,ImagePointer2;
	int x,y;
	ImagePointerType head1=RawImage+Eff1,head2=RawImage+Eff2;
	if(pImage->GetDepth()>8){
		for (y=0; y<ylen; y++) {
			ImagePointer1=head1+sDepth1;
			ImagePointer2=head2+sDepth2;
			for (x=0; x<xlen; x++) {
				ImagePointer1[0]=ImagePointer2[0];
				ImagePointer1[1]=ImagePointer2[1];
				ImagePointer1[2]=ImagePointer2[2];
				ImagePointer1+=psDepth;
				ImagePointer2+=psDepth;
			}
			ImagePointer1=head1+xbegin*sDepth;
			for(x=xbegin;x<xend;x++){
				ImagePointer1[0]=0;
				ImagePointer1[1]=0;
				ImagePointer1[2]=0;
				ImagePointer1+=sDepth;
			}
			head1+=pEffWidth;
			head2+=pEffWidth;
		}
		ZeroMemory(RawImage+ybegin*EffWidth,(yend-ybegin)*EffWidth);
	}else{
		VERIFY(pImage->GetPalette());
		int index=pImage->GetPalette()->GetPixel(0,0,0);
		for (y=0; y<ylen; y++) {
			ImagePointer1=head1+sDepth1;
			ImagePointer2=head2+sDepth2;
			for (x=0; x<xlen; x++) {
				ImagePointer1[0]=ImagePointer2[0];
				ImagePointer1+=psDepth;
				ImagePointer2+=psDepth;
			}
			ImagePointer1=head1+xbegin*sDepth;
			for(x=xbegin;x<xend;x++){
				ImagePointer1[0]=index;
				ImagePointer1+=sDepth;
			}
			head1+=pEffWidth;
			head2+=pEffWidth;
		}
		FillMemory(RawImage+ybegin*EffWidth,(yend-ybegin)*EffWidth,index);
	}
}

void CDipProcessor::PointTransMinus(CImage *&pImage)
{
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		VERIFY(temp);
		delete pImage;
		pImage=temp;
	}
	int Width=pImage->GetWidth(),Height=pImage->GetHeight();
	int xoff=1,yoff=1,xWidth=Width-xoff,yHeight=Height-yoff;
	int sDepth=pImage->GetDepth()>>3;
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer1,ImagePointer2;
	long EffWidth=pImage->GetEffWidth();
	int x,y;
	BYTE t;
	ImagePointerType head=RawImage;
	for (y=0; y<yHeight; y++) {
		ImagePointer1=head;
		ImagePointer2=head+sDepth*xoff+yoff*EffWidth;
		for (x=0; x<xWidth; x++) {
			t=(ImagePointer1[0]-ImagePointer2[0])/2+127;
			ImagePointer1[0]=t>255?255:t;
			t=(ImagePointer1[1]-ImagePointer2[1])/2+127;
			ImagePointer1[1]=t>255?255:t;
			t=(ImagePointer1[2]-ImagePointer2[2])/2+127;
			ImagePointer1[2]=t>255?255:t;
			ImagePointer1+=sDepth;
			ImagePointer2+=sDepth;
		}
		head+=EffWidth;
	}
}

CImage* CDipProcessor::Sys_Size(CImage *pImage, int nWidth, int nHeight)
{
    LPBITMAPINFO lpbmi = NULL; 
    LPBYTE       lpSourceBits, lpTargetBits;
    HDC			 hDC = NULL, hSourceDC, hTargetDC;
    HBITMAP      hSourceBitmap, hTargetBitmap, hOldTargetBitmap, hOldSourceBitmap; 
    DWORD        dwSourceBitsSize, dwTargetBitsSize;

	CWaitCursor wait;

	LPBITMAPINFO lpSrcDIB =(LPBITMAPINFO) pImage->GetImplementation()->GetBits();
	if (! lpSrcDIB)
	{
		return NULL;
	}
	CImage *image=new CImage;
	image->Create(nWidth, nHeight, pImage->GetDepth(), pImage->GetColorType());
	
	lpbmi=(LPBITMAPINFO) image->GetImplementation()->GetBits();
    hDC = GetDC( NULL ); 
	if(pImage->GetPalette()){
		image->SetPalette(new CImagePalette(pImage->GetPalette()));
		hTargetBitmap = CreateDIBSection( hDC, lpbmi, DIB_PAL_COLORS, (VOID **)&lpTargetBits, NULL, 0 ); 
		hSourceBitmap = CreateDIBSection( hDC, lpSrcDIB, DIB_PAL_COLORS, (VOID **)&lpSourceBits, NULL, 0 ); 
	}else{
		hTargetBitmap = CreateDIBSection( hDC, lpbmi, DIB_RGB_COLORS, (VOID **)&lpTargetBits, NULL, 0 ); 
		hSourceBitmap = CreateDIBSection( hDC, lpSrcDIB, DIB_RGB_COLORS, (VOID **)&lpSourceBits, NULL, 0 ); 
	}
    hSourceDC = CreateCompatibleDC( hDC ); 
    hTargetDC = CreateCompatibleDC( hDC ); 
 
	dwSourceBitsSize = lpSrcDIB->bmiHeader.biHeight * pImage->GetEffWidth(); 
	dwTargetBitsSize = lpbmi->bmiHeader.biHeight * image->GetEffWidth(); 
    memcpy(lpSourceBits, pImage->GetRawImage(), dwSourceBitsSize ); 
    
    hOldSourceBitmap = (HBITMAP)SelectObject( hSourceDC, hSourceBitmap );
    hOldTargetBitmap = (HBITMAP)SelectObject( hTargetDC, hTargetBitmap );
 
	SetStretchBltMode( hTargetDC, COLORONCOLOR ); 
	StretchBlt( hTargetDC, 0, 0, lpbmi->bmiHeader.biWidth, lpbmi->bmiHeader.biHeight, hSourceDC, 0, 0, lpSrcDIB->bmiHeader.biWidth, lpSrcDIB->bmiHeader.biHeight, SRCCOPY );
    SelectObject( hSourceDC, hOldSourceBitmap ); 
    SelectObject( hTargetDC, hOldTargetBitmap ); 
    DeleteDC( hSourceDC ); 
    DeleteDC( hTargetDC ); 
    ReleaseDC( NULL, hDC ); 
 
    GdiFlush(); 
 
    memcpy(image->GetRawImage(), lpTargetBits, dwTargetBitsSize ); 
 
    DeleteObject( hTargetBitmap ); 
    DeleteObject( hSourceBitmap ); 
	return image;
}

void CDipProcessor::PointPseudo(CImage *pImage)
{
	for(int i=0;i<256;i++){
		if(i<64){
			r[i]=0;
			g[i]=254-4*i;
			b[i]=255;
		}else if(i<128){
			r[i]=0;
			g[i]=4*i-254;
			b[i]=510-4*i;
		}else if(i<192){
			r[i]=4*i-510;
			g[i]=255;
			b[i]=0;
		}else{
			r[i]=255;
			g[i]=1022-4*i;
			b[i]=0;
		}
	}
	DoPoint(pImage);
}

CImage * CDipProcessor::PointAdd(CImage *p1, CImage *p2)
{
	CImage *np1,*np2,*image;
	BOOL bCopy1=FALSE,bCopy2=FALSE;
	if(p1->GetDepth()<16){
		np1=Cov_8_To_24(p1);
		VERIFY(np1);
		bCopy1=TRUE;
	}else{
		np1=p1;
	}
	if(p2->GetDepth()<16){
		np2=Cov_8_To_24(p2);
		VERIFY(np2);
		bCopy2=TRUE;
	}else{
		np2=p2;
	}
	int Width=p1->GetWidth(),Height=p1->GetHeight();
	if(Width!=p2->GetWidth()||Height!=p2->GetHeight()){
		CImage *temp=Sys_Size(np2,Width,Height);
		VERIFY(temp);
		if(bCopy2){
			delete np2;
			np2=temp;
		}else{
			np2=temp;
		}
		bCopy2=TRUE;
	}
	image=new CImage;
	VERIFY(image);
	image->Create(Width,Height,24,-1);
	ImagePointerType RawImage=image->GetRawImage();
	ImagePointerType RawImage1=np1->GetRawImage();
	ImagePointerType RawImage2=np2->GetRawImage();
	VERIFY(RawImage);
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,ImagePointer;
	long EffWidth=image->GetEffWidth();
	int sDepth1=np1->GetDepth()>>3,
		sDepth2=np2->GetDepth()>>3;
	int x,y;
	int t;
	for (y=0; y<Height; y++) {
		for (x=0; x<Width; x++) {
			ImagePointer=RawImage+y*EffWidth+x*3;
			ImagePointer1=RawImage1+y*EffWidth+x*sDepth1;
			ImagePointer2=RawImage2+y*EffWidth+x*sDepth2;
			t = ImagePointer1[0]+ImagePointer2[0];
			ImagePointer[0]=BYTE(t/2);
			t = ImagePointer1[1]+ImagePointer2[1];
			ImagePointer[1]=BYTE(t/2);
			t = ImagePointer1[2]+ImagePointer2[2];
			ImagePointer[2]=BYTE(t/2);
			/*
			if(ImagePointer1[0] > 32)
			{
				ImagePointer[0]=max(ImagePointer1[0],ImagePointer2[0]);//(ImagePointer1[0]+ImagePointer2[0])/2;
				ImagePointer[1]=max(ImagePointer1[0],ImagePointer2[0]);//(ImagePointer1[1]+ImagePointer2[1])/2;
				ImagePointer[2]=max(ImagePointer1[0],ImagePointer2[0]);//(ImagePointer1[2]+ImagePointer2[2])/2;
			}
			else
			{
				ImagePointer[0]=ImagePointer1[0];
				ImagePointer[1]=ImagePointer1[0];
				ImagePointer[2]=ImagePointer1[0];
			}
			*/
		}
	}
	if(bCopy1) delete np1;
	if(bCopy2) delete np2;
	return image;
}

CImage * CDipProcessor::PointAnd(CImage *p1, CImage *p2)
{
	CImage *np1,*np2,*image;
	BOOL bCopy1=FALSE,bCopy2=FALSE;
	if(p1->GetDepth()<16){
		np1=Cov_8_To_24(p1);
		VERIFY(np1);
		bCopy1=TRUE;
	}else{
		np1=p1;
	}
	if(p2->GetDepth()<16){
		np2=Cov_8_To_24(p2);
		VERIFY(np2);
		bCopy2=TRUE;
	}else{
		np2=p2;
	}
	int Width=p1->GetWidth(),Height=p1->GetHeight();
	if(Width!=p2->GetWidth()||Height!=p2->GetHeight()){
		CImage *temp=Sys_Size(np2,Width,Height);
		VERIFY(temp);
		if(bCopy2){
			delete np2;
			np2=temp;
		}else{
			np2=temp;
		}
		bCopy2=TRUE;
	}
	image=new CImage;
	VERIFY(image);
	image->Create(Width,Height,24,-1);
	ImagePointerType RawImage=image->GetRawImage();
	ImagePointerType RawImage1=np1->GetRawImage();
	ImagePointerType RawImage2=np2->GetRawImage();
	VERIFY(RawImage);
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,ImagePointer;
	long EffWidth=image->GetEffWidth();
	int sDepth1=np1->GetDepth()>>3,
		sDepth2=np2->GetDepth()>>3;
	int x,y;
	for (y=0; y<Height; y++) {
		for (x=0; x<Width; x++) {
			ImagePointer=RawImage+y*EffWidth+x*3;
			ImagePointer1=RawImage1+y*EffWidth+x*sDepth1;
			ImagePointer2=RawImage2+y*EffWidth+x*sDepth2;
			ImagePointer[0]=min(ImagePointer1[0] , ImagePointer2[0]);
			ImagePointer[1]=min(ImagePointer1[1] , ImagePointer2[1]);
			ImagePointer[2]=min(ImagePointer1[2] , ImagePointer2[2]);
		}
	}
	if(bCopy1) delete np1;
	if(bCopy2) delete np2;
	return image;
}

void CDipProcessor::CutPart(CImage *pImage, int left, int top, int width, int height)
{
	if(left<0||top<0||left>=pImage->GetWidth()||top>=pImage->GetHeight()||width<1||height<1){
		return;
	}
	if(left+width>pImage->GetWidth()){
		width=pImage->GetWidth()-left;
	}
	if(top+height>pImage->GetHeight()){
		height=pImage->GetHeight()-top;
	}
	ImagePointerType RawImage2=pImage->GetRawImage();
	VERIFY(RawImage2);
	ImagePointerType ImagePointer2,head2;
	long EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y;
	head2=RawImage2 + EffWidth2*top;
	if(pImage->GetDepth()<16){
		VERIFY(pImage->GetPalette());
		int index=pImage->GetPalette()->GetPixel(255,255,255);
		for (y=0; y<height; y++) {
			ImagePointer2=head2+left;//*sDepth;
			for (x=0; x<width; x++) {
				ImagePointer2[0]=index;
				ImagePointer2 ++;//= sDepth;
			}
			head2+=EffWidth2;
		}
	}else{
		for (y=0; y<height; y++) {
			ImagePointer2=head2+left*sDepth;
			for (x=0; x<width; x++) {
				ImagePointer2[0]=255;
				ImagePointer2[1]=255;
				ImagePointer2[2]=255;
				ImagePointer2 +=sDepth;
			}
			head2+=EffWidth2;
		}
	}
}

void CDipProcessor::MergePart(CImage *&pImage,CImage *image, int left, int top)
{
	if(!image||!pImage) return;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	int width=image->GetWidth(),height=image->GetHeight();
	if(left>=pImage->GetWidth()||top>=pImage->GetHeight()||width<1||height<1){
		return;
	}
	if(left+width>pImage->GetWidth()){
		if(left<0)
			width=pImage->GetWidth();
		else
			width=pImage->GetWidth()-left;
	}
	if(top+height>pImage->GetHeight()){
		if(top<0)
			height=pImage->GetHeight();
		else
			height=pImage->GetHeight()-top;
	}
	int rleft=0,rtop=0;
	if(left<0){
		width+=left;
		rleft=-left;
		left=0;
	}
	if(top<0){
		height+=top;
		rtop=-top;
		top=0;
	}
	ImagePointerType RawImage2=pImage->GetRawImage();
	VERIFY(RawImage2);
	ImagePointerType ImagePointer2,head2;
	long EffWidth2=pImage->GetEffWidth();
	int sDepth2=pImage->GetDepth()>>3;
	
	ImagePointerType RawImage1=image->GetRawImage();
	VERIFY(RawImage1);
	ImagePointerType ImagePointer1,head1;
	long EffWidth1=image->GetEffWidth();
	int sDepth1=image->GetDepth()>>3;
	
	int x,y;
	head2=RawImage2 + EffWidth2*top;
	head1=RawImage1 + EffWidth1*rtop;
	if(image->GetDepth()<16){
		CImagePalette* pPal=image->GetPalette();
		VERIFY(pPal);
		PALETTEENTRY entry;
		int index;
		for (y=0; y<height; y++) {
			ImagePointer2=head2+left*sDepth2;
			ImagePointer1=head1+rleft;
			for (x=0; x<width; x++) {
				index=ImagePointer1[0];
				::GetPaletteEntries((HPALETTE) (*pPal), index, 1, &entry);
				ImagePointer2[0]=entry.peBlue;
				ImagePointer2[1]=entry.peGreen;
				ImagePointer2[2]=entry.peRed;
				ImagePointer1 ++;
				ImagePointer2 +=sDepth2;
			}
			head2+=EffWidth2;
			head1+=EffWidth1;
		}
	}else{
		for (y=0; y<height; y++) {
			ImagePointer2=head2+left*sDepth2;
			ImagePointer1=head1+rleft*sDepth1;
			for (x=0; x<width; x++) {	
				ImagePointer2[0]=ImagePointer1[0];
				ImagePointer2[1]=ImagePointer1[1];
				ImagePointer2[2]=ImagePointer1[2];
				ImagePointer2 +=sDepth2;
				ImagePointer1 +=sDepth1;
			}
			head2+=EffWidth2;
			head1+=EffWidth1;
		}
	}
}

int * CDipProcessor::His(CImage *pImage, int ch,BOOL color)
{
	BYTE n;
	static int arr[257];
	for(int i=0;i<257;i++) arr[i]=0;
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer,head;
	int Width=pImage->GetWidth(),Height=pImage->GetHeight();
	long EffWidth=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	head=RawImage;
	if(pImage->GetDepth()>8){
		int m=ch ? 3-ch : 0;
		for (int y=0; y<Height; y++) {
			ImagePointer=head;
			for (int x=0; x<Width; x++) {
				if(ch || !color){
					n=ImagePointer[m];
				}else{
					n=(BYTE)(0.2989*ImagePointer[0]+0.5866*ImagePointer[1]+0.1144*ImagePointer[2]);
				}
				if(n>0)
				{
				arr[n]++;
				if(arr[256]<arr[n]) arr[256]=arr[n];
				}
				ImagePointer +=sDepth;
			}
			head+=EffWidth;
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		PALETTEENTRY entry;
		BYTE *p;
		switch(ch){
		case 3:
			p=&entry.peBlue;
			break;
		case 2:
			p=&entry.peGreen;
			break;
		default:
			p=&entry.peRed;
		}
		for (int y=0; y<Height; y++) {
			ImagePointer=head;
			for (int x=0; x<Width; x++) {
				if (::GetPaletteEntries((HPALETTE) (*pPal),ImagePointer[0] , 1, &entry))
				{
					if(ch || !color){
						n=*p;
					}else{
						n=(BYTE)(0.2989f*entry.peRed+0.5866f*entry.peGreen+0.1144f*entry.peBlue);
					}
					arr[n]++;
					if(arr[256]<arr[n]) arr[256]=arr[n];
				}
				ImagePointer++;
			}
			head+=EffWidth;
		}
	}
	return arr;
}

void CDipProcessor::HisEqu(CImage *&pImage)
{
	if(!pImage) return;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer,head;
	long EffWidth=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,i;
	head=RawImage;
	static int hr[256],hg[256],hb[256];
	for(i=0;i<256;i++) hr[i]=hg[i]=hb[i]=0;
	double size=height*width;
	for (y=0; y<height; y++){
		ImagePointer=head;
		for (x=0; x<width; x++){
			hr[ImagePointer[2]]++;
			hg[ImagePointer[1]]++;
			hb[ImagePointer[0]]++;
			ImagePointer+=sDepth;
		}
		head+=EffWidth;
	}
	int rs=0,gs=0,bs=0;
	for(i=0;i<256;i++){
		rs+=hr[i];
		gs+=hg[i];
		bs+=hb[i];
		r[i]=BYTE(rs*255/size);
		g[i]=BYTE(gs*255/size);
		b[i]=BYTE(bs*255/size);
	}
	DoPoint(pImage);
}

void CDipProcessor::DoPoint(CImage *pImage)
{
	if(pImage->GetDepth()>8){
		ImagePointerType RawImage=pImage->GetRawImage();
		VERIFY(RawImage);
		ImagePointerType ImagePointer,head;
		int Width=pImage->GetWidth(),Height=pImage->GetHeight();
		long EffWidth=pImage->GetEffWidth();
		int sDepth=pImage->GetDepth()>>3;
		head=RawImage;
		for (int y=0; y<Height; y++) {
			ImagePointer = head;
			for (int x=0; x<Width; x++) {
				ImagePointer[0]=b[ImagePointer[0]];
				ImagePointer[1]=g[ImagePointer[1]];
				ImagePointer[2]=r[ImagePointer[2]];
				ImagePointer+=sDepth;
			}
			head += EffWidth;
		}
	}else{
		CImagePalette* pPal=pImage->GetPalette();
		VERIFY(pPal);
		int size=pPal->GetEntryCount();
		PALETTEENTRY entry;
		for(int j=0;j<size;j++){
			if (::GetPaletteEntries((HPALETTE) (*pPal), j, 1, &entry))
			{
				entry.peRed=r[entry.peRed];
				entry.peBlue=b[entry.peBlue];
				entry.peGreen=g[entry.peGreen];
				VERIFY(::SetPaletteEntries((HPALETTE) (*pPal),j,1,&entry));
			}
		}
	}
}

void CDipProcessor::PointLine(CImage *pImage, float aa, int bb)
{
	int t;
	for(int i=0;i<256;i++){
		t=int(aa*i)+bb;
		if(t<0) t=0;
		else if(t>255) t=255;
		r[i]=g[i]=b[i]=t;
	}
	DoPoint(pImage);
}

HBITMAP CDipProcessor::ImageToDDB(CImage *pImage)
{
	HBITMAP     hBitmap;            // handle to device-dependent bitmap 
	HDC         hDC;                    // handle to DC 
	HPALETTE    hOldPal = NULL;    // handle to a palette 
 
    // if invalid handle, return NULL  
	if (!pImage) 
		return NULL;

    hDC = GetDC(NULL); 
    if (!hDC) 
    { 
        return NULL; 
    }
	
	// select and realize palette 
	
	if (pImage->GetDepth()<16) 
	{
		HPALETTE oldPal = ::SelectPalette(hDC, (HPALETTE) pImage->GetPalette()->m_hObject, FALSE);
		::RealizePalette(hDC);
	}
	
	// create bitmap from DIB info and bits 

	hBitmap = ::CreateDIBitmap(hDC,
		     pImage->GetImplementation()->GetBits(),
		     CBM_INIT, 
			 pImage->GetRawImage(), 
			 (LPBITMAPINFO) pImage->GetImplementation()->GetBits(),
			 DIB_PAL_COLORS);
	// restore previous palette 
	if (hOldPal) 
		SelectPalette(hDC, hOldPal, FALSE); 

	// clean up 
	ReleaseDC(NULL, hDC); 
	return hBitmap; 
}

HANDLE CDipProcessor::ImageToDIB(CImage *pImage)
{
	HANDLE h=pImage->GetImplementation()->GetBits();
	if (h == NULL)
		return NULL;

//	DWORD  dwLen = ::GlobalSize((HGLOBAL)h);
	DWORD dwSizeImage = pImage->GetHeight()*(DWORD)((pImage->GetWidth()*pImage->GetDepth()/8+3)&~3);
	DWORD  dwLen=sizeof(BITMAPINFOHEADER)+dwSizeImage + 1024;
	HANDLE hCopy = ::GlobalAlloc(GHND, dwLen);
	if (hCopy == NULL)
		return NULL;

	void* lpCopy = ::GlobalLock((HGLOBAL) hCopy);
	void* lp     = ::GlobalLock((HGLOBAL) h);
	::CopyMemory(lpCopy, lp, dwLen);

	if(pImage->GetDepth()<16){
		DibSetUsage(LPBITMAPINFOHEADER(lpCopy), (HPALETTE) (*pImage->GetPalette()), DIB_RGB_COLORS);
	}

	::GlobalUnlock(hCopy);
	::GlobalUnlock(h);

	return hCopy;
}

BOOL CDipProcessor::ConvoluteImage(CImage *&pImage, KERNEL *lpKernel, int Strength, int nKernelNum,int bColor)
{
	if(!pImage) return FALSE;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return FALSE;
	ImagePointerType RawImage1=image->GetRawImage(),
		             RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2;
	long EffWidth1=image->GetEffWidth(),
		 EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,off=1;
	head1=RawImage1+off*EffWidth1;
	head2=RawImage2;//+off*EffWidth2;
	int red, green, blue;
	BYTE OldR,OldG,OldB;
	height-=off;
	width-=off;
	JFun pFun=nKernelNum<2?DoConvoluteDIB1:DoConvoluteDIB2;
	for (y=off; y<height; y++){
		ImagePointer1=head1+off*3;
		ImagePointer2=head2;//+off*sDepth;
		for (x=off; x<width; x++){
				pFun(&red, &green, &blue, 
					ImagePointer2, sDepth,EffWidth2, lpKernel,bColor);
			OldB = ImagePointer2[0];
			OldG = ImagePointer2[1];
			OldR = ImagePointer2[2];
			// When we get here, red, green and blue have the new RGB value.
			if (Strength != MAX_STRENGTH) 
			{
				// Interpolate pixel data
				red   = OldR + int(((red - OldR) * Strength) / float(MAX_STRENGTH));
				green = OldG + int(((green - OldG) * Strength) / float(MAX_STRENGTH));
				blue  = OldB + int(((blue - OldB) * Strength) / float(MAX_STRENGTH));
			}
			ImagePointer1[0]=BOUND(blue, 0, 255);
			ImagePointer1[1]=BOUND(green, 0, 255);
			ImagePointer1[2]=BOUND(red, 0, 255);
			ImagePointer1+=3;
			ImagePointer2+=sDepth;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
	}
	delete pImage;
	pImage=image;
	return TRUE;
}

void CDipProcessor::DoConvoluteDIB1(int *red, int *green, int *blue, ImagePointerType p,
					int sDepth,long EffWidth, KERNEL *lpKernel,int bColor)
{
	static BYTE b[9], g[9], r[9];
	
//	ImagePointerType p=pt-EffWidth-sDepth;
	b[0] = p[0];g[0] = p[1];r[0] = p[2];
	p+=sDepth;
	b[1] = p[0];g[1] = p[1];r[1] = p[2];
	p+=sDepth;
	b[2] = p[0];g[2] = p[1];r[2] = p[2];
	p+=EffWidth;
	b[5] = p[0];g[5] = p[1];r[5] = p[2];
	p-=sDepth;
	b[4] = p[0];g[4] = p[1];r[4] = p[2];
	p-=sDepth;
	b[3] = p[0];g[3] = p[1];r[3] = p[2];
	p+=EffWidth;
	b[6] = p[0];g[6] = p[1];r[6] = p[2];
	p+=sDepth;
	b[7] = p[0];g[7] = p[1];r[7] = p[2];
	p+=sDepth;
	b[8] = p[0];g[8] = p[1];r[8] = p[2];

	*red = *green = *blue = 0;
	if(bColor){
		for (int k=0; k<9; ++k)
		{
			*red   += lpKernel->Element[k]*r[k];
			*green += lpKernel->Element[k]*g[k];
			*blue  += lpKernel->Element[k]*b[k];
		}
	}else{
		for (int k=0; k<9; ++k)
		{
			*red   += lpKernel->Element[k]*r[k];
		}
		*green=*blue=*red;
	}

	if (lpKernel->Divisor != 1) 
	{
		*red   = int(*red/lpKernel->Divisor);
		*green = int(*green/lpKernel->Divisor);
		*blue  = int(*blue/lpKernel->Divisor);
	}
	*red   = abs(*red);
	*green = abs(*green);
	*blue  = abs(*blue);
}

void CDipProcessor::DoConvoluteDIB2(int *red, int *green, int *blue, ImagePointerType p,
					int sDepth,long EffWidth, KERNEL *lpKernel,int bColor)
{
	static BYTE b[9], g[9], r[9];
	
//	ImagePointerType p=pt-EffWidth-sDepth;
	b[0] = p[0];g[0] = p[1];r[0] = p[2];
	p+=sDepth;
	b[1] = p[0];g[1] = p[1];r[1] = p[2];
	p+=sDepth;
	b[2] = p[0];g[2] = p[1];r[2] = p[2];
	p+=EffWidth;
	b[5] = p[0];g[5] = p[1];r[5] = p[2];
	p-=sDepth;
	b[4] = p[0];g[4] = p[1];r[4] = p[2];
	p-=sDepth;
	b[3] = p[0];g[3] = p[1];r[3] = p[2];
	p+=EffWidth;
	b[6] = p[0];g[6] = p[1];r[6] = p[2];
	p+=sDepth;
	b[7] = p[0];g[7] = p[1];r[7] = p[2];
	p+=sDepth;
	b[8] = p[0];g[8] = p[1];r[8] = p[2];

	int rs=0,gs=0,bs= 0;
	int k;
	if(bColor){
		for (k=0; k<9; ++k)
		{
			rs+= lpKernel->Element[k]*r[k];
			gs+= lpKernel->Element[k]*g[k];
			bs+= lpKernel->Element[k]*b[k];
		}
	}else{
		for (k=0; k<9; ++k)
		{
			rs+= lpKernel->Element[k]*r[k];
		}
	}
	float s=lpKernel->Divisor*lpKernel->Divisor;
	lpKernel++;
	int rt=0,gt=0,bt=0;
	if(bColor){
		for (k=0; k<9; ++k)
		{
			rt+= lpKernel->Element[k]*r[k];
			gt+= lpKernel->Element[k]*g[k];
			bt+= lpKernel->Element[k]*b[k];
		}
	}else{
		for (k=0; k<9; ++k)
		{
			rt+= lpKernel->Element[k]*r[k];
		}
	}
	float t=lpKernel->Divisor*lpKernel->Divisor;
	if(bColor){
		*red   = BYTE(sqrt(rs*rs/s+rt*rt/t));
		*green = BYTE(sqrt(gs*gs/s+gt*gt/t));
		*blue  = BYTE(sqrt(bs*bs/s+bt*bt/t));
	}else{
		*red   = BYTE(sqrt(rs*rs/s+rt*rt/t));
		*green=*blue=*red;
	}
}

BOOL CDipProcessor::GaussLap(CImage *&pImage,int bColor)
{
	if(!pImage) return FALSE;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return FALSE;
	int *ppp=new int[width*height];
	int npwidth = width;
	if(!ppp) return FALSE;
	int *pppt;

	ImagePointerType RawImage1=image->GetRawImage(),
		             RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2,pt;
	long EffWidth1=image->GetEffWidth(),
		 EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,off=2,i;
	head1=RawImage1+off*EffWidth1;
	head2=RawImage2;//+off*EffWidth2;
	int r,g,b,max,min;
	height-=off;
	width-=off;
	if(bColor){
		for (y=off; y<height; y++){
			ImagePointer1=head1+off*3;
			ImagePointer2=head2;//+off*sDepth;
			for (x=off; x<width; x++){
				r=0,g=0,b=0;
				pt=ImagePointer2;//-off*EffWidth2-off*sDepth;
				r+=pt[2]*(-2);g+=pt[1]*(-2);b+=pt[0]*(-2);
				for(i=0;i<3;i++){
					pt+=sDepth;
					r+=pt[2]*(-4);g+=pt[1]*(-4);b+=pt[0]*(-4);
				}
				pt+=sDepth;
				r+=pt[2]*(-2);g+=pt[1]*(-2);b+=pt[0]*(-2);
				
				pt+=EffWidth2;
				r+=pt[2]*(-4);g+=pt[1]*(-4);b+=pt[0]*(-4);
				pt-=sDepth<<1;
				r+=pt[2]*(8);g+=pt[1]*(8);b+=pt[0]*(8);
				pt-=sDepth<<1;
				r+=pt[2]*(-4);g+=pt[1]*(-4);b+=pt[0]*(-4);
				
				pt+=EffWidth2;
				r+=pt[2]*(-4);g+=pt[1]*(-4);b+=pt[0]*(-4);
				pt+=sDepth;
				r+=pt[2]*(8);g+=pt[1]*(8);b+=pt[0]*(8);
				pt+=sDepth;
				r+=pt[2]*(24);g+=pt[1]*(24);b+=pt[0]*(24);
				pt+=sDepth;
				r+=pt[2]*(8);g+=pt[1]*(8);b+=pt[0]*(8);
				pt+=sDepth;
				r+=pt[2]*(-4);g+=pt[1]*(-4);b+=pt[0]*(-4);
				
				pt+=EffWidth2;
				r+=pt[2]*(-4);g+=pt[1]*(-4);b+=pt[0]*(-4);
				pt-=sDepth<<1;
				r+=pt[2]*(8);g+=pt[1]*(8);b+=pt[0]*(8);
				pt-=sDepth<<1;
				r+=pt[2]*(-4);g+=pt[1]*(-4);b+=pt[0]*(-4);
				
				pt+=EffWidth2;
				r+=pt[2]*(-2);g+=pt[1]*(-2);b+=pt[0]*(-2);
				for(i=0;i<3;i++){
					pt+=sDepth;
					r+=pt[2]*(-4);g+=pt[1]*(-4);b+=pt[0]*(-4);
				}
				pt+=sDepth;
				r+=pt[2]*(-2);g+=pt[1]*(-2);b+=pt[0]*(-2);
				
				
				ImagePointer1[0]=BOUND(b, 0, 255);
				ImagePointer1[1]=BOUND(g, 0, 255);
				ImagePointer1[2]=BOUND(r, 0, 255);
				ImagePointer1+=3;
				ImagePointer2+=sDepth;
			}
			head1+=EffWidth1;
			head2+=EffWidth2;
		}
	}else{
		max=0;
		min=200;
		pppt = ppp+off*npwidth;
		for (y=off; y<height; y++){
			pppt+=off;
			ImagePointer2=head2;//+off*sDepth;
			for (x=off; x<width; x++){
				b=0;
				pt=ImagePointer2;//-off*EffWidth2-off*sDepth;
				b+=pt[0]*(-2);
				for(i=0;i<3;i++){
					pt+=sDepth;
					b+=pt[0]*(-4);
				}
				pt+=sDepth;b+=pt[0]*(-2);
				
				pt+=EffWidth2;b+=pt[0]*(-4);
				pt-=sDepth<<1;b+=pt[0]*(8);
				pt-=sDepth<<1;b+=pt[0]*(-4);
				
				pt+=EffWidth2;b+=pt[0]*(-4);
				pt+=sDepth;b+=pt[0]*(8);
				pt+=sDepth;b+=pt[0]*(24);
				pt+=sDepth;b+=pt[0]*(8);
				pt+=sDepth;b+=pt[0]*(-4);
				
				pt+=EffWidth2;b+=pt[0]*(-4);
				pt-=sDepth<<1;b+=pt[0]*(8);
				pt-=sDepth<<1;b+=pt[0]*(-4);
				
				pt+=EffWidth2;b+=pt[0]*(-2);
				for(i=0;i<3;i++){
					pt+=sDepth;b+=pt[0]*(-4);
				}
				pt+=sDepth;b+=pt[0]*(-2);
				
				b/=100;
				if(b<0) b = -b;
				if(b>max) max=b;
				else if(b>0 && b<min) min = b;

				*pppt=b;
		
				ImagePointer2+=sDepth;
				pppt++;
			}
			pppt+=off;
			head2+=EffWidth2;
		}
		head1=RawImage1+off*EffWidth1;
		pppt = ppp+off*npwidth;
		r = max-min;
		g = r>>1;
		for (y=off; y<height; y++){
			pppt+=off;
			ImagePointer1=head1+off*3;
			for (x=off; x<width; x++){
				//*
				b = 
			//		*pppt;
			//	if(b<=0)
			//		b = 0;
			//	else b =255;
				//	*pppt;
				((*pppt-min)*255+g)/r;
				ImagePointer1[0]=BOUND(b, 0, 255);
				/*/
				if(*pppt < 0.01*r)
				{
					ImagePointer1[0] = 255;
				}
				else
				{
					ImagePointer1[0] = 0;
				}
				//*/
				ImagePointer1[1]=ImagePointer1[0];
				ImagePointer1[2]=ImagePointer1[0];
				ImagePointer1+=3;
				pppt++;
			}
			pppt+=off;
			head1+=EffWidth1;
		}
	}
	delete pImage;
	pImage=image;
	return TRUE;
}

void CDipProcessor::Convolute(CImage *&pImage, int strength,int nFilter,int bColor)
{
	switch(nFilter){
	case LF1:
		CDipProcessor::ConvoluteImage(pImage,&LP1,strength,1,bColor);
		break;
	case LF2:
		CDipProcessor::ConvoluteImage(pImage,&LP2,strength,1,bColor);
		break;
	case GAUSS:
		CDipProcessor::ConvoluteImage(pImage,&Gauss,strength,1,bColor);
		break;
	case HF1:
		CDipProcessor::ConvoluteImage(pImage,&HP1,strength,1,bColor);
		break;
	case HF2:
		CDipProcessor::ConvoluteImage(pImage,&HP2,strength,1,bColor);
		break;
	case HF3:
		CDipProcessor::ConvoluteImage(pImage,&HP3,strength,1,bColor);
		break;
	case ROBERTS:
		CDipProcessor::ConvoluteImage(pImage,Roberts,strength,2,bColor);
		break;
	case PREWITT:
		CDipProcessor::ConvoluteImage(pImage,Prewitt,strength,2,bColor);
		break;
	case SOBEL:
		CDipProcessor::ConvoluteImage(pImage,Sobel,strength,2,bColor);
		break;
	case ISOBEL:
		CDipProcessor::ConvoluteImage(pImage,ISobel,strength,2,bColor);
		break;
	case LAP1:
		CDipProcessor::ConvoluteImage(pImage,&Lap1,strength,1,bColor);
		break;
	case LAP2:
		CDipProcessor::ConvoluteImage(pImage,&Lap2,strength,1,bColor);
		break;
	case LAP3:
		CDipProcessor::ConvoluteImage(pImage,&Lap3,strength,1,bColor);
		break;
	case LAP4:
		CDipProcessor::ConvoluteImage(pImage,&Lap4,strength,1,bColor);
		break;
	}
}

void CDipProcessor::GeoAffine(CImage *&pImage, float cd, float ss, float nq, float xz,BOOL inter)
{
	if(!pImage) return;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return;
	ImagePointerType RawImage1=image->GetRawImage(),
		             RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1;
	long EffWidth1=image->GetEffWidth(),
		 EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y;
	head1=RawImage1;
	float nx,ny;
	int x1,y1;
	float t=xz*3.14146f/180.0f;
	float cs=float(cos(t)),sn=float(sin(t));
	float xoff=width/2.0f,yoff=height/2.0f;
	float xx,xy,yx,yy;
	xx=cd*cs;
	xy=cd*ss*nq*cs-cd*ss*sn;
	yx=cd*sn;
	yy=cd*ss*nq*sn+cd*ss*cs;
	t=xoff-xx*xoff-xy*yoff;
	yoff=yoff-yx*xoff-yy*yoff;
	xoff=t;
	if(inter){
		float fxb,fxb1;
		for (y=0; y<height; y++){
			ImagePointer1=head1;
			nx=xoff;
			ny=yoff;
			for (x=0; x<width; x++){
				x1=int(nx);
				y1=int(ny);
				if(nx>=0&&ny>=0&&x1<width-1&&y1<height-1){
					ImagePointer2=RawImage2+EffWidth2*y1+sDepth*x1;
					
					fxb=(x1+1-nx)*ImagePointer2[0]+(nx-x1)*ImagePointer2[sDepth];
					fxb1=(x1+1-nx)*ImagePointer2[EffWidth2]+(nx-x1)*ImagePointer2[sDepth+EffWidth2];
					ImagePointer1[0]=BYTE((y1+1-ny)*fxb+(ny-y1)*fxb1);
					
					fxb=(x1+1-nx)*ImagePointer2[1]+(nx-x1)*ImagePointer2[sDepth+1];
					fxb1=(x1+1-nx)*ImagePointer2[EffWidth2+1]+(nx-x1)*ImagePointer2[sDepth+EffWidth2+1];
					ImagePointer1[1]=BYTE((y1+1-ny)*fxb+(ny-y1)*fxb1);
					
					fxb=(x1+1-nx)*ImagePointer2[2]+(nx-x1)*ImagePointer2[sDepth+2];
					fxb1=(x1+1-nx)*ImagePointer2[EffWidth2+2]+(nx-x1)*ImagePointer2[sDepth+EffWidth2+2];
					ImagePointer1[2]=BYTE((y1+1-ny)*fxb+(ny-y1)*fxb1);
				}else{
					ImagePointer1[0]=ImagePointer1[1]=ImagePointer1[2]=0;
				}
				ImagePointer1+=3;
				nx+=xx;
				ny+=yx;
			}
			xoff+=xy;
			yoff+=yy;
			head1+=EffWidth1;
		}
	}else{
		for (y=0; y<height; y++){
			ImagePointer1=head1;
			nx=xoff;
			ny=yoff;
			for (x=0; x<width; x++){
				x1=int(nx+0.5);
				y1=int(ny+0.5);
				if(pImage->Inside(x1,y1)){
					ImagePointer2=RawImage2+EffWidth2*y1+sDepth*x1;
					ImagePointer1[0]=ImagePointer2[0];
					ImagePointer1[1]=ImagePointer2[1];
					ImagePointer1[2]=ImagePointer2[2];
				}else{
					ImagePointer1[0]=ImagePointer1[1]=ImagePointer1[2]=0;
				}
				ImagePointer1+=3;
				nx+=xx;
				ny+=yx;
			}
			xoff+=xy;
			yoff+=yy;
			head1+=EffWidth1;
		}
	}
	delete pImage;
	pImage=image;
}

void CDipProcessor::GeoTs(CImage *&pImage, float jl, int sj1, int sj2, float jj,BOOL inter)
{
	if(!pImage) return;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return;
	ImagePointerType RawImage1=image->GetRawImage(),
		             RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2;
	long EffWidth1=image->GetEffWidth(),
		 EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y;
	head1=RawImage1;
	head2=RawImage2;
	float nx,ny,nz;
	int x1,y1;
	float t=sj1*3.14146f/180.0f;
	float cs1=float(cos(t));
	t=sj2*3.14146f/180.0f;
	float cs2=float(cos(t));
	float xoff=width/2.0f,yoff=height/2.0f,zoff;
	float xx,xy,yx,yy;
	float A=1/float(sqrt(cs1*cs1+cs2*cs2));
	float B=float(sqrt(1-cs1*cs1-cs2*cs2));
	xx=-cs2*A*jj;
	xy=cs1*A*jj;
	yx=-cs1*A*B*jj;
	yy=-cs2*A*B*jj;
	t=xoff-xx*xoff-xy*yoff;
	yoff=(yoff-yx*xoff-yy*yoff)*jj;
	xoff=t*jj;
	zoff=cs1*xoff+cs2*yoff+jl/B;
	/*
	if(inter){
		float fxb,fxb1;
		for (y=0; y<height; y++){
			ImagePointer1=head1;
			nx=xoff;
			ny=yoff;
			for (x=0; x<width; x++){
				x1=int(nx);
				y1=int(ny);
				if(nx>=0&&ny>=0&&x1<width-1&&y1<height-1){
					ImagePointer2=RawImage2+EffWidth2*y1+sDepth*x1;
					
					fxb=(x1+1-nx)*ImagePointer2[0]+(nx-x1)*ImagePointer2[sDepth];
					fxb1=(x1+1-nx)*ImagePointer2[EffWidth2]+(nx-x1)*ImagePointer2[sDepth+EffWidth2];
					ImagePointer1[0]=BYTE((y1+1-ny)*fxb+(ny-y1)*fxb1);
					
					fxb=(x1+1-nx)*ImagePointer2[1]+(nx-x1)*ImagePointer2[sDepth+1];
					fxb1=(x1+1-nx)*ImagePointer2[EffWidth2+1]+(nx-x1)*ImagePointer2[sDepth+EffWidth2+1];
					ImagePointer1[1]=BYTE((y1+1-ny)*fxb+(ny-y1)*fxb1);
					
					fxb=(x1+1-nx)*ImagePointer2[2]+(nx-x1)*ImagePointer2[sDepth+2];
					fxb1=(x1+1-nx)*ImagePointer2[EffWidth2+2]+(nx-x1)*ImagePointer2[sDepth+EffWidth2+2];
					ImagePointer1[2]=BYTE((y1+1-ny)*fxb+(ny-y1)*fxb1);
				}else{
					ImagePointer1[0]=ImagePointer1[1]=ImagePointer1[2]=0;
				}
				ImagePointer1+=3;
				nx+=xx;
				ny+=yx;
			}
			xoff+=xy;
			yoff+=yy;
			head1+=EffWidth1;
		}
	}else{*/
		for (y=0; y<height; y++){
			ImagePointer2=head2;
			nx=xoff;
			ny=yoff;
			nz=zoff;
			for (x=0; x<width; x++){
				x1=int(nx/nz);
				y1=int(ny/nz);
				if(pImage->Inside(x1,y1)){
					ImagePointer1=RawImage1+EffWidth1*y1+3*x1;
					ImagePointer1[0]=ImagePointer2[0];
					ImagePointer1[1]=ImagePointer2[1];
					ImagePointer1[2]=ImagePointer2[2];
				}else{
					ImagePointer1[0]=ImagePointer1[1]=ImagePointer1[2]=0;
				}
				ImagePointer2+=3;
				nx+=xx;
				ny+=yx;
				nz-=cs1;
			}
			xoff+=xy;
			yoff+=yy;
			zoff-=cs2;
			head2+=EffWidth2;
		}
//	}
	delete pImage;
	pImage=image;
}

BOOL CDipProcessor::MedianFilter(CImage *&pImage,BOOL bColor) 
{
	if(!pImage) return FALSE;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return FALSE;
	ImagePointerType RawImage1=image->GetRawImage(),
		             RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2;
	long EffWidth1=image->GetEffWidth(),
		 EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,off=2;
	head1=RawImage1+off*EffWidth1;
	head2=RawImage2;
	int r,g,b;
	height-=off;
	width-=off;
	MFun pFun=bColor?DoMedianFilter1:DoMedianFilter2;
	for (y=off; y<height; y++){
		ImagePointer1=head1+off*3;
		ImagePointer2=head2;
		for (x=off; x<width; x++){
			pFun(&r, &g, &b,ImagePointer2,sDepth,EffWidth2);
			ImagePointer1[0]=BOUND(b, 0, 255);
			ImagePointer1[1]=BOUND(g, 0, 255);
			ImagePointer1[2]=BOUND(r, 0, 255);
			ImagePointer1+=3;
			ImagePointer2+=sDepth;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
	}
	delete pImage;
	pImage=image;
	return TRUE;
}
#define _MFILTER_SIZE 9
void msort(BYTE *p)
{
	int i,j;//,bj,lj;
	BYTE t;
	//*
	for(i=0;i<_MFILTER_SIZE-1;i++){
		for(j=i+1;j<_MFILTER_SIZE;j++){
			if(p[j]<p[i]){
				t=p[i];
				p[i]=p[j];
				p[j]=t;
			}
		}
	}
/*/
	static buf[_MFILTER_SIZE];
	int g,l,e;
	while(1){
		t=p[0];
		bj=lj=g=e=0;
		l=_MFILTER_SIZE;
		for(i=1;i<_MFILTER_SIZE;i++){
			if(p[i]>t){
				buf[g++]=p[i];
				bj=i;
			}else if(p[i]<t){
				buf[l--]=p[i];
				lj=i;
			}else e++;
		}
		if((e-abs(_MFILTER_SIZE-l-g))>=0) break;
		if(_MFILTER_SIZE-l>g) j=lj;
		else j=bj;
		p[0]=p[j];
		p[j]=t;
	}
*/
}

void CDipProcessor::DoMedianFilter1(int *red, int *green, 
	int *blue, ImagePointerType p,int sDepth,long EffWidth)
{
	static BYTE b[9], g[9], r[9];
	
	b[4] = p[0];g[4] = p[1];r[4] = p[2];
	p+=sDepth;
	b[1] = p[0];g[1] = p[1];r[1] = p[2];
	p+=sDepth;
	b[2] = p[0];g[2] = p[1];r[2] = p[2];
	p+=EffWidth;
	b[5] = p[0];g[5] = p[1];r[5] = p[2];
	p-=sDepth;
	b[0] = p[0];g[0] = p[1];r[0] = p[2];
	p-=sDepth;
	b[3] = p[0];g[3] = p[1];r[3] = p[2];
	p+=EffWidth;
	b[6] = p[0];g[6] = p[1];r[6] = p[2];
	p+=sDepth;
	b[7] = p[0];g[7] = p[1];r[7] = p[2];
	p+=sDepth;
	b[8] = p[0];g[8] = p[1];r[8] = p[2];

	msort(r);
	msort(g);
	msort(b);

	*red   = r[0];
	*green = g[0];
	*blue  = b[0];
}

void CDipProcessor::DoMedianFilter2(int *red, int *green, 
	int *blue, ImagePointerType p,int sDepth,long EffWidth)
{
	static BYTE b[9];
	
	b[4] = p[0];p+=sDepth;
	b[1] = p[0];p+=sDepth;
	b[2] = p[0];p+=EffWidth;
	b[5] = p[0];p-=sDepth;
	b[0] = p[0];p-=sDepth;
	b[3] = p[0];p+=EffWidth;
	b[6] = p[0];p+=sDepth;
	b[7] = p[0];p+=sDepth;
	b[8] = p[0];
	msort(b);

	*red   = b[0];
	*green = b[0];
	*blue  = b[0];
}

CImage* CDipProcessor::MorphErosion(CImage *&pImage, int *T, int m, int n,BOOL del)
{
	if(!pImage) return NULL;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return FALSE;
	ImagePointerType RawImage1=image->GetRawImage(),
		             RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2;
	long EffWidth1=image->GetEffWidth(),
		 EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,i,j;
	int xoff=m/2,yoff=n/2;
	head1=RawImage1+yoff*EffWidth1;
	head2=RawImage2;
	int r,g,b;
	int k,t;
	int *pT;
	height-=yoff;
	width-=xoff;
	ImagePointerType ptHead,pt2;

	for (y=yoff; y<height; y++){
		ImagePointer1=head1+yoff*3;
		ImagePointer2=head2;
		for (x=xoff; x<width; x++){
			b=ImagePointer2[0];
			g=ImagePointer2[1];
			r=ImagePointer2[2];
			ptHead=ImagePointer2;
			pT=T;
			for (j=0;j<n;j++){
				pt2=ptHead;
				for (i=0;i<m;i++)
				{
					t=*pT++;
					k=pt2[0]-t;
					if (k<b) b=k;
					k=pt2[1]-t;
					if (k<g) g=k;
					k=pt2[2]-t;
					if (k<r) r=k;
					pt2+=sDepth;
				}
				ptHead+=EffWidth2;
			}
			ImagePointer1[0]=b+1;
			ImagePointer1[1]=g+1;
			ImagePointer1[2]=r+1;
			ImagePointer1+=3;
			ImagePointer2+=sDepth;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
	}
	if(del){
		delete pImage;
		pImage=image;
	}
	return image;
}

CImage* CDipProcessor::MorphDilation(CImage *&pImage, int *T, int m, int n,BOOL del)
{
	if(!pImage) return NULL;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return FALSE;
	ImagePointerType RawImage1=image->GetRawImage(),
		             RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2;
	long EffWidth1=image->GetEffWidth(),
		 EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,i,j;
	int xoff=m/2,yoff=n/2;
	head1=RawImage1+yoff*EffWidth1;
	head2=RawImage2;
	int r,g,b;
	int k,t;
	int *pT;
	height-=yoff;
	width-=xoff;
	ImagePointerType ptHead,pt2;

	BOOL bb = FALSE;
	for (y=yoff; y<height; y++){
		ImagePointer1=head1+yoff*3;
		ImagePointer2=head2;
		for (x=xoff; x<width; x++){
			b=ImagePointer2[0];
			g=ImagePointer2[1];
			r=ImagePointer2[2];
			ptHead=ImagePointer2;
			pT=T;
			bb = FALSE;
			for (j=0;j<n;j++){
				pt2=ptHead;
				for (i=0;i<m;i++)
				{
					t=*pT++;
//					if(t && !pt2[0])
//					{
//						bb = TRUE;
//					}
					k=pt2[0]+t;
					if (k>b) b=k;
					k=pt2[1]+t;
					if (k>g) g=k;
					k=pt2[2]+t;
					if (k>r) r=k;
					pt2+=sDepth;
				}
				ptHead+=EffWidth2;
			}
//			if(!bb)
//				ImagePointer1[0]=255;
				ImagePointer1[0]=b-1;
//			else
//				ImagePointer1[0]=ImagePointer2[0];
			ImagePointer1[1]=ImagePointer1[0];
			ImagePointer1[2]=ImagePointer1[0];
			ImagePointer1+=3;
			ImagePointer2+=sDepth;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
	}
	if(del){
		delete pImage;
		pImage=image;
	}
	return image;
}

void CDipProcessor::ImageMinus(CImage *p1, CImage *p2)
{
	int Width=p1->GetWidth(),Height=p1->GetHeight();
	ImagePointerType RawImage1=p1->GetRawImage();
	ImagePointerType RawImage2=p2->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2;
	ImagePointerType head1,head2;
	int sDepth1=p1->GetDepth()>>3,
		sDepth2=p2->GetDepth()>>3;
	long EffWidth1=p1->GetEffWidth(),
		 EffWidth2=p2->GetEffWidth();
	int x,y;
	head1=RawImage1;
	head2=RawImage2;
	for (y=0; y<Height; y++) {
		ImagePointer1=head1;
		ImagePointer2=head2;
		for (x=0; x<Width; x++) {
			ImagePointer1[0]=BYTE(abs(ImagePointer1[0]-ImagePointer2[0]));
			ImagePointer1[1]=BYTE(abs(ImagePointer1[1]-ImagePointer2[1]));
			ImagePointer1[2]=BYTE(abs(ImagePointer1[2]-ImagePointer2[2]));
			ImagePointer1+=sDepth1;
			ImagePointer2+=sDepth2;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
	}
}

void CDipProcessor::ImageMax(CImage *p1, CImage *p2)
{
	int Width=p1->GetWidth(),Height=p1->GetHeight();
	ImagePointerType RawImage1=p1->GetRawImage();
	ImagePointerType RawImage2=p2->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2;
	ImagePointerType head1,head2;
	int sDepth1=p1->GetDepth()>>3,
		sDepth2=p2->GetDepth()>>3;
	long EffWidth1=p1->GetEffWidth(),
		 EffWidth2=p2->GetEffWidth();
	int x,y;
	head1=RawImage1;
	head2=RawImage2;
	for (y=0; y<Height; y++) {
		ImagePointer1=head1;
		ImagePointer2=head2;
		for (x=0; x<Width; x++) {
			if(ImagePointer2[0]>ImagePointer1[0])
				ImagePointer1[0]=ImagePointer2[0];
			if(ImagePointer2[1]>ImagePointer1[1])
				ImagePointer1[1]=ImagePointer2[1];
			if(ImagePointer2[2]>ImagePointer1[2])
				ImagePointer1[2]=ImagePointer2[2];
			ImagePointer1+=sDepth1;
			ImagePointer2+=sDepth2;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
	}
}

BOOL CDipProcessor::SUSAN(CImage *&pImage,int G,int T,BOOL bColor)
{
	if(!pImage) return FALSE;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return FALSE;
	ImagePointerType RawImage1=image->GetRawImage(),
		             RawImage2=pImage->GetRawImage();
	VERIFY(RawImage1);
	VERIFY(RawImage2);
	ImagePointerType ImagePointer1,ImagePointer2,head1,head2,pt,pthead2;
	long EffWidth1=image->GetEffWidth(),
		 EffWidth2=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,off=3;
	int off2=2;
	head1=RawImage1+off*EffWidth1;
	head2=RawImage2+off*EffWidth2;
	pthead2=RawImage2;
	int r, g, b;
	height-=off;
	width-=off;
	for (y=off; y<height; y++){
		ImagePointer1=head1+off*3;
		ImagePointer2=head2+off*sDepth;
		pt=pthead2+off2*sDepth;
		for (x=off; x<width; x++){
			b=ImagePointer2[0];
			g=ImagePointer2[1];
			r=ImagePointer2[2];
			DoSusan(&r, &g, &b,G,T, 
					pt, sDepth,EffWidth2,bColor);
			ImagePointer1[0]=BOUND(b, 0, 255);
			ImagePointer1[1]=BOUND(g, 0, 255);
			ImagePointer1[2]=BOUND(r, 0, 255);
			ImagePointer1+=3;
			ImagePointer2+=sDepth;
			pt+=sDepth;
		}
		head1+=EffWidth1;
		head2+=EffWidth2;
		pthead2+=EffWidth2;
	}
	delete pImage;
	pImage=image;
	return TRUE;
}

void CDipProcessor::DoSusan(int *r, int *g, int *b, int G,int T,
			 ImagePointerType pt, int sDepth,
			 long EffWidth,BOOL bColor)
{
	int num[7] ={3,5,7,7,7,5,3};
	int back[7]={-sDepth,-sDepth,0,0,sDepth,sDepth,0};
	int i,j;
	int nr=-1,ng=-1,nb=-1;
	ImagePointerType head=pt;

	if(bColor){
		for(i=0;i<7;i++){
			pt=head;
			for(j=0;j<num[i];j++){
				if(abs(pt[0]-*b)<T) nb++;
				if(abs(pt[1]-*g)<T) ng++;
				if(abs(pt[2]-*r)<T) nr++;
				pt+=sDepth;
			}
			head+=EffWidth;
			head+=back[i];
		}
		*b=nb<G?G-nb:0;
		*g=ng<G?G-ng:0;
		*r=nr<G?G-nr:0;
	}else{
		for(i=0;i<7;i++){
			pt=head;
			for(j=0;j<num[i];j++){
				if(abs(pt[0]-*b)<T) nb++;
				pt+=sDepth;
			}
			head+=EffWidth;
			head+=back[i];
		}
		*b= nb;//*255/259;
	//	nb<G?255:0;
		*g=*b;
		*r=*b;
	}
}
	
BOOL CDipProcessor::Canny(CImage *&pImage)
{
	if(!pImage) return FALSE;
	UINT n1 = GetTickCount();

	static int filterx[10*10]={
	0 ,  0 ,   0  ,    0 ,    0 ,    0 ,    0 ,   0 ,  0 , 0,
    0 ,  0 ,   2  ,    8 ,    8 ,   -8 ,   -8 ,  -2 ,  0 , 0,
    0 ,  3 ,  38  ,  171 ,  155 , -155 , -171 , -38 , -3 , 0,
    0 , 20 , 284  , 1260 , 1142 ,-1142 ,-1260 ,-284 ,-20 , 0,
    1 , 54 , 773  , 3426 , 3104 ,-3104 ,-3426 ,-773 ,-54 ,-1,
    1 , 54 , 773  , 3426 , 3104 ,-3104 ,-3426 ,-773 ,-54 ,-1,
    0 , 20 , 284  , 1260 , 1142 ,-1142 ,-1260 ,-284 ,-20 , 0,
    0 ,  3 ,  38  ,  171 ,  155 , -155 , -171 , -38 , -3 , 0,
    0 ,  0 ,   2  ,    8 ,    8 ,   -8 ,   -8 ,  -2 ,  0 , 0,
    0 ,  0 ,   0  ,    0 ,    0 ,    0 ,    0 ,   0 ,  0 , 0
    };
	int divx=10000;
	static int filtery[10*10]={  
	0 , 0 ,   0 ,    0 ,    1 ,    1 ,    0 ,   0 , 0 , 0,
	0 , 0 ,   3 ,   20 ,   54 ,   54 ,   20 ,   3 , 0 , 0,
	0 , 2 ,  38 ,  284 ,  773 ,  773 ,  284 ,  38 , 2 , 0,
	0 , 8 , 171 , 1260 , 3426 , 3426 , 1260 , 171 , 8 , 0,
	0 , 8 , 155 , 1142 , 3104 , 3104 , 1142 , 155 , 8 , 0,
	0 ,-8 ,-155 ,-1142 ,-3104 ,-3104 ,-1142 ,-155 ,-8 , 0,
	0 ,-8 ,-171 ,-1260 ,-3426 ,-3426 ,-1260 ,-171 ,-8 , 0,
	0 ,-2 ,- 38 ,- 284 ,- 773 ,- 773 ,- 284 ,- 38 ,-2 , 0,
	0 , 0 ,-  3 ,-  20 ,-  54 ,-  54 ,-  20 ,-  3 , 0 , 0,
	0 , 0 ,   0 ,    0 ,-   1 ,-   1 ,    0 ,   0 , 0 , 0
	};
	int divy=10000;

	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}

	int width=pImage->GetWidth(),height=pImage->GetHeight();
	CImage *image=new CImage;
	image->Create(width, height, 24, pImage->GetColorType());
	if(!image) return FALSE;
	ImagePointerType RawImage=image->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer,head;
	long EffWidth=image->GetEffWidth();
	head=RawImage+EffWidth+3;
	
	float *Ix =new float[width*height];
	float *Iy =new float[width*height];
	float *NVI=new float[width*height];
	float *Ibw=new float[width*height];
	float *p1,*p2,*p3,*p4,f1,f2,f3,f4,f5;

	int i,j;
	float tmax=-9999;
	float tmin=+9999;
	float tmax1=-9999;
	float tmin1=+9999;
		
	BYTE tt;

	ConvImage2(Ix,Iy,pImage,filterx,divx,filtery,divy);
//	ConvImage(Ix,pImage,filterx,divx);
//	ConvImage(Iy,pImage,filtery,divy);
	p1=Ix;
	p2=Iy;
	p3=NVI;

	for(j=0;j<height;j++){
		for(i=0;i<width;i++){
			f1=*p1++;
			f2=*p2++;
			f3=float(sqrt(f1*f1+f2*f2));
			if(fabs(f1) > fabs(f2))
			{
				f4=f2/f1;
			}
			else
			{
				f4=f1/f2;
			}
			if(f3>tmax)tmax=f3;
			if(f3<tmin)tmin=f3;
			if(f4>tmax1)tmax1=f4;
			if(f4<tmin1)tmin1=f4;
			*p3++=f3;
		}
	}

	float alfa=0.1f;
	float level;
	level=(alfa*(tmax-tmin)+tmin);

	p1=NVI;
	p2=Ibw;
	//��ֵ����
	
	//*
	for(j=0;j<height;j++){
		for(i=0;i<width;i++){
			f1=*p1++;
		//	if(f1>level) 
				*p2++=f1;
		//	else *p2++=level;
		}
	}
	//*/
	//˫���Բ�ֵϸ����
	float dx,dy;
	p1=Ix+width;
	p2=Iy+width;
	p3=NVI+width;
	p4=Ibw+width;
	for(j=1;j<height-1;j++){
		p1++;p2++;p3++;p4++;
		ImagePointer=head;
		for(i=1;i<width-1;i++){
			f1=*p4;
			//*
			if(f1>level){
			//*/
				f3=*p3;
				dx=(*p1)/f3;
				dy=(*p2)/f3;

				if(fabs(*p1) > fabs(*p2))
				{
					f4=atan(-(*p2)/(*p1))/3.14*180;
					if(f4<0)
						f4 = -90 -f4;
					else
						f4 = 90 -f4;
				}
				else
				{
					f4=atan(-(*p1)/(*p2))/3.15*180;
				}

				if(90-fabs(f4)<0.1)
				{
					f4=fabs(f4);
				}
				tt = BYTE((f3-tmin)/(tmax-tmin)*255+0.49);
				/*
				ImagePointer[0]=ImagePointer[1]=ImagePointer[2]=
				//BYTE( (f4+90)/(180)*255+0.49 );
				//BYTE( (f4+90)/(180)*(f3-tmin)/(tmax-tmin)*255 );
				//BYTE((f3-tmin)/(tmax-tmin)*255+0.49);
				tt;
				/*/
				f4 = Interpolation(i-dy,j-dx,p3-1-width,width,height);
				f5 = Interpolation(i+dy,j+dx,p3,width,height);

				if(f4<f1
				&& f5<f1){
					ImagePointer[0]=ImagePointer[1]=ImagePointer[2]=
					//	max(tt,( ((f1-f4)+(f1-f5))/f1*255 ) );
						255;
				}
				else
				{
					ImagePointer[0]=ImagePointer[1]=ImagePointer[2]=0;//tt;//min(tt,40);
				}
			}
			//*/
			p1++;p2++;p3++;p4++;
			ImagePointer+=3;
		}
		head+=EffWidth;
		p1++;p2++;p3++;p4++;
	}

	delete []Ix;
	delete []Iy;
	delete []NVI;
	delete []Ibw;
	delete pImage;
	pImage=image;
	
	UINT n2 = GetTickCount();
	CString str;
	str.Format("%d",n2-n1);
	AfxMessageBox(str);

	return TRUE;
}

float CDipProcessor::Interpolation(float nx,float ny,float *data,int sx,int sy)
{
	if(nx<0 || ny<0 || nx>sx-1 || ny>sy-1) return 0;
	int x=int(nx);
	int y=int(ny);
	float fxb1,fxb2;
	float t,temp;
	t=nx-x;
	temp=data[1]-data[0];
	fxb1=t*temp+data[0];
	fxb2=t*(data[sx+1]-data[sx]-temp)+data[sx]-data[0];
	return ((ny-y)*fxb2+fxb1);
}

BOOL CDipProcessor::ConvImage(float *out,CImage *pImage,int *T,int div)
{
	if(!pImage) return FALSE;
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer,head,pt,ptHead;
	long EffWidth=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	int x,y,i,j,ioff,joff,iend,jend;
	long sum;
	int *pT,*pTHead;
	float *pOut;
	head=RawImage;
	pOut=out;
	for (y=0; y<height; y++){
		ImagePointer=head;
		for (x=0; x<width; x++){
			
			ioff=x<5?5-x:0;
			iend=x>width-6?4+width-x:10;
			joff=y<5?5-y:0;
			jend=y>height-6?4+height-y:10;
			
			pTHead=T+joff;
			ptHead=ImagePointer;
			sum=0;
			for(j=joff;j<jend;j++){
				pT=pTHead+ioff;
				pt=ptHead;
				for(i=ioff;i<iend;i++){
					sum+=(*pt)*(*pT);
					pt+=sDepth;
					pT++;
				}
				ptHead+=EffWidth;
				pTHead+=10;
			}
			*pOut=float(double(sum)/div);
			if(x>=5) ImagePointer+=sDepth;
			pOut++;
		}
		if(y>=5) head+=EffWidth;
	}
	return TRUE;
}

BOOL CDipProcessor::ConvImage2(float *out1,float *out2,CImage *pImage,int *T1,int div1,int *T2,int div2)
{
	if(!pImage) return FALSE;
	
	int width=pImage->GetWidth(),height=pImage->GetHeight();
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer,head,pt,ptHead;
	long EffWidth=pImage->GetEffWidth();
	long DEffWidth=EffWidth<<1;
	long NEffWidth=EffWidth*9;
	int sDepth=pImage->GetDepth()>>3;
	int DsDepth=sDepth<<1;
	int NsDepth=sDepth*9;
	int x,y,i,j,ioff,joff,iend,jend,tx,ty,t1,t2;
	long sum1,sum2;
	int *pT1,*pTHead1,*pT2,*pTHead2;
	float *pOut1,*pOut2;
	head=RawImage;
	pOut1=out1;
	pOut2=out2;

	for (y=0; y<height; y++){
		ImagePointer=head;
		for (x=0; x<width; x++){
			
			ioff=x<5?5-x:0;
			iend=x>width-5?5+width-x:10;
			joff=y<5?5-y:0;
			jend=y>height-5?5+height-y:10;
			
			pTHead1=T1+joff;
			pTHead2=T2+joff;
			ptHead=ImagePointer;
			sum1=sum2=0;
			if(!ioff&&!joff&&iend==10&&jend==10){
				ty=NEffWidth;
				for(j=0;j<5;j++){
		 			pT1=pTHead1;
					pT2=pTHead2;
					pt=ptHead;
					tx=NsDepth;
					for(i=0;i<5;i++){
						t1=pt[0]-pt[tx+ty];
						t2=pt[tx]-pt[ty];
						if(*pT1)
						sum1+=(*pT1)*(t1-t2);
						if(*pT2)
						sum2+=(*pT2)*(t1+t2);
						pt+=sDepth;
						pT1++;
						pT2++;
						tx-=DsDepth;
					}
					ptHead+=EffWidth;
					pTHead1+=10;
					pTHead2+=10;
					ty-=DEffWidth;
				}
			}else{
				for(j=joff;j<jend;j++){
		 			pT1=pTHead1+ioff;
					pT2=pTHead2+ioff;
					pt=ptHead;
					for(i=ioff;i<iend;i++){
						sum1+=(*pt)*(*pT1);
						sum2+=(*pt)*(*pT2);
						pt+=sDepth;
						pT1++;
						pT2++;
					}
					ptHead+=EffWidth;
					pTHead1+=10;
					pTHead2+=10;
				}
			}
			*pOut1=float(double(sum1)/div1);
			*pOut2=float(double(sum2)/div2);
			if(x>=5) ImagePointer+=sDepth;
			pOut1++;
			pOut2++;
		}
		if(y>=5) head+=EffWidth;
	}
	return TRUE;
}

BOOL CDipProcessor::Thin(CImage *&pImage,BOOL white)
{
	//������㷨
	//��ȥ������������
	static int erasetable[256]={
					0,0,1,1,0,0,1,1,    	1,1,0,1,1,1,0,1,
					1,1,0,0,1,1,1,1,		0,0,0,0,0,0,0,1,
					0,0,1,1,0,0,1,1,		1,1,0,1,1,1,0,1,
					1,1,0,0,1,1,1,1,		0,0,0,0,0,0,0,1,
					1,1,0,0,1,1,0,0,		0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,		0,0,0,0,0,0,0,0,
					1,1,0,0,1,1,0,0,		1,1,0,1,1,1,0,1,
					0,0,0,0,0,0,0,0,		0,0,0,0,0,0,0,0,
           			0,0,1,1,0,0,1,1,		1,1,0,1,1,1,0,1,
					1,1,0,0,1,1,1,1,		0,0,0,0,0,0,0,1,
					0,0,1,1,0,0,1,1,		1,1,0,1,1,1,0,1,
					1,1,0,0,1,1,1,1,		0,0,0,0,0,0,0,0,
					1,1,0,0,1,1,0,0,		0,0,0,0,0,0,0,0,
             		1,1,0,0,1,1,1,1,		0,0,0,0,0,0,0,0,
					1,1,0,0,1,1,0,0,		1,1,0,1,1,1,0,0,
					1,1,0,0,1,1,1,0,		1,1,0,0,1,0,0,0
	};
	
	if(!pImage) return FALSE;
	if(pImage->GetDepth()<16){
		CImage *temp=Cov_8_To_24(pImage);
		delete pImage;
		pImage=temp;
	}

	int x,y,i;
	
	//��ֵ��
	if(white){
		for(i=0;i<256;i++){
			if(i<127){
				r[i]=g[i]=b[i]=255;
			}else{
				r[i]=g[i]=b[i]=0;
			}
		}
	}else{
		for(i=0;i<256;i++){
			if(i>126){
				r[i]=g[i]=b[i]=255;
			}else{
				r[i]=g[i]=b[i]=0;
			}
		}
	}
	DoPoint(pImage);

	int width=pImage->GetWidth(),height=pImage->GetHeight();
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer,head;
	long EffWidth=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;

	int nw,n,ne,w,e,sw,s,se;
	bool Finished=false;
	
	//ˮƽ�봹ֱ������������ĵ㣻
	while(!Finished){
		Finished=true;
		head=RawImage+EffWidth;
		for (y=1; y<height-1; y++){
			ImagePointer=head+sDepth;
			for (x=1; x<width-1; x++){
				if(ImagePointer[0]==0){
					w=*(ImagePointer-sDepth);
					e=*(ImagePointer+sDepth);
					if(w==255||e==255){
						nw=*(ImagePointer-EffWidth-sDepth);
						n =*(ImagePointer-EffWidth);
						ne=*(ImagePointer-EffWidth+sDepth);
						sw=*(ImagePointer+EffWidth-sDepth);
						s =*(ImagePointer+EffWidth);
						se=*(ImagePointer+EffWidth+sDepth);
						int index=((nw==255)? 1:0)+(( n==255)? 2:0)
								 +((ne==255)? 4:0)+(( w==255)? 8:0)
								 +(( e==255)?16:0)+((sw==255)?32:0)
								 +(( s==255)?64:0)+((se==255)?128:0);
						if(erasetable[index]) 
						{
							ImagePointer[0]=ImagePointer[1]=ImagePointer[2]=255;
							Finished=false;
							x++;
							ImagePointer+=sDepth;
						}
					}
				}
				ImagePointer+=sDepth;	
			}
			head+=EffWidth;
		}

		head=RawImage+sDepth;
		for (x=1; x<width-1; x++){
			ImagePointer=head+EffWidth;
			for (y=1; y<height-1; y++){
				if(ImagePointer[0]==0){
					s =*(ImagePointer+EffWidth);
					n =*(ImagePointer-EffWidth);
					if(s==255||n==255){
						w=*(ImagePointer-sDepth);
						e=*(ImagePointer+sDepth);
						nw=*(ImagePointer-EffWidth-sDepth);
						ne=*(ImagePointer-EffWidth+sDepth);
						sw=*(ImagePointer+EffWidth-sDepth);
						se=*(ImagePointer+EffWidth+sDepth);
						int index=((nw==255)? 1:0)+(( n==255)? 2:0)
								 +((ne==255)? 4:0)+(( w==255)? 8:0)
								 +(( e==255)?16:0)+((sw==255)?32:0)
								 +(( s==255)?64:0)+((se==255)?128:0);
						if(erasetable[index]) 
						{
							ImagePointer[0]=ImagePointer[1]=ImagePointer[2]=255;
							Finished=false;
							y++;
							ImagePointer+=EffWidth;
						}
					}
				}
				ImagePointer+=EffWidth;
			}
			head+=sDepth;
		}
	}

	//��ɫ
	if(white){
		for(i=0;i<256;i++){
			r[i]=g[i]=b[i]=255-i;
		}
		DoPoint(pImage);
	}

	return TRUE;
}

BOOL CDipProcessor::Empty(CImage *pImage)
{
	ImagePointerType RawImage=pImage->GetRawImage();
	VERIFY(RawImage);
	ImagePointerType ImagePointer,head;
	int Width=pImage->GetWidth(),Height=pImage->GetHeight();
	long EffWidth=pImage->GetEffWidth();
	int sDepth=pImage->GetDepth()>>3;
	head=RawImage;
	for (int y=0; y<Height; y++) {
		ImagePointer = head;
		for (int x=0; x<Width; x++) {
			if(ImagePointer[0]!=0)
				return FALSE;
			ImagePointer+=sDepth;
		}
		head += EffWidth;
	}
	return TRUE;
}
