#if !defined(AFX_TSDLG_H__58085AA2_BDC0_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_TSDLG_H__58085AA2_BDC0_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TsDlg.h : header file
//
#include "GraphStatic.h"
/////////////////////////////////////////////////////////////////////////////
// CTsDlg dialog

class CTsDlg : public CDialog
{
// Construction
public:
	void Reset();
	CTsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTsDlg)
	enum { IDD = IDD_DIALOG_PERSPECTE };
	CButton	m_two;
	CGraphStatic	m_graph;
	int		m_jj;
	int		m_jl;
	int		m_sj1;
	int		m_sj2;
	BOOL	m_inter;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnButtonReset();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void DoUpdate();
	CImage * m_image,* m_bak;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TSDLG_H__58085AA2_BDC0_11D4_A11E_0080C8D7131C__INCLUDED_)
