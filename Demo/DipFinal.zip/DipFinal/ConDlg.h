#if !defined(AFX_CONDLG_H__6EAD5609_B494_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_CONDLG_H__6EAD5609_B494_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConDlg.h : header file
//
#include "ParaLine.h"

/////////////////////////////////////////////////////////////////////////////
// CConDlg dialog

class CConDlg : public CDialog
{
// Construction
public:
	CConDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CConDlg)
	enum { IDD = IDD_DIALOG_CONTRAST };
	CParaLine	m_static;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CConDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONDLG_H__6EAD5609_B494_11D4_A11E_0080C8D7131C__INCLUDED_)
