// FloatDibWnd.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"
#include "lib/cimage.h"
#include "DipDoc.h"
#include "DipView.h"
//#include "FloatDibWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFloatDibWnd

CFloatDibWnd::CFloatDibWnd(CImage *pImage, BOOL bcolor,CRect rc, CWnd* pParentWnd,BOOL bPaste)
{
	m_image = pImage;
	m_nFirst = 0;
	m_bcolor=bcolor;
	m_bPaste=bPaste;
	m_hCursorFloat = AfxGetApp()->LoadCursor(IDC_CURSORMOVE);
	Create(AfxRegisterWndClass(NULL, m_hCursorFloat), 
		   "", WS_VISIBLE|WS_CHILD|WS_CLIPSIBLINGS, 
		   rc, pParentWnd, 0x6612);
}

CFloatDibWnd::~CFloatDibWnd()
{
	delete 	m_image;
	m_image=NULL;
}


BEGIN_MESSAGE_MAP(CFloatDibWnd, CWnd)
	//{{AFX_MSG_MAP(CFloatDibWnd)
	ON_WM_PAINT()
	ON_WM_NCHITTEST()
	ON_WM_SETCURSOR()
	ON_WM_DESTROY()
	ON_WM_MOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CFloatDibWnd message handlers

void CFloatDibWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	OnDraw(&dc);
}

UINT CFloatDibWnd::OnNcHitTest(CPoint point) 
{
	return HTCAPTION;
}

BOOL CFloatDibWnd::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	SetCursor(m_hCursorFloat);	
	return TRUE;//CWnd::OnSetCursor(pWnd, nHitTest, message);
}

void CFloatDibWnd::OnDestroy() 
{
	delete m_image;
	m_image=NULL;
	CWnd::OnDestroy();
}

void CFloatDibWnd::OnMove(int x, int y) 
{
	CWnd::OnMove(x, y);

	// eat the first WM_MOVE when creating
	if (m_nFirst==0){
		m_nFirst = 1;
		return;
	}
	
	if (m_nFirst==1)
	{
		m_nFirst = 2;
		CDipView* pParent = (CDipView *)GetParent();
		pParent->CutSelectedRect();
		return;
	}
	UpdateWindow();
}


void CFloatDibWnd::OnDraw(CDC *pDC)
{
	CRect rc;
	GetClientRect(&rc);
	int width = rc.right - rc.left;
	int height = rc.bottom - rc.top;

	if (m_image)
	{    
		CPalette *hOldPal = 0;
		if (m_image->GetPalette())
		{
			hOldPal = pDC->SelectPalette(m_image->GetPalette(), TRUE);
			pDC->RealizePalette();
		}
		m_image->Stretch(pDC,0,0,rc.Width(), rc.Height(),0,0);//Draw(pDC->GetSafeHdc(),0,0,rc.Width(), rc.Height(),0,0);
		if(hOldPal)
			pDC->SelectPalette(hOldPal,TRUE);
	}

	CPen pen1(PS_SOLID, 1, RGB(255,255,255));
	CPen pen2(PS_DOT, 1, RGB(0,0,0));
	CPen* pOldPen = pDC->SelectObject(&pen1);
	pDC->MoveTo(rc.left, rc.top);
	pDC->LineTo(rc.right-1, rc.top);
	pDC->LineTo(rc.right-1, rc.bottom-1);
	pDC->LineTo(rc.left, rc.bottom-1);
	pDC->LineTo(rc.left, rc.top);

	pDC->SelectObject(&pen2);
	pDC->MoveTo(rc.left, rc.top);
	pDC->LineTo(rc.right-1, rc.top);
	pDC->LineTo(rc.right-1, rc.bottom-1);
	pDC->LineTo(rc.left, rc.bottom-1);
	pDC->LineTo(rc.left, rc.top);
	pDC->SelectObject(pOldPen);
}
