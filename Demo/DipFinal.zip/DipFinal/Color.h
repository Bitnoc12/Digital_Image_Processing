#if !defined(AFX_COLOR_H__8A1BE72C_B35A_11D4_A11E_0080C8D7131C__INCLUDED_)
#define AFX_COLOR_H__8A1BE72C_B35A_11D4_A11E_0080C8D7131C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Color.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CColor window

class CColor : public CStatic
{
// Construction
public:
	CColor();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColor)
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetCh(int ch);
	virtual ~CColor();

	// Generated message map functions
protected:
	int m_ch;
	//{{AFX_MSG(CColor)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLOR_H__8A1BE72C_B35A_11D4_A11E_0080C8D7131C__INCLUDED_)
