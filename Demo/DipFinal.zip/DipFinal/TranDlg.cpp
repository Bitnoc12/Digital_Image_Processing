// TranDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Dip.h"

#include "lib/cimage.h"
#include "DipProcessor.h"

#include "DipDoc.h"
#include "DipView.h"
#include "TranDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTranDlg dialog


CTranDlg::CTranDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTranDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTranDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_image=NULL;
	m_view=NULL;
}


void CTranDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTranDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTranDlg, CDialog)
	//{{AFX_MSG_MAP(CTranDlg)
	ON_WM_DESTROY()
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTranDlg message handlers

void CTranDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	delete m_image;
	m_image=NULL;
	m_view->ReleaseCurDC(pDc);
}

void CTranDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);

	CDipProcessor::CopyData(m_view->GetDocument()->GetCurImage(),m_image);
	static CString str;
	str.Format("%d",m_ps_L->GetPos()-m_image->GetWidth());
	SetDlgItemText(IDC_STATIC_L,str);
	str.Format("%d",m_ps_H->GetPos()-m_image->GetHeight());
	SetDlgItemText(IDC_STATIC_H,str);
	CDipProcessor::GeoTranlate(m_view->GetDocument()->GetCurImage(),m_ps_L->GetPos()-m_image->GetWidth(),m_ps_H->GetPos()-m_image->GetHeight());
	m_view->ReDraw(pDc);//OnDraw(pDc);
}

BOOL CTranDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_view=CDipView::GetActiveView();
	pDc=m_view->GetCurDC();

	m_image=new CImage(m_view->GetDocument()->GetCurImage());
	CDipProcessor::CopyData(m_image,m_view->GetDocument()->GetCurImage());
	VERIFY(m_image->IsOK());

	CString str;
	m_ps_L=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_L);
	m_ps_L->SetRange(0,2*m_image->GetWidth());
	m_ps_L->SetPos(m_image->GetWidth());
	str.Format("%d",m_ps_L->GetPos()-m_image->GetWidth());
	SetDlgItemText(IDC_STATIC_L,str);

	m_ps_H=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_H);
	m_ps_H->SetRange(0,2*m_image->GetHeight());
	m_ps_H->SetPos(m_image->GetHeight());
	str.Format("%d",m_ps_H->GetPos()-m_image->GetHeight());
	SetDlgItemText(IDC_STATIC_H,str);

	return 	true;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
